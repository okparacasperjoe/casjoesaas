<?php

namespace App\Modules\CasjoeAcademy\Controllers;

use App\Core\Database;
use App\Core\TenantContext;
use App\Core\SubscriptionManager;
use App\Core\Services\CurrencyService;
use PDO;

class AcademyController
{
    private $pdo;

    public function __construct()
    {
        $this->pdo = Database::getInstance()->getConnection();
    }

    public function index()
    {
        $tenantId = TenantContext::getTenantId();
        SubscriptionManager::requireActive($tenantId);

        // Public Catalog
        $stmt = $this->pdo->query("SELECT * FROM academy_courses WHERE status = 'published' ORDER BY created_at DESC");
        $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
        require __DIR__ . '/../views/catalog.php';
    }

    public function myCourses()
    {
        if (!isset($_SESSION['user_id'])) {
           header('Location: /login');
           exit;
        }

        $userId = $_SESSION['user_id'];
        $stmt = $this->pdo->prepare("
            SELECT c.*, e.progress_percent 
            FROM academy_courses c
            JOIN academy_enrollments e ON c.id = e.course_id
            WHERE e.user_id = ?
        ");
        $stmt->execute([$userId]);
        $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../views/student_dashboard.php';
    }

    public function course($id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM academy_courses WHERE id = ?");
        $stmt->execute([$id]);
        $course = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$course) die("Course not found");

        // Get Curriculum
        $stmt = $this->pdo->prepare("SELECT * FROM academy_sections WHERE course_id = ? ORDER BY sort_order ASC");
        $stmt->execute([$id]);
        $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($sections as &$section) {
            $stmt = $this->pdo->prepare("SELECT * FROM academy_lessons WHERE section_id = ? ORDER BY sort_order ASC");
            $stmt->execute([$section['id']]);
            $section['lessons'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        // Check Enrollment
        $isEnrolled = false;
        if (isset($_SESSION['user_id'])) {
            $stmt = $this->pdo->prepare("SELECT * FROM academy_enrollments WHERE user_id = ? AND course_id = ?");
            $stmt->execute([$_SESSION['user_id'], $id]);
            $enrollment = $stmt->fetch(PDO::FETCH_ASSOC);
            $isEnrolled = (bool) $enrollment;
            $progressPercent = $enrollment['progress_percent'] ?? 0;
        }

        require __DIR__ . '/../views/course_details.php';
    }

    public function enroll($id)
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: /login');
            exit;
        }

        $stmt = $this->pdo->prepare("SELECT * FROM academy_courses WHERE id = ?");
        $stmt->execute([$id]);
        $course = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$course) die("Course not found");

        // Check if already enrolled
        $stmt = $this->pdo->prepare("SELECT * FROM academy_enrollments WHERE user_id = ? AND course_id = ?");
        $stmt->execute([$_SESSION['user_id'], $id]);
        if ($stmt->fetch()) {
             header("Location: /academy/course/$id");
             exit;
        }

        // Free Course?
        if ($course['price'] <= 0) {
            $stmt = $this->pdo->prepare("INSERT INTO academy_enrollments (user_id, course_id) VALUES (?, ?)");
            $stmt->execute([$_SESSION['user_id'], $id]);
            header("Location: /academy/course/$id");
            exit;
        }

        // Paid Course -> Show Payment Page
        require __DIR__ . '/../views/enroll.php';
    }

    public function processEnrollment()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id'])) {
            header('Location: /academy'); exit;
        }

        $userId = $_SESSION['user_id'];
        $courseId = $_POST['course_id'];
        $currency = $_POST['currency'] ?? 'NGN';

        $stmt = $this->pdo->prepare("SELECT * FROM academy_courses WHERE id = ?");
        $stmt->execute([$courseId]);
        $course = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$course) die("Invalid Course");
        
        $priceNGN = (float) $course['price'];

        // Calculate Cost in Selected Currency
        $currencyService = new CurrencyService();
        $rate = $currencyService->getExchangeRate('NGN', $currency);
        $cost = $priceNGN * $rate;

        // Check Wallet
        $stmt = $this->pdo->prepare("SELECT balance FROM cp_wallets WHERE user_id = ? AND currency = ?");
        $stmt->execute([$userId, $currency]);
        $wallet = $stmt->fetch(PDO::FETCH_ASSOC);

        if (($wallet['balance'] ?? 0) < $cost) {
            die("Insufficient $currency balance. Need " . number_format($cost, 2) . " $currency");
        }

        // Debit & Enroll
        $this->pdo->beginTransaction();
        try {
            // Debit
            $stmt = $this->pdo->prepare("UPDATE cp_wallets SET balance = balance - ? WHERE user_id = ? AND currency = ?");
            $stmt->execute([$cost, $userId, $currency]);

            // Enroll
            $stmt = $this->pdo->prepare("INSERT INTO academy_enrollments (user_id, course_id) VALUES (?, ?)");
            $stmt->execute([$userId, $courseId]);

            // Transaction Log
            $desc = "Enrolled in " . $course['title'];
            $stmt = $this->pdo->prepare("INSERT INTO cp_transactions (tenant_id, user_id, reference, amount, currency, status, type, description) VALUES (?, ?, ?, ?, ?, 'successful', 'debit', ?)");
            $stmt->execute([TenantContext::getTenantId(), $userId, 'ENR-'.uniqid(), $cost, $currency, $desc]);

            $this->pdo->commit();
            header("Location: /academy/course/$courseId?success=enrolled");

        } catch (\Exception $e) {
            $this->pdo->rollBack();
            die("Enrollment Failed: " . $e->getMessage());
        }
    }


}
