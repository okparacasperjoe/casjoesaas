<?php

namespace App\Modules\CasjoeAcademy\Controllers;

use App\Core\Database;
use App\Core\TenantContext;
use App\Core\SubscriptionManager;
use PDO;

class BusinessController
{
    private $pdo;
    private $tenantId;

    public function __construct() {
        $this->tenantId = TenantContext::getTenantId();
        SubscriptionManager::requireActive($this->tenantId);
        $this->pdo = Database::getInstance()->getConnection();
    }

    // Dashboard: Overview of Team Learning
    public function dashboard() {
        $tenantId = $this->tenantId;
        
        // Stats
        $totalStaff = $this->pdo->query("SELECT COUNT(*) FROM users WHERE tenant_id = $tenantId")->fetchColumn();
        $totalLicenses = $this->pdo->query("SELECT SUM(seats_total) FROM academy_licenses WHERE tenant_id = $tenantId")->fetchColumn() ?? 0;
        $activeLearners = $this->pdo->query("SELECT COUNT(DISTINCT user_id) FROM academy_certificates WHERE tenant_id = $tenantId")->fetchColumn(); // Approx
        
        // Licenses Owned
        $licenses = $this->pdo->query("
            SELECT l.*, c.title, c.thumbnail 
            FROM academy_licenses l 
            JOIN academy_courses c ON l.course_id = c.id 
            WHERE l.tenant_id = $tenantId
        ")->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../views/business/dashboard.php';
    }

    // Marketplace: Browse System Courses to Buy
    public function marketplace() {
        $courses = $this->pdo->query("SELECT * FROM academy_courses WHERE is_system_course = 1 AND status = 'published'")->fetchAll(PDO::FETCH_ASSOC);
        require __DIR__ . '/../views/business/marketplace.php';
    }

    // Buy License (Simulation)
    public function buyLicense() {
        $courseId = $_POST['course_id'];
        $seats = intval($_POST['seats']);
        
        if ($seats < 1) die("Invalid seats");

        // Casjoe Pay Logic would go here (Check balance, deduct funds)
        
        // Create/Update License
        $stmt = $this->pdo->prepare("INSERT INTO academy_licenses (tenant_id, course_id, seats_total, seats_used) VALUES (?, ?, ?, 0) ON DUPLICATE KEY UPDATE seats_total = seats_total + ?");
        // Note: ON DUPLICATE KEY UPDATE on (tenant_id, course_id) requires a UNIQUE index which we didn't add yet, so let's just insert new row or separate logic.
        // Actually, schema didn't enforce unique tenant_id+course_id. Simple Insert is fine for now, or we can check existing.
        
        // Simple logic: Check existing license
        $stmt = $this->pdo->prepare("SELECT id FROM academy_licenses WHERE tenant_id = ? AND course_id = ?");
        $stmt->execute([$this->tenantId, $courseId]);
        $existing = $stmt->fetch();

        if ($existing) {
            $this->pdo->prepare("UPDATE academy_licenses SET seats_total = seats_total + ? WHERE id = ?")->execute([$seats, $existing['id']]);
        } else {
             $this->pdo->prepare("INSERT INTO academy_licenses (tenant_id, course_id, seats_total, seats_used) VALUES (?, ?, ?, 0)")->execute([$this->tenantId, $courseId, $seats]);
        }

        header("Location: /academy/business");
    }

    // Assign Seat View
    public function assignView() {
        $licenseId = $_GET['license_id'];
        
        // Get License
        $stmt = $this->pdo->prepare("SELECT l.*, c.title FROM academy_licenses l JOIN academy_courses c ON l.course_id = c.id WHERE l.id = ? AND l.tenant_id = ?");
        $stmt->execute([$licenseId, $this->tenantId]);
        $license = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$license) die("License not found");

        // Get Staff not yet enrolled
        $stmt = $this->pdo->prepare("
            SELECT u.* 
            FROM users u 
            WHERE u.tenant_id = ? 
            AND u.id NOT IN (
                SELECT user_id FROM academy_enrollments WHERE course_id = ?
            )
        ");
        $stmt->execute([$this->tenantId, $license['course_id']]);
        $staff = $stmt->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../views/business/assign.php';
    }

    // Process Assignment
    public function assignStore() {
        $licenseId = $_POST['license_id'];
        $userId = $_POST['user_id'];

        // Verify License Seats
        $stmt = $this->pdo->prepare("SELECT * FROM academy_licenses WHERE id = ? AND tenant_id = ?");
        $stmt->execute([$licenseId, $this->tenantId]);
        $license = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($license['seats_used'] >= $license['seats_total']) {
            die("No seats available. Purchase more.");
        }

        // Enroll User
        $this->pdo->prepare("INSERT INTO academy_enrollments (user_id, course_id, progress_percent) VALUES (?, ?, 0)")->execute([$userId, $license['course_id']]);
        
        // Update License Count
        $this->pdo->prepare("UPDATE academy_licenses SET seats_used = seats_used + 1 WHERE id = ?")->execute([$licenseId]);

        header("Location: /academy/business");
    }
}
