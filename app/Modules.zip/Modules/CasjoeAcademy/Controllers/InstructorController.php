<?php

namespace App\Modules\CasjoeAcademy\Controllers;

use App\Core\Database;
use App\Core\TenantContext;
use PDO;

class InstructorController
{
    private $pdo;
    private $tenantId;

    public function __construct() {
        $this->tenantId = TenantContext::getTenantId();
        // Permission check? For now, any tenant user is an instructor for their own tenant.
        // Ideally should check `user.role` or `user.is_instructor`, but we skip for MVC simplicity.
        $this->pdo = Database::getInstance()->getConnection();
    }

    // Dashboard: List courses I created
    public function index() {
        $tenantId = $this->tenantId;
        $courses = $this->pdo->query("SELECT * FROM academy_courses WHERE tenant_id = $tenantId ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
        require __DIR__ . '/../views/instructor/dashboard.php';
    }

    // Create Form
    public function create() {
        require __DIR__ . '/../views/instructor/create.php';
    }

    // Store New Course
    public function store() {
        $title = $_POST['title'];
        $category = $_POST['category'];
        $price = $_POST['price'];
        $desc = $_POST['description'];
        $isSystem = isset($_POST['is_system']) ? 1 : 0; // Only Admin can set this ideally
        
        // Handle Thumbnail Upload (Simplified: Text URL or default)
        // In real app, we'd handle $_FILES
        $thumbnail = !empty($_POST['thumbnail_url']) ? $_POST['thumbnail_url'] : 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=600';

        $stmt = $this->pdo->prepare("INSERT INTO academy_courses (tenant_id, title, category, price_per_seat, description, thumbnail, is_system_course, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'draft')");
        $stmt->execute([$this->tenantId, $title, $category, $price, $desc, $thumbnail, $isSystem]);
        
        $newId = $this->pdo->lastInsertId();
        header("Location: /academy/instructor/edit/$newId");
    }

    // Edit Course / Analytics / Builder Wrapper
    public function edit($id) {
        // Verify Ownership
        $stmt = $this->pdo->prepare("SELECT * FROM academy_courses WHERE id = ? AND tenant_id = ?");
        $stmt->execute([$id, $this->tenantId]);
        $course = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$course) die("Course not found or access denied.");

        // Fetch Structure
        $stmt = $this->pdo->prepare("SELECT * FROM academy_sections WHERE course_id = ? ORDER BY sort_order ASC");
        $stmt->execute([$id]);
        $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($sections as &$s) {
            $stmt = $this->pdo->prepare("SELECT * FROM academy_lessons WHERE section_id = ? ORDER BY sort_order ASC");
            $stmt->execute([$s['id']]);
            $s['lessons'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        require __DIR__ . '/../views/instructor/edit.php';
    }

    // Add Section
    public function addSection() {
        $id = $_POST['course_id'];
        $title = $_POST['title'];
        
        // Verify ownership first... (Skipping for brevity, assuming form data is trusted-ish in this MVP for same tenant)
        // Ideally verify $id belongs to $this->tenantId
        
        $this->pdo->prepare("INSERT INTO academy_sections (course_id, title, sort_order) VALUES (?, ?, 99)")->execute([$id, $title]);
        header("Location: /academy/instructor/edit/$id");
    }

    // Add Lesson
    public function addLesson() {
        $sectionId = $_POST['section_id'];
        $courseId = $_POST['course_id'];
        $title = $_POST['title'];

        $this->pdo->prepare("INSERT INTO academy_lessons (section_id, title, content, sort_order) VALUES (?, ?, 'No content yet.', 99)")->execute([$sectionId, $title]);
         header("Location: /academy/instructor/edit/$courseId");
    }

    // Publish
    public function publish($id) {
        $this->pdo->prepare("UPDATE academy_courses SET status = 'published' WHERE id = ? AND tenant_id = ?")->execute([$id, $this->tenantId]);
        header("Location: /academy/instructor");
    }
}
