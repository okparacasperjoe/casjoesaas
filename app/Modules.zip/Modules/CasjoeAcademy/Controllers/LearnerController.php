<?php

namespace App\Modules\CasjoeAcademy\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\TenantContext;

class LearnerController
{
    private $pdo;
    private $tenantId;

    public function __construct() {
        if (!Auth::check()) {
            $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
            header("Location: /login");
            exit;
        }
        $this->tenantId = TenantContext::getTenantId();
        $this->pdo = Database::getInstance()->getConnection();
    }

    public function dashboard() {
        $userId = Auth::user()['id'];

        $stmt = $this->pdo->prepare("
            SELECT e.*, c.title, c.thumbnail 
            FROM academy_enrollments e
            JOIN academy_courses c ON e.course_id = c.id
            WHERE e.user_id = ?
            ORDER BY e.enrolled_at DESC
        ");
        $stmt->execute([$userId]);
        $courses = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        require __DIR__ . '/../views/student_dashboard.php';
    }

    public function learn($id) {
        $userId = Auth::user()['id'];

        // 1. Fetch Lesson
        $stmt = $this->pdo->prepare("SELECT * FROM academy_lessons WHERE id = ?");
        $stmt->execute([$id]);
        $lesson = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$lesson) die("Lesson not found.");

        // 2. Fetch Course & Sections
        $courseId = 0; 
        // Need to find course_id from section. 
        $stmt = $this->pdo->prepare("SELECT course_id FROM academy_sections WHERE id = ?");
        $stmt->execute([$lesson['section_id']]);
        $courseId = $stmt->fetchColumn();

        $stmt = $this->pdo->prepare("SELECT * FROM academy_courses WHERE id = ?");
        $stmt->execute([$courseId]);
        $course = $stmt->fetch(\PDO::FETCH_ASSOC);

        // 3. Verify Enrollment
        $stmt = $this->pdo->prepare("SELECT * FROM academy_enrollments WHERE user_id = ? AND course_id = ?");
        $stmt->execute([$userId, $courseId]);
        $enrollment = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$enrollment) {
            die("You are not enrolled in this course.");
        }

        // 4. Fetch Full Curriculum for Sidebar
        $stmt = $this->pdo->prepare("SELECT * FROM academy_sections WHERE course_id = ? ORDER BY sort_order ASC");
        $stmt->execute([$courseId]);
        $sections = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        foreach ($sections as &$s) {
            $stmt = $this->pdo->prepare("SELECT * FROM academy_lessons WHERE section_id = ? ORDER BY sort_order ASC");
            $stmt->execute([$s['id']]);
            $s['lessons'] = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        }

        // 5. Check Completion Status
        $stmt = $this->pdo->prepare("SELECT lesson_id FROM academy_lesson_completions WHERE user_id = ? AND course_id = ?");
        $stmt->execute([$userId, $courseId]);
        $completedLessonIds = $stmt->fetchAll(\PDO::FETCH_COLUMN);

        $isCompleted = in_array($id, $completedLessonIds);

        // View
        require __DIR__ . '/../views/learn.php';
    }

    public function completeLesson($id) {
        $userId = Auth::user()['id'];

        // Get Course ID from Lesson
        $stmt = $this->pdo->prepare("
            SELECT s.course_id 
            FROM academy_lessons l 
            JOIN academy_sections s ON l.section_id = s.id 
            WHERE l.id = ?
        ");
        $stmt->execute([$id]);
        $courseId = $stmt->fetchColumn();

        if (!$courseId) die("Invalid lesson.");

        // Mark as Complete
        // Use IGNORE to prevent error on duplicate click
        $this->pdo->prepare("INSERT IGNORE INTO academy_lesson_completions (user_id, lesson_id, course_id) VALUES (?, ?, ?)")
                  ->execute([$userId, $id, $courseId]);

        // Calculate New Progress
        $this->updateProgress($userId, $courseId);

        // Redirect to next lesson or same page
        header("Location: /academy/learn/$id");
    }

    private function updateProgress($userId, $courseId) {
        // Count Total Lessons
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) FROM academy_lessons l
            JOIN academy_sections s ON l.section_id = s.id
            WHERE s.course_id = ?
        ");
        $stmt->execute([$courseId]);
        $total = $stmt->fetchColumn();

        if ($total == 0) return;

        // Count Completed
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM academy_lesson_completions WHERE user_id = ? AND course_id = ?");
        $stmt->execute([$userId, $courseId]);
        $completed = $stmt->fetchColumn();

        $percent = min(100, round(($completed / $total) * 100));

        // Update Enrollment
        $this->pdo->prepare("UPDATE academy_enrollments SET progress_percent = ? WHERE user_id = ? AND course_id = ?")
                  ->execute([$percent, $userId, $courseId]);
    }
}
