<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Quiz | Casjoe Academy</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="app-container">
        <?php include __DIR__ . '/../../layout/sidebar.php'; ?>
        
        <main class="main-content">
            <div class="top-bar">
                <h1>Create Quiz for: <?= htmlspecialchars($course['title']) ?></h1>
            </div>

            <div class="card" style="max-width: 800px;">
                <form action="/academy/quiz/store/<?= $course['id'] ?>" method="POST">
                    
                    <div class="form-group">
                        <label>Quiz Title</label>
                        <input type="text" name="title" required placeholder="e.g. Final Assessment" class="form-control">
                    </div>

                    <div class="form-group">
                        <label>Passing Score (%)</label>
                        <input type="number" name="passing_score" min="0" max="100" value="70" class="form-control">
                    </div>

                    <hr>
                    <h3>Questions</h3>
                    <div id="questions-container">
                        <!-- Questions will be added here dynamically -->
                    </div>

                    <button type="button" class="btn btn-secondary" onclick="addQuestion()" style="margin-bottom: 20px;">+ Add Question</button>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Save Quiz</button>
                    </div>
                </form>
            </div>
        </main>
    </div>

    <script>
        let questionCount = 0;

        function addQuestion() {
            const container = document.getElementById('questions-container');
            const index = questionCount;
            
            const html = `
                <div class="card" style="margin-bottom: 15px; border: 1px solid #eee; background: #f9f9f9;">
                    <div class="form-group">
                        <label>Question ${index + 1}</label>
                        <input type="text" name="questions[${index}][text]" required class="form-control" placeholder="Enter question text">
                    </div>
                    
                    <div style="margin-left: 20px;">
                        <label>Options (Select the correct answer dot)</label>
                        <div style="display: flex; align-items: center; margin-bottom: 5px;">
                            <input type="radio" name="questions[${index}][correct_index]" value="0" required>
                            <input type="text" name="questions[${index}][options][]" required class="form-control" style="width: 80%; margin-left: 10px;" placeholder="Option A">
                        </div>
                        <div style="display: flex; align-items: center; margin-bottom: 5px;">
                            <input type="radio" name="questions[${index}][correct_index]" value="1">
                            <input type="text" name="questions[${index}][options][]" required class="form-control" style="width: 80%; margin-left: 10px;" placeholder="Option B">
                        </div>
                        <div style="display: flex; align-items: center; margin-bottom: 5px;">
                            <input type="radio" name="questions[${index}][correct_index]" value="2">
                            <input type="text" name="questions[${index}][options][]" class="form-control" style="width: 80%; margin-left: 10px;" placeholder="Option C (Optional)">
                        </div>
                        <div style="display: flex; align-items: center; margin-bottom: 5px;">
                            <input type="radio" name="questions[${index}][correct_index]" value="3">
                            <input type="text" name="questions[${index}][options][]" class="form-control" style="width: 80%; margin-left: 10px;" placeholder="Option D (Optional)">
                        </div>
                    </div>
                </div>
            `;
            
            const div = document.createElement('div');
            div.innerHTML = html;
            container.appendChild(div);
            questionCount++;
        }
        
        // Add one question by default
        addQuestion();
    </script>
</body>
</html>
