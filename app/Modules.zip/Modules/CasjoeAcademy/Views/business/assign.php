<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Assign Training | Casjoe Academy</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="brand">
                <span>Casjoe Academy</span>
            </div>
             <ul class="nav-menu">
                <li class="nav-item"><a href="/academy/business" class="nav-link active">Back to Dashboard</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h1>Assign Training License</h1>
            </div>

            <div class="card app-card-white" style="max-width: 600px; text-align: left;">
                <h3 style="margin-bottom: 20px;">Course: <?= htmlspecialchars($license['title']) ?></h3>
                
                <div style="background: #f9f9f9; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #eee;">
                    <strong>Seats Available:</strong> <?= $license['seats_total'] - $license['seats_used'] ?> / <?= $license['seats_total'] ?>
                </div>

                <form action="/academy/business/assign" method="POST">
                    <input type="hidden" name="license_id" value="<?= $license['id'] ?>">
                    
                    <div class="form-group">
                        <label>Select Team Member</label>
                        <select name="user_id" class="form-control" required style="color: #333; background: white; border: 1px solid #ccc;">
                            <option value="">-- Choose Staff --</option>
                            <?php foreach ($staff as $u): ?>
                                <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['first_name'] . ' ' . $u['last_name']) ?> (<?= $u['email'] ?>)</option>
                            <?php endforeach; ?>
                        </select>
                        <?php if(empty($staff)): ?>
                            <p style="color: orange; font-size: 0.9rem; margin-top: 5px;">No eligible staff found (or all already enrolled).</p>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="btn">Assign Seat</button>
                    <a href="/academy/business" class="btn" style="background: #eee; color: #333;">Cancel</a>
                </form>
            </div>
        </main>
    </div>
</body>
</html>
