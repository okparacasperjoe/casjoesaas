<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Academy | Business Dashboard</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <?php $active = 'academy_business'; include __DIR__ . '/../partials/sidebar_academy.php'; ?>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h1>Business Training Hub</h1>
                <div class="user-profile">
                    <div class="user-avatar">AD</div>
                </div>
            </div>

            <!-- ROI / Stats Cards -->
            <div class="dashboard-grid">
                <div class="card stat-card">
                    <div class="stat-value"><?= $totalStaff ?></div>
                    <div class="stat-label">Total Staff</div>
                    <ion-icon name="people-outline" class="stat-icon"></ion-icon>
                </div>
                <div class="card stat-card">
                    <div class="stat-value"><?= $totalLicenses ?></div>
                    <div class="stat-label">Licenses Purchased</div>
                    <ion-icon name="card-outline" class="stat-icon"></ion-icon>
                </div>
                <div class="card stat-card">
                    <div class="stat-value"><?= $activeLearners ?></div>
                    <div class="stat-label">Certified Staff</div>
                    <ion-icon name="ribbon-outline" class="stat-icon"></ion-icon>
                </div>
            </div>

            <!-- License Management -->
            <div class="section-title">
                <ion-icon name="library-outline"></ion-icon>
                Training Inventory
            </div>

            <div class="card app-card-white" style="align-items: stretch; text-align: left;">
                <?php if (empty($licenses)): ?>
                    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
                        <ion-icon name="school-outline" style="font-size: 3rem; margin-bottom: 10px;"></ion-icon>
                        <p>No active training licenses. Visit the Catalog to equip your team.</p>
                        <a href="/academy/business/marketplace" class="btn" style="margin-top: 15px;">Browse Catalog</a>
                    </div>
                <?php else: ?>
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="border-bottom: 1px solid #eee;">
                                <th style="padding: 15px;">Course</th>
                                <th style="padding: 15px;">Seats (Used / Total)</th>
                                <th style="padding: 15px;">Utilization</th>
                                <th style="padding: 15px; text-align: right;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($licenses as $l): ?>
                                <?php $utilization = $l['seats_total'] > 0 ? round(($l['seats_used'] / $l['seats_total']) * 100) : 0; ?>
                                <tr style="border-bottom: 1px solid #fafafa;">
                                    <td style="padding: 15px; display: flex; align-items: center; gap: 10px;">
                                        <img src="<?= htmlspecialchars($l['thumbnail']) ?>" style="width: 40px; height: 40px; border-radius: 4px; object-fit: cover; background: #eee;">
                                        <span style="font-weight: 500; color: #333;"><?= htmlspecialchars($l['title']) ?></span>
                                    </td>
                                    <td style="padding: 15px; color: #555;">
                                        <?= $l['seats_used'] ?> / <?= $l['seats_total'] ?>
                                    </td>
                                    <td style="padding: 15px;">
                                        <div style="background: #eee; height: 6px; width: 100px; border-radius: 3px; overflow: hidden;">
                                            <div style="background: var(--secondary); height: 100%; width: <?= $utilization ?>%;"></div>
                                        </div>
                                        <span style="font-size: 11px; color: #999;"><?= $utilization ?>%</span>
                                    </td>
                                    <td style="padding: 15px; text-align: right;">
                                        <a href="/academy/business/assign?license_id=<?= $l['id'] ?>" class="btn-sm" style="color: var(--primary); text-decoration: none; border: 1px solid var(--primary); padding: 5px 10px; border-radius: 4px;">Unknown Staff</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
