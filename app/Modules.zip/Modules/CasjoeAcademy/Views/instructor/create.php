<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Course | Casjoe Academy</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        .form-card { max-width: 700px; margin: 0 auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .form-group label { font-weight: 600; color: #444; margin-bottom: 8px; display: block; }
        .form-control { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 1rem; transition: border 0.3s; }
        .form-control:focus { border-color: var(--primary); outline: none; }
        .upload-box { border: 2px dashed #ddd; padding: 30px; text-align: center; border-radius: 8px; cursor: pointer; transition: background 0.2s; }
        .upload-box:hover { background: #f9f9f9; border-color: #ccc; }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="brand">
                 <img src="/assets/casjoe_logo.png" alt="Casjoe Apps" style="height: 40px;">
            </div>
            <ul class="nav-menu">
                <li class="nav-item"><a href="/academy/instructor" class="nav-link"><ion-icon name="arrow-back-outline"></ion-icon> Cancel</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="form-card">
                <h2 style="margin-top: 0; margin-bottom: 25px; text-align: center;">Name Your Course</h2>
                
                <form action="/academy/instructor/store" method="POST" enctype="multipart/form-data">
                    <div class="form-group" style="margin-bottom: 20px;">
                        <label>Course Title</label>
                        <input type="text" name="title" class="form-control" placeholder="e.g. Master Class in Strategic Finance" required>
                    </div>

                    <div style="display: flex; gap: 20px; margin-bottom: 20px;">
                        <div class="form-group" style="flex: 1;">
                            <label>Category</label>
                            <select name="category" class="form-control">
                                <option value="Operations">Operations</option>
                                <option value="Sales">Sales</option>
                                <option value="Marketing">Marketing</option>
                                <option value="Technology">Technology</option>
                                <option value="Finance">Finance</option>
                                <option value="HR">HR & Leadership</option>
                            </select>
                        </div>
                        <div class="form-group" style="flex: 1;">
                            <label>Price ($)</label>
                            <input type="number" name="price" class="form-control" value="0.00" min="0" step="0.01">
                        </div>
                    </div>

                    <div class="form-group" style="margin-bottom: 20px;">
                        <label>Thumbnail Image</label>
                        <div class="upload-box" onclick="document.getElementById('thumbInput').click()">
                            <ion-icon name="image-outline" style="font-size: 2rem; color: #888;"></ion-icon>
                            <p style="margin: 10px 0 0; color: #666;">Click to upload cover image</p>
                            <input type="file" name="thumbnail" id="thumbInput" style="display: none;" accept="image/*">
                        </div>
                    </div>

                    <div class="form-group" style="margin-bottom: 25px;">
                        <label>Description</label>
                        <textarea name="description" class="form-control" rows="4" placeholder="Briefly describe what students will learn..."></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary" style="width: 100%; padding: 15px; font-size: 1.1rem;">Create Course & Build Curriculum</button>
                </form>
            </div>
        </main>
    </div>
</body>
</html>
