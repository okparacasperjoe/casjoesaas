<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Course: <?= htmlspecialchars($course['title']) ?></title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        .builder-container { display: grid; grid-template-columns: 250px 1fr; gap: 30px; }
        .builder-main { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
        .section-block { background: #f8f9fa; border: 1px solid #e9ecef; border-radius: 8px; margin-bottom: 20px; overflow: hidden; }
        .section-header { padding: 15px; background: #eee; display: flex; justify-content: space-between; align-items: center; font-weight: bold; }
        .lesson-list { padding: 10px; }
        .lesson-item { 
            background: white; padding: 10px; margin-bottom: 8px; border-radius: 4px; border: 1px solid #ddd; 
            display: flex; justify-content: space-between; align-items: center;
        }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); align-items: center; justify-content: center; z-index: 1000; }
        .modal-content { background: white; padding: 30px; border-radius: 12px; width: 500px; max-width: 90%; }
        .hidden { display: none; }
    </style>
</head>
<body>
<div class="app-container">
    <aside class="sidebar">
        <div class="brand">
             <img src="/assets/casjoe_logo.png" alt="Casjoe Apps" style="height: 40px;">
        </div>
        <ul class="nav-menu">
            <li class="nav-item"><a href="/academy/instructor" class="nav-link"><ion-icon name="arrow-back-outline"></ion-icon> Back to Dashboard</a></li>
            <li class="nav-item"><a href="#" class="nav-link active"><ion-icon name="create-outline"></ion-icon> Edit Course</a></li>
            <li class="nav-item"><a href="/academy/course/<?= $course['id'] ?>" target="_blank" class="nav-link"><ion-icon name="eye-outline"></ion-icon> Preview</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <div class="top-bar">
            <h1>Editing: <?= htmlspecialchars($course['title']) ?></h1>
            <div>
                <?php if($course['status'] === 'draft'): ?>
                    <a href="/academy/instructor/publish/<?= $course['id'] ?>" class="btn">Publish Course</a>
                <?php else: ?>
                    <span class="badge" style="background: #2ed573; color: white; padding: 5px 12px; border-radius: 12px;">Published</span>
                <?php endif; ?>
            </div>
        </div>

        <div class="builder-main">
            <h3>Curriculum Builder</h3>
            <p style="margin-bottom: 20px; color: #666;">Organize your course into sections and lessons.</p>

            <!-- Sections Loop -->
            <?php foreach ($sections as $section): ?>
                <div class="section-block">
                    <div class="section-header">
                        <span><ion-icon name="folder-open-outline" style="vertical-align: middle;"></ion-icon> <?= htmlspecialchars($section['title']) ?></span>
                        <a href="/academy/instructor/section/delete/<?= $section['id'] ?>" onclick="return confirm('Delete section?')" style="color: #ff4757;"><ion-icon name="trash-outline"></ion-icon></a>
                    </div>
                    <div class="lesson-list">
                        <?php if(empty($section['lessons'])): ?>
                            <div style="text-align: center; padding: 10px; font-size: 0.9rem; color: #999;">No lessons yet.</div>
                        <?php else: ?>
                            <?php foreach ($section['lessons'] as $lesson): ?>
                                <div class="lesson-item">
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <ion-icon name="<?= $lesson['content_type'] == 'video' ? 'videocam' : ($lesson['content_type'] == 'pdf' ? 'document' : 'text') ?>-outline" style="color: var(--secondary);"></ion-icon>
                                        <div>
                                            <strong><?= htmlspecialchars($lesson['title']) ?></strong>
                                            <span style="font-size: 0.8rem; color: #888; margin-left: 5px; text-transform: uppercase;"><?= $lesson['content_type'] ?></span>
                                        </div>
                                    </div>
                                    <a href="/academy/instructor/lesson/delete/<?= $lesson['id'] ?>" onclick="return confirm('Delete lesson?')" style="color: #aaa; font-size: 1.2rem;"><ion-icon name="close-circle-outline"></ion-icon></a>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        
                        <button onclick="openLessonModal(<?= $section['id'] ?>)" class="btn" style="width: 100%; margin-top: 10px; background: transparent; border: 1px dashed #ccc; color: #666;">+ Add Lesson</button>
                    </div>
                </div>
            <?php endforeach; ?>

            <!-- Add Section Button -->
            <div style="margin-top: 20px; text-align: center;">
                 <form action="/academy/instructor/section/add" method="POST" style="display: inline-block;">
                     <input type="hidden" name="course_id" value="<?= $course['id'] ?>">
                     <input type="text" name="title" placeholder="New Section Title" required style="padding: 10px; border: 1px solid #ddd; border-radius: 5px; width: 300px;">
                     <button type="submit" class="btn">Add Section</button>
                 </form>
            </div>

        </div>
    </main>

    <!-- Add Lesson Modal -->
    <div id="lessonModal" class="modal">
        <div class="modal-content">
            <h3 style="margin-top: 0;">Add New Lesson</h3>
            <form action="/academy/instructor/lesson/add" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="course_id" value="<?= $course['id'] ?>">
                <input type="hidden" name="section_id" id="modalSectionId">
                
                <div class="form-group" style="margin-bottom: 15px;">
                    <label>Lesson Title</label>
                    <input type="text" name="title" required class="form-control" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                </div>

                <div class="form-group" style="margin-bottom: 15px;">
                    <label>Content Type</label>
                    <select name="type" id="lessonType" onchange="toggleInputs()" class="form-control" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                        <option value="text">Text Article</option>
                        <option value="video">Video Upload</option>
                        <option value="pdf">PDF Document</option>
                    </select>
                </div>

                <div id="input-text" class="type-input">
                    <label>Content</label>
                    <textarea name="content" rows="4" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;"></textarea>
                </div>

                <div id="input-file" class="type-input hidden">
                    <label>Upload File (Video/PDF)</label>
                    <input type="file" name="lesson_file">
                </div>

                 <div id="input-url" class="type-input hidden">
                    <label>Or Video URL (YouTube/Vimeo)</label>
                    <input type="text" name="video_url" class="form-control" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                </div>

                <div style="margin-top: 20px; display: flex; justify-content: flex-end; gap: 10px;">
                    <button type="button" onclick="closeModal()" class="btn" style="background: #ccc; color: #333;">Cancel</button>
                    <button type="submit" class="btn">Add Lesson</button>
                </div>
            </form>
        </div>
    </div>

</div>

<script>
    function openLessonModal(sectionId) {
        document.getElementById('modalSectionId').value = sectionId;
        document.getElementById('lessonModal').style.display = 'flex';
    }
    function closeModal() {
        document.getElementById('lessonModal').style.display = 'none';
    }
    function toggleInputs() {
        const type = document.getElementById('lessonType').value;
        document.querySelectorAll('.type-input').forEach(el => el.classList.add('hidden'));

        if(type === 'text') document.getElementById('input-text').classList.remove('hidden');
        if(type === 'video') {
            document.getElementById('input-file').classList.remove('hidden');
            document.getElementById('input-url').classList.remove('hidden');
        }
        if(type === 'pdf') document.getElementById('input-file').classList.remove('hidden');
    }
</script>

</body>
</html>
