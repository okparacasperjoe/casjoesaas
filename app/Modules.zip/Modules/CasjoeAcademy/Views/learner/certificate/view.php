<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Certificate of Completion | Casjoe Academy</title>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&family=Great+Vibes&family=Roboto:wght@300;400&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            background: #f0f0f0;
            font-family: 'Roboto', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        .certificate-container {
            background: #fff;
            width: 900px;
            padding: 40px;
            position: relative;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            text-align: center;
            border: 20px solid #000066; /* Casjoe Blue */
        }
        .inner-border {
            border: 5px solid #FFA600; /* Casjoe Amber */
            padding: 40px;
            height: 100%;
            box-sizing: border-box;
        }
        .header {
            font-family: 'Cinzel', serif;
            font-size: 3rem;
            color: #000066;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .sub-header {
            font-size: 1.2rem;
            color: #666;
            margin-bottom: 40px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .recipient {
            font-family: 'Great Vibes', cursive;
            font-size: 4rem;
            color: #333;
            margin: 20px 0;
            border-bottom: 2px solid #eee;
            display: inline-block;
            padding: 0 40px 10px;
        }
        .course-title {
            font-weight: bold;
            font-size: 1.5rem;
            color: #000066;
            margin: 20px 0 10px;
        }
        .description {
            font-size: 1.1rem;
            color: #555;
            line-height: 1.6;
            max-width: 700px;
            margin: 0 auto 50px;
        }
        .footer {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-top: 40px;
        }
        .signature {
            text-align: center;
        }
        .signature-line {
            width: 200px;
            border-top: 1px solid #333;
            margin-top: 50px;
            padding-top: 10px;
            font-weight: bold;
            font-size: 0.9rem;
            text-transform: uppercase;
        }
        .verify-code {
            font-size: 0.8rem;
            color: #999;
            margin-top: 40px;
        }
        @media print {
            body { background: none; }
            .certificate-container { box-shadow: none; width: 100%; border-width: 10px; }
        }
    </style>
</head>
<body>
    <div class="certificate-container">
        <div class="inner-border">
            <div class="header">Certificate of Completion</div>
            <div class="sub-header">This is to certify that</div>

            <div class="recipient"><?= htmlspecialchars($cert['student_name']) ?></div>

            <div class="description">
                has successfully completed the requirements for the course
                <div class="course-title"><?= htmlspecialchars($cert['course_title']) ?></div>
                demonstrating dedication, proficiency, and commitment to professional excellence.
            </div>

            <div class="footer">
                <div class="signature">
                    <div style="font-family: 'Great Vibes', cursive; font-size: 2rem; color: #000066;">Casjoe Academy</div>
                    <div class="signature-line">Casjoe Academy Director</div>
                </div>
                
                <div style="text-align: center;">
                    <img src="/assets/seal.png" alt="Seal" style="width: 100px; opacity: 0.8; display: block; margin: 0 auto;">
                    <div style="font-size: 0.9rem; color: #666; margin-top: 10px;"><?= date('F j, Y', strtotime($cert['issued_at'])) ?></div>
                </div>

                <div class="signature">
                     <!-- Real signature could go here -->
                    <div style="font-family: 'Great Vibes', cursive; font-size: 2rem; color: #000066;">Instructor</div>
                    <div class="signature-line">Course Instructor</div>
                </div>
            </div>

            <div class="verify-code">
                Certificate ID: <?= htmlspecialchars($cert['certificate_code']) ?><br>
                Verify at: <?= $_SERVER['HTTP_HOST'] ?>/academy/certificate/<?= htmlspecialchars($cert['certificate_code']) ?>
            </div>
        </div>
    </div>
    
    <script>
        // Auto-print prompt
        window.onload = function() {
            // setTimeout(() => window.print(), 1000);
        }
    </script>
</body>
</html>
