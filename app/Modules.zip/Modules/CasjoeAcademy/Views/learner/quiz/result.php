<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Assessment Result | Casjoe Academy</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
    <div class="app-container" style="justify-content: center; align-items: center; background: #f4f6f9;">
        
        <div class="card" style="width: 500px; text-align: center; padding: 40px;">
            <?php if ($passed): ?>
                <ion-icon name="checkmark-circle" style="font-size: 80px; color: green; margin-bottom: 20px;"></ion-icon>
                <h1 style="color: green; margin-bottom: 10px;">Passed!</h1>
                <p style="font-size: 1.2rem; color: #555;">Congratulations, you scored <strong><?= $score ?>%</strong>.</p>
                <p style="color: #666; margin-bottom: 30px;">You have successfully completed this assessment.</p>
                
                <a href="/academy/player/<?= $quizId ?>" class="btn btn-primary">Continue Learning</a>
            <?php else: ?>
                <ion-icon name="close-circle" style="font-size: 80px; color: red; margin-bottom: 20px;"></ion-icon>
                <h1 style="color: red; margin-bottom: 10px;">Failed</h1>
                <p style="font-size: 1.2rem; color: #555;">You scored <strong><?= $score ?>%</strong>.</p>
                <p style="color: #666; margin-bottom: 30px;">Don't worry, review the material and try again.</p>
                
                <a href="/academy/quiz/<?= $quizId ?>" class="btn btn-primary">Retake Quiz</a>
                <a href="/academy/player/<?= $quizId ?>" class="btn btn-secondary" style="margin-top: 10px; display: inline-block;">Back to Course</a>
            <?php endif; ?>
        </div>

    </div>
</body>
</html>
