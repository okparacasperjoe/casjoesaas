<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($quiz['title']) ?> | Casjoe Academy</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="app-container">
        <!-- Leaner Sidebar would go here, simplified for exam mode -->
        
        <main class="main-content" style="max-width: 800px; margin: 0 auto;">
            <div class="top-bar">
                <h1><?= htmlspecialchars($quiz['title']) ?></h1>
                <span class="badge">Passing Score: <?= $quiz['passing_score'] ?>%</span>
            </div>

            <form action="/academy/quiz/submit/<?= $quiz['id'] ?>" method="POST">
                
                <?php foreach ($questions as $index => $q): 
                    $options = json_decode($q['options']);
                ?>
                    <div class="card" style="margin-bottom: 20px;">
                        <h3><?= $index + 1 ?>. <?= htmlspecialchars($q['question_text']) ?></h3>
                        
                        <div class="question-options" style="margin-top: 15px;">
                            <?php foreach ($options as $optIndex => $option): ?>
                                <?php if (!empty($option)): ?>
                                    <label style="display: block; padding: 10px; border: 1px solid #eee; margin-bottom: 5px; border-radius: 4px; cursor: pointer;">
                                        <input type="radio" name="answers[<?= $q['id'] ?>]" value="<?= $optIndex ?>" required>
                                        <?= htmlspecialchars($option) ?>
                                    </label>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>

                <div style="text-align: center; margin-top: 30px;">
                    <button type="submit" class="btn btn-primary btn-lg">Submit Assessment</button>
                    <a href="/academy/player/<?= $quiz['course_id'] ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
            
        </main>
    </div>
</body>
</html>
