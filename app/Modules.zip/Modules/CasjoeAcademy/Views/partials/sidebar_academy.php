<div class="brand">
    <ion-icon name="school-outline" style="color: var(--secondary); font-size: 1.8rem;"></ion-icon>
    <span>Casjoe Academy</span>
</div>
<ul class="nav-menu">
    <li class="nav-item">
        <a href="/academy/business" class="nav-link <?= $active == 'academy_business' ? 'active' : '' ?>">
            <ion-icon name="business-outline"></ion-icon> Administration
        </a>
    </li>
    <li class="nav-item">
        <a href="/academy/business/marketplace" class="nav-link <?= $active == 'academy_market' ? 'active' : '' ?>">
            <ion-icon name="cart-outline"></ion-icon> Course Catalog
        </a>
    </li>
    <li class="nav-item">
        <a href="/academy/learn" class="nav-link <?= $active == 'academy_learn' ? 'active' : '' ?>">
            <ion-icon name="book-outline"></ion-icon> My Learning
        </a>
    </li>
    
    <li class="nav-item" style="margin-top: 10px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
        <span class="nav-label" style="font-size: 10px; text-transform: uppercase; color: #888; padding-left: 15px; letter-spacing: 1px;">Instructor</span>
    </li>
    <li class="nav-item">
        <a href="/academy/instructor" class="nav-link <?= $active == 'academy_instructor' ? 'active' : '' ?>">
            <ion-icon name="construct-outline"></ion-icon> Course Builder
        </a>
    </li>

    <li class="nav-item" style="margin-top: auto;">
        <a href="/dashboard" class="nav-link">
            <ion-icon name="arrow-back-outline"></ion-icon> Back to Apps
        </a>
    </li>
</ul>
