<?php

use App\Core\Router;
use App\Modules\CasjoeAcademy\Controllers\BusinessController;
use App\Modules\CasjoeAcademy\Controllers\LearnerController;

// Business Owner Routes (Tenant Admin)
Router::get('/academy', [BusinessController::class, 'dashboard']); // Default to business dash
Router::get('/academy/business', [BusinessController::class, 'dashboard']);
Router::get('/academy/business/marketplace', [BusinessController::class, 'marketplace']);
Router::post('/academy/business/buy', [BusinessController::class, 'buyLicense']);
Router::get('/academy/business/assign', [BusinessController::class, 'assignView']);
Router::post('/academy/business/assign', [BusinessController::class, 'assignStore']);

// Learner Routes (Staff)
Router::get('/academy/learn', [LearnerController::class, 'dashboard']);
Router::get('/academy/learn/complete/{lessonId}', [LearnerController::class, 'markComplete']); // Using GET for simplicity in links, ideally POST
Router::get('/academy/learn/{id}', [LearnerController::class, 'learn']);
Router::get('/academy/lesson/complete/{id}', [LearnerController::class, 'completeLesson']);
// Certificate Routes
use App\Modules\CasjoeAcademy\Controllers\CertificateController;
Router::post('/academy/certificate/generate/{courseId}', [CertificateController::class, 'generate']);
Router::get('/academy/certificate/{code}', [CertificateController::class, 'view']);

// Quiz Routes
use App\Modules\CasjoeAcademy\Controllers\QuizController;
Router::get('/academy/quiz/create/{courseId}', [QuizController::class, 'create']);
Router::post('/academy/quiz/store/{courseId}', [QuizController::class, 'store']);
Router::get('/academy/quiz/{id}', [QuizController::class, 'take']);
Router::post('/academy/quiz/submit/{id}', [QuizController::class, 'submit']);
Router::get('/academy/quiz/result/{id}', [QuizController::class, 'result']);

// Instructor Routes (Curriculum Builder)
use App\Modules\CasjoeAcademy\Controllers\InstructorController;

Router::get('/academy/instructor', [InstructorController::class, 'index']);
Router::get('/academy/instructor/create', [InstructorController::class, 'create']);
Router::post('/academy/instructor/store', [InstructorController::class, 'store']);
Router::get('/academy/instructor/edit/{id}', [InstructorController::class, 'edit']);
Router::post('/academy/instructor/section/add', [InstructorController::class, 'addSection']);
Router::post('/academy/instructor/lesson/add', [InstructorController::class, 'addLesson']);
Router::get('/academy/instructor/lesson/delete/{id}', [InstructorController::class, 'deleteLesson']);
Router::get('/academy/instructor/section/delete/{id}', [InstructorController::class, 'deleteSection']);
Router::get('/academy/instructor/publish/{id}', [InstructorController::class, 'publish']);

// Track Routes (Bundles)
use App\Modules\CasjoeAcademy\Controllers\TrackController;

Router::get('/academy/tracks', [TrackController::class, 'index']);
Router::get('/academy/tracks/create', [TrackController::class, 'create']);

// Public Academy Routes (Catalog & Enrollment)
use App\Modules\CasjoeAcademy\Controllers\AcademyController;

Router::get('/academy/catalog', [AcademyController::class, 'index']);
Router::get('/academy/course/{id}', [AcademyController::class, 'course']);
Router::get('/academy/enroll/{id}', [AcademyController::class, 'enroll']);
Router::post('/academy/enroll/process', [AcademyController::class, 'processEnrollment']);


