<?php

namespace App\Modules\CasjoeCloud\Controllers;

use App\Core\Database;
use App\Core\TenantContext;
use App\Core\SubscriptionManager;
use PDO;

class CloudController
{
    private $pdo;
    private $tenantId;
    private $storageRoot;

    public function __construct()
    {
        $this->tenantId = TenantContext::getTenantId();
        SubscriptionManager::requireActive($this->tenantId);
        $this->pdo = Database::getInstance()->getConnection();
        
        // Define storage root for this tenant
        $this->storageRoot = __DIR__ . '/../../../../storage/tenants/' . $this->tenantId . '/cloud/';
        if (!is_dir($this->storageRoot)) {
            mkdir($this->storageRoot, 0777, true);
        }
    }

    public function index()
    {
        $folderId = $_GET['folder'] ?? null;
        
        // Breadcrumb logic
        $breadcrumbs = [['id' => null, 'name' => 'Home']];
        if ($folderId) {
            $curr = $folderId;
            $path = [];
            while ($curr) {
                $stmt = $this->pdo->prepare("SELECT id, name, parent_id FROM cloud_folders WHERE id = ? AND tenant_id = ?");
                $stmt->execute([$curr, $this->tenantId]);
                $f = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$f) break;
                array_unshift($path, $f);
                $curr = $f['parent_id'];
            }
            $breadcrumbs = array_merge($breadcrumbs, $path);
        }

        // Fetch Folders
        $stmt = $this->pdo->prepare("SELECT * FROM cloud_folders WHERE parent_id " . ($folderId ? "= ?" : "IS NULL") . " AND tenant_id = ? ORDER BY name ASC");
        if ($folderId) $stmt->execute([$folderId, $this->tenantId]);
        else $stmt->execute([$this->tenantId]);
        $folders = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Fetch Files
        $stmt = $this->pdo->prepare("SELECT * FROM cloud_files WHERE folder_id " . ($folderId ? "= ?" : "IS NULL") . " AND tenant_id = ? ORDER BY uploaded_at DESC");
        if ($folderId) $stmt->execute([$folderId, $this->tenantId]);
        else $stmt->execute([$this->tenantId]);
        $files = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Calc total usage
        $stmt = $this->pdo->prepare("SELECT SUM(size_bytes) FROM cloud_files WHERE tenant_id = ?");
        $stmt->execute([$this->tenantId]);
        $usedBytes = $stmt->fetchColumn() ?: 0;
        $totalBytes = 20 * 1024 * 1024 * 1024; // 20GB limit

        require __DIR__ . '/../views/dashboard.php';
    }

    public function createFolder()
    {
        $name = $_POST['name'] ?? 'New Folder';
        $parentId = $_POST['parent_id'] ?: null;

        $stmt = $this->pdo->prepare("INSERT INTO cloud_folders (tenant_id, parent_id, name) VALUES (?, ?, ?)");
        $stmt->execute([$this->tenantId, $parentId, $name]);

        header('Location: ' . $_SERVER['HTTP_REFERER']);
    }

    public function upload()
    {
        if (!empty($_FILES['file']['name'])) {
            $folderId = $_POST['folder_id'] ?: null;
            $file = $_FILES['file'];
            
            // Generate safe name
            $name = $file['name'];
            $ext = pathinfo($name, PATHINFO_EXTENSION);
            $hashName = uniqid() . '.' . $ext;
            
            // Mock Upload (since we might not have permissions effectively on this simulated env, we try best effort)
            // Real path would be storage/tenants/{id}/cloud/{hashName}
            $target = $this->storageRoot . $hashName;
            
            if (move_uploaded_file($file['tmp_name'], $target)) {
                $stmt = $this->pdo->prepare("INSERT INTO cloud_files (tenant_id, folder_id, name, path, size_bytes, type) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$this->tenantId, $folderId, $name, $hashName, $file['size'], $file['type']]);
            }
        }
        header('Location: ' . $_SERVER['HTTP_REFERER']);
    }

    public function deleteFile()
    {
        $id = $_POST['id'];
        $stmt = $this->pdo->prepare("SELECT * FROM cloud_files WHERE id = ? AND tenant_id = ?");
        $stmt->execute([$id, $this->tenantId]);
        $file = $stmt->fetch();

        if ($file) {
            $path = $this->storageRoot . $file['path'];
            if (file_exists($path)) unlink($path);
            
            $stmt = $this->pdo->prepare("DELETE FROM cloud_files WHERE id = ?");
            $stmt->execute([$id]);
        }
        header('Location: ' . $_SERVER['HTTP_REFERER']);
    }
}
