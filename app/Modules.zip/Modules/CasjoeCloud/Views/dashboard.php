<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Casjoe Cloud | Secure Storage</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        .breadcrumbs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            font-size: 1.1rem;
        }
        .breadcrumb-item {
            color: var(--text-muted);
            text-decoration: none;
        }
        .breadcrumb-item:last-child {
            color: var(--primary);
            font-weight: bold;
        }
        .file-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 20px;
        }
        .file-card {
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            transition: all 0.2s;
            position: relative;
            cursor: pointer;
        }
        .file-card:hover {
            transform: translateY(-3px);
            background: rgba(255,255,255,0.1);
        }
        .file-icon {
            font-size: 3rem;
            color: var(--secondary);
            margin-bottom: 10px;
        }
        .file-name {
            font-size: 0.9rem;
            word-break: break-all;
            color: var(--text-color);
        }
        .folder-icon {
            color: #ffd700;
        }
        .usage-bar {
            height: 6px;
            background: rgba(255,255,255,0.1);
            border-radius: 3px;
            overflow: hidden;
            margin-top: 5px;
        }
        .usage-fill {
            height: 100%;
            background: var(--secondary);
        }
        .context-menu {
            position: absolute;
            top: 10px;
            right: 10px;
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: 5px;
            padding: 5px;
            display: none;
        }
        .file-card:hover .context-menu {
            display: block;
        }
    </style>
</head>
<body>
<?php require_once dirname(__DIR__, 3) . '/core/Views/partials/mobile_nav.php'; ?>
<div class="app-container">
    <aside class="sidebar">
        <div class="brand">
            <ion-icon name="cloud-upload-outline" style="color: var(--secondary); font-size: 1.8rem;"></ion-icon>
            <span>Casjoe Cloud</span>
        </div>
        
        <div style="padding: 20px;">
            <button class="btn" style="width: 100%;" onclick="document.getElementById('uploadInput').click()">
                <ion-icon name="add-circle"></ion-icon> Upload File
            </button>
            <form id="uploadForm" action="/cloud/upload" method="POST" enctype="multipart/form-data" style="display:none;">
                <input type="hidden" name="folder_id" value="<?= $folderId ?>">
                <input type="file" id="uploadInput" name="file" onchange="document.getElementById('uploadForm').submit()">
            </form>
            
            <button class="btn" style="width: 100%; margin-top: 10px; background: transparent; border: 1px solid var(--glass-border); color: var(--text-color);" onclick="createFolder()">
                <ion-icon name="folder-open"></ion-icon> New Folder
            </button>
        </div>

        <div style="padding: 20px; color: var(--text-muted); font-size: 0.8rem;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                <span>Storage Used</span>
                <span><?= round($usedBytes / 1024 / 1024, 2) ?> MB / 20 GB</span>
            </div>
            <div class="usage-bar">
                <div class="usage-fill" style="width: <?= min(100, ($usedBytes / $totalBytes) * 100) ?>%"></div>
            </div>
        </div>

        <ul class="nav-menu">
            <li class="nav-item"><a href="/cloud" class="nav-link active"><ion-icon name="folder"></ion-icon> My Files</a></li>
            <li class="nav-item"><a href="#" class="nav-link"><ion-icon name="share-social"></ion-icon> Shared</a></li>
            <li class="nav-item"><a href="#" class="nav-link"><ion-icon name="trash"></ion-icon> Trash</a></li>
            <li class="nav-item"><a href="/dashboard" class="nav-link"><ion-icon name="arrow-back"></ion-icon> Back to Apps</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <div class="top-bar">
            <h2>My Files</h2>
        </div>

        <div class="breadcrumbs">
            <?php foreach ($breadcrumbs as $crumb): ?>
                <a href="/cloud?folder=<?= $crumb['id'] ?>" class="breadcrumb-item">
                    <?= htmlspecialchars($crumb['name']) ?> /
                </a>
            <?php endforeach; ?>
        </div>

        <div class="file-grid">
            <!-- Folders -->
            <?php foreach ($folders as $folder): ?>
                <div class="file-card" onclick="window.location.href='/cloud?folder=<?= $folder['id'] ?>'">
                    <ion-icon name="folder" class="file-icon folder-icon"></ion-icon>
                    <div class="file-name"><?= htmlspecialchars($folder['name']) ?></div>
                </div>
            <?php endforeach; ?>

            <!-- Files -->
            <?php foreach ($files as $file): ?>
                <div class="file-card">
                    <ion-icon name="document-text" class="file-icon"></ion-icon>
                    <div class="file-name"><?= htmlspecialchars($file['name']) ?></div>
                    <div style="font-size: 0.7rem; color: var(--text-muted); margin-top: 5px;">
                        <?= round($file['size_bytes'] / 1024, 2) ?> KB
                    </div>
                    
                    <form action="/cloud/delete" method="POST" class="context-menu" onsubmit="return confirm('Delete this file?')">
                         <input type="hidden" name="id" value="<?= $file['id'] ?>">
                        <button type="submit" style="background: none; border: none; color: red; cursor: pointer;">
                            <ion-icon name="trash"></ion-icon>
                        </button>
                    </form>
                </div>
            <?php endforeach; ?>
            
            <?php if(empty($folders) && empty($files)): ?>
                <div style="grid-column: 1/-1; text-align: center; color: var(--text-muted); padding: 50px;">
                    <ion-icon name="cloud-upload" style="font-size: 4rem; opacity: 0.5;"></ion-icon>
                    <p>This folder is empty. Upload items to get started.</p>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<script>
    function createFolder() {
        const name = prompt("Folder Name:");
        if (name) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '/cloud/folder/create';
            
            const input = document.createElement('input');
            input.name = 'name';
            input.value = name;
            form.appendChild(input);

            const parent = document.createElement('input');
            parent.type = 'hidden';
            parent.name = 'parent_id';
            parent.value = '<?= $folderId ?? '' ?>';
            form.appendChild(parent);

            document.body.appendChild(form);
            form.submit();
        }
    }
</script>
</body>
</html>
