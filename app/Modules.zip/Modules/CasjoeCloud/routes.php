<?php

use App\Core\Router;
use App\Modules\CasjoeCloud\Controllers\CloudController;

Router::get('/cloud', [CloudController::class, 'index']);
Router::post('/cloud/upload', [CloudController::class, 'upload']);
Router::post('/cloud/folder/create', [CloudController::class, 'createFolder']);
Router::post('/cloud/delete', [CloudController::class, 'deleteFile']);
