<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ERP Dashboard | Casjoe ERP</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        .module-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        .module-card {
            background: #ffffff;
            border: 1px solid var(--glass-border);
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            transition: transform 0.2s;
            cursor: pointer;
            text-decoration: none;
            color: #333;
            display: block;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }
        .module-card:hover {
            transform: translateY(-5px);
            background: #ffffff;
            box-shadow: 0 8px 15px rgba(0,0,0,0.1);
        }
        .module-icon {
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 20px;
        }
        .module-title {
            font-size: 1.2rem;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .module-stat {
            font-size: 0.9rem;
            color: var(--secondary);
        }
    </style>
</head>
<body>
    <?php require __DIR__ . '/layout/mobile_nav.php'; ?>
<div class="app-container">
    <?php require __DIR__ . '/layout/sidebar.php'; ?>

    <main class="main-content">
        <div class="top-bar">
            <h2>Enterprise Resource Planning</h2>
        </div>

        <div class="module-grid">
            <!-- Revenue Card -->
            <a href="/erp/finance" class="module-card">
                <ion-icon name="trending-up-outline" class="module-icon" style="color: #2e7d32;"></ion-icon>
                <div class="module-title">Revenue</div>
                <div class="module-stat" style="font-size: 1.5rem; font-weight: bold; color: #333;">
                    $<?= number_format($stats['revenue'], 2) ?>
                </div>
                <div style="font-size: 0.8rem; color: #666; margin-top: 5px;">Total Income</div>
            </a>

            <!-- Goals Card -->
             <div class="module-card" style="cursor: default; text-align: left;">
                <div class="module-title" style="text-align: center; margin-bottom: 20px;">
                    <ion-icon name="flag-outline" style="vertical-align: middle; color: #ef5350;"></ion-icon> Business Goals
                </div>
                <?php foreach($goals as $goal): 
                    $percent = $goal['target'] > 0 ? min(100, ($goal['current'] / $goal['target']) * 100) : 0;
                ?>
                <div style="margin-bottom: 15px;">
                    <div style="display: flex; justify-content: space-between; font-size: 0.85rem; margin-bottom: 5px;">
                        <span><?= $goal['title'] ?></span>
                        <span><?= $goal['unit'] . number_format($goal['current']) ?> / <?= $goal['unit'] . number_format($goal['target']) ?></span>
                    </div>
                    <div style="background: #eee; height: 6px; border-radius: 3px; overflow: hidden;">
                        <div style="background: var(--primary); width: <?= $percent ?>%; height: 100%;"></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Kanban / Project Summary -->
            <a href="/erp/projects/kanban" class="module-card">
                <ion-icon name="grid-outline" class="module-icon" style="color: #f57c00;"></ion-icon>
                <div class="module-title">Kanban Board</div>
                <div class="module-stat"><?= $stats['pending_tasks'] ?> Pending Tasks</div>
                <div style="font-size: 0.8rem; color: #666; margin-top: 5px;">
                    <?= $stats['total_tasks'] ?> Total Tasks
                </div>
            </a>

            <a href="/erp/hr" class="module-card">
                <ion-icon name="people-outline" class="module-icon"></ion-icon>
                <div class="module-title">Human Resources</div>
                <div class="module-stat"><?= $stats['employees'] ?> Active Employees</div>
            </a>
            
            <a href="/erp/crm" class="module-card">
                <ion-icon name="people-circle-outline" class="module-icon"></ion-icon>
                <div class="module-title">CRM</div>
                <div class="module-stat"><?= $stats['customers'] ?> Customers</div>
            </a>

             <a href="/erp/inventory" class="module-card">
                <ion-icon name="cube-outline" class="module-icon"></ion-icon>
                <div class="module-title">Inventory</div>
                <div class="module-stat">Stock Management</div>
            </a>
        </div>

    </main>
</div>
</body>
</html>