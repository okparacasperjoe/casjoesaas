<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payslip #<?= $payroll['id'] ?> | Casjoe ERP</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        body { font-family: 'Segoe UI', sans-serif; }
        .payslip-container {
            background: white;
            padding: 40px;
            max-width: 800px;
            margin: auto;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            border-radius: 8px;
        }
        .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 40px; border-bottom: 2px solid #eee; padding-bottom: 20px; }
        .payslip-title { text-align: right; }
        .payslip-title h2 { margin: 0; color: #333; letter-spacing: 2px; }
        
        .employee-details { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; background: #f8f9fa; padding: 20px; border-radius: 6px; margin-bottom: 30px; }
        .detail-group label { display: block; font-size: 0.8rem; color: #888; text-transform: uppercase; margin-bottom: 4px; }
        .detail-group div { font-weight: 600; color: #333; }

        .earnings-deductions { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-bottom: 30px; }
        .section-table { width: 100%; border-collapse: collapse; }
        .section-table th { text-align: left; border-bottom: 2px solid #eee; padding: 8px 0; color: #666; font-size: 0.9rem; }
        .section-table td { padding: 10px 0; border-bottom: 1px solid #f5f5f5; color: #444; }
        .section-table .amount { text-align: right; font-family: monospace; font-size: 1.1em; }
        
        .totals { background: #333; color: white; padding: 20px; border-radius: 6px; display: flex; justify-content: flex-end; }
        .total-row { display: flex; align-items: center; gap: 30px; }
        .total-row span:first-child { text-transform: uppercase; letter-spacing: 1px; font-size: 0.9rem; opacity: 0.9; }
        .net-pay { font-size: 2rem; font-weight: bold; }
        
        @media print {
            body { background: white; }
            .no-print { display: none !important; }
            .payslip-container { box-shadow: none; padding: 0; }
        }
    </style>
</head>
<body style="background: #f4f6f9;">

<div class="no-print" style="max-width: 800px; margin: 20px auto; display: flex; gap: 10px;">
    <?php
    $backUrl = '/erp/payroll';
    if(isset($_GET['source']) && $_GET['source'] == 'portal') {
        $backUrl = '/erp/my-portal';
    }
    ?>
    <a href="<?= $backUrl ?>" class="btn btn-outline">&larr; Back</a>
    <div style="flex:1"></div>
    <button onclick="window.print()" class="btn btn-primary"><ion-icon name="print-outline"></ion-icon> Print Payslip</button>
</div>

<div class="payslip-container">
    <div class="header">
        <div class="company-info">
            <img src="/assets/casjoe_logo.png" alt="Logo" style="height: 50px; margin-bottom: 10px;">
            <div>Casjoe Tech Ltd</div>
            <div style="font-size: 0.9rem; color: #666;">123 Business Road, Lagos, NG</div>
        </div>
        <div class="payslip-title">
            <h2>PAYSLIP</h2>
            <span>#<?= str_pad($payroll['id'], 6, '0', STR_PAD_LEFT) ?></span>
            <br>
            <span style="display: block; margin-top: 5px;">
                Date: <?= date('M d, Y', strtotime($payroll['payment_date'])) ?>
            </span>
        </div>
    </div>

    <div class="employee-details">
        <div class="detail-group">
            <label>Employee Name</label>
            <div><?= htmlspecialchars($payroll['first_name'] . ' ' . $payroll['last_name']) ?></div>
        </div>
        <div class="detail-group">
            <label>Designation</label>
            <div><?= htmlspecialchars($payroll['job_title'] ?? 'Employee') ?></div>
        </div>
        <div class="detail-group">
            <label>Employee ID</label>
            <div>EMP-<?= str_pad($payroll['employee_id'], 4, '0', STR_PAD_LEFT) ?></div>
        </div>
        <div class="detail-group">
            <label>Pay Period</label>
            <div><?= date('M d', strtotime($payroll['pay_period_start'])) ?> - <?= date('M d, Y', strtotime($payroll['pay_period_end'])) ?></div>
        </div>
    </div>

    <div class="earnings-deductions">
        <div>
            <h4 style="margin: 0 0 10px 0; color: #2e7d32; text-transform: uppercase; font-size: 0.8rem; letter-spacing: 1px;">Earnings</h4>
            <table class="section-table">
                <tr><th>Description</th><th style="text-align: right;">Amount</th></tr>
                <?php 
                $totalEarnings = 0;
                foreach($items as $item): 
                    if($item['type'] == 'earning'):
                        $totalEarnings += $item['amount'];
                ?>
                <tr>
                    <td><?= htmlspecialchars($item['description']) ?></td>
                    <td class="amount">₦<?= number_format($item['amount'], 2) ?></td>
                </tr>
                <?php endif; endforeach; ?>
                <tr style="font-weight: bold; border-top: 1px solid #ddd;">
                    <td style="padding-top: 10px;">Total Earnings</td>
                    <td class="amount" style="padding-top: 10px;">₦<?= number_format($totalEarnings, 2) ?></td>
                </tr>
            </table>
        </div>
        
        <div>
            <h4 style="margin: 0 0 10px 0; color: #c62828; text-transform: uppercase; font-size: 0.8rem; letter-spacing: 1px;">Deductions</h4>
            <table class="section-table">
                <tr><th>Description</th><th style="text-align: right;">Amount</th></tr>
                <?php 
                $totalDeductions = 0;
                foreach($items as $item): 
                    if($item['type'] == 'deduction'):
                        $totalDeductions += $item['amount'];
                ?>
                <tr>
                    <td><?= htmlspecialchars($item['description']) ?></td>
                    <td class="amount">₦<?= number_format($item['amount'], 2) ?></td>
                </tr>
                <?php endif; endforeach; ?>
                 <tr style="font-weight: bold; border-top: 1px solid #ddd;">
                    <td style="padding-top: 10px;">Total Deductions</td>
                    <td class="amount" style="padding-top: 10px;">₦<?= number_format($totalDeductions, 2) ?></td>
                </tr>
            </table>
        </div>
    </div>

    <div class="totals">
        <div class="total-row">
            <span>Net Pay</span>
            <span class="net-pay">₦<?= number_format($payroll['net_pay'], 2) ?></span>
        </div>
    </div>

     <div style="margin-top: 40px; font-size: 0.8rem; color: #999; text-align: center;">
        This is a system-generated payslip.
    </div>

</div>

</body>
</html>
