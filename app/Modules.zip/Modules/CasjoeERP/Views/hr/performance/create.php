<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>New Performance Review | Casjoe ERP</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
<?php require __DIR__ . '/../../../layout/mobile_nav.php'; ?>
<div class="app-container">
    <?php require __DIR__ . '/../../layout/sidebar.php'; ?>

    <main class="main-content">
        <div class="top-bar">
            <h2>New Performance Review</h2>
            <a href="/erp/performance" class="btn btn-outline" style="background: rgba(255, 255, 255, 0.1); border: 1px solid rgba(255, 255, 255, 0.2); color: #fff;">Cancel</a>
        </div>

        <div class="card" style="max-width: 700px; margin: 0 auto; background: rgba(30, 30, 30, 0.8); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.1);">
            <form action="/erp/performance/store" method="POST">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label style="color: #aaa; font-size: 0.9rem;">Select Employee</label>
                        <select name="employee_id" class="form-control" required style="background: rgba(255, 255, 255, 0.05); color: #fff; border-color: rgba(255, 255, 255, 0.1);">
                            <option value="">Choose...</option>
                            <?php foreach ($employees as $e): ?>
                                <option value="<?= $e['id'] ?>"><?= htmlspecialchars($e['first_name'] . ' ' . $e['last_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label style="color: #aaa; font-size: 0.9rem;">Review Date</label>
                        <input type="date" name="review_date" class="form-control" required value="<?= date('Y-m-d') ?>" style="background: rgba(255, 255, 255, 0.05); color: #fff; border-color: rgba(255, 255, 255, 0.1);">
                    </div>
                </div>

                <div class="form-group">
                    <label style="color: #aaa; font-size: 0.9rem;">Overall Rating</label>
                    <select name="rating" class="form-control" required style="background: rgba(255, 255, 255, 0.05); color: #fff; border-color: rgba(255, 255, 255, 0.1);">
                        <option value="5" style="color: #000;">5 - Exceptional Performance</option>
                        <option value="4" style="color: #000;">4 - Exceeds Expectations</option>
                        <option value="3" style="color: #000;" selected>3 - Fully Successful</option>
                        <option value="2" style="color: #000;">2 - Partially Successful</option>
                        <option value="1" style="color: #000;">1 - Does Not Meet Expectations</option>
                    </select>
                </div>

                <div class="form-group">
                    <label style="color: #aaa; font-size: 0.9rem;">Detailed Feedback & Comments</label>
                    <textarea name="comments" class="form-control" rows="6" placeholder="Provide specific examples of performance..." style="background: rgba(255, 255, 255, 0.05); color: #fff; border-color: rgba(255, 255, 255, 0.1); border-radius: 8px;"></textarea>
                </div>

                <div style="text-align: right; margin-top: 30px;">
                    <button type="submit" class="btn btn-primary" style="padding: 12px 40px; border-radius: 8px; font-weight: bold; background: #ffa600; color: #000;">
                        Submit Performance Review
                    </button>
                </div>
            </form>
        </div>
    </main>
</div>
</body>
</html>
