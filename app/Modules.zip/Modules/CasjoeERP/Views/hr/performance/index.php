<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Performance Reviews | Casjoe ERP</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        .star-rating { color: #ffa600; font-size: 1.1rem; }
        .rating-badge { padding: 4px 8px; border-radius: 4px; font-size: 0.8rem; font-weight: bold; }
        .rating-5 { background: rgba(46, 213, 115, 0.2); color: #2ed573; }
        .rating-4 { background: rgba(46, 213, 115, 0.2); color: #2ed573; }
        .rating-3 { background: rgba(255, 166, 0, 0.2); color: #ffa502; }
        .rating-2 { background: rgba(239, 83, 80, 0.2); color: #ef5350; }
        .rating-1 { background: rgba(239, 83, 80, 0.2); color: #ef5350; }
    </style>
</head>
<body>
<?php require __DIR__ . '/../../layout/mobile_nav.php'; ?>
<div class="app-container">
    <?php require __DIR__ . '/../../layout/sidebar.php'; ?>

    <main class="main-content">
        <div class="top-bar">
            <h2>Performance Reviews</h2>
            <a href="/erp/performance/create" class="btn"><ion-icon name="add-outline"></ion-icon> New Review</a>
        </div>

        <div class="card">
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Employee</th>
                            <th>Rating</th>
                            <th>Summary Feedback</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reviews as $r): ?>
                        <tr>
                            <td><?= date('M d, Y', strtotime($r['review_date'])) ?></td>
                            <td style="font-weight: 500;"><?= htmlspecialchars($r['first_name'] . ' ' . $r['last_name']) ?></td>
                            <td>
                                <div class="star-rating">
                                    <?php for($i=1; $i<=5; $i++): ?>
                                        <ion-icon name="<?= $i <= $r['rating'] ? 'star' : 'star-outline' ?>"></ion-icon>
                                    <?php endfor; ?>
                                </div>
                            </td>
                            <td style="color: #bbb;"><?= htmlspecialchars(substr($r['comments'], 0, 60)) ?><?= strlen($r['comments']) > 60 ? '...' : '' ?></td>
                            <td>
                                <button class="btn btn-sm btn-outline" style="padding: 4px 10px; font-size: 0.8rem; background: rgba(255,255,255,0.05); color: #fff; border: 1px solid rgba(255,255,255,0.1);" onclick="alert('Detailed view coming soon!')">View</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($reviews)): ?>
                            <tr><td colspan="5" style="text-align: center; color: #888;">No performance reviews found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>
</body>
</html>
