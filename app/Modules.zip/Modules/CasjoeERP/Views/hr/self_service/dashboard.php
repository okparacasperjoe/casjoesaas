<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Portal | Casjoe ERP</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
<?php require __DIR__ . '/../../layout/mobile_nav.php'; ?>
<div class="app-container">
    <?php require __DIR__ . '/../../layout/sidebar.php'; ?>
    <main class="main-content">

<div class="content-header" style="margin-bottom: 30px;">
    <h1>My Portal</h1>
    <div>
        <a href="/erp/my-portal/request-leave" class="btn btn-primary" style="margin-right: 10px;">Request Time Off</a>
        <a href="/erp/my-portal/profile" class="btn btn-outline">My Profile</a>
    </div>
</div>

<!-- Stats Cards -->
<div class="module-grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); margin-bottom: 30px;">
    <div class="module-card" style="text-align: left; padding: 20px;">
        <div style="color: #666; font-size: 0.9rem; margin-bottom: 5px;">Leave Balance</div>
        <div style="font-size: 2rem; font-weight: bold; color: var(--primary);"><?= $leaveBalance ?> Days</div>
        <div style="font-size: 0.8rem; color: #888;">Annual Quota</div>
    </div>
    <div class="module-card" style="text-align: left; padding: 20px;">
        <div style="color: #666; font-size: 0.9rem; margin-bottom: 5px;">Next Payday</div>
        <div style="font-size: 1.5rem; font-weight: bold; color: #333;"><?= date('M d', strtotime('last day of this month')) ?></div>
        <div style="font-size: 0.8rem; color: #888;">Estimated</div>
    </div>
    <div class="module-card" style="text-align: left; padding: 20px;">
        <div style="color: #666; font-size: 0.9rem; margin-bottom: 5px;">Status</div>
        <div style="font-size: 1.5rem; font-weight: bold; color: #4caf50;">Active</div>
        <div style="font-size: 0.8rem; color: #888;">Employee</div>
    </div>
</div>

<div class="card mb-4">
    <div style="display: flex; align-items: start; gap: 20px;">
        <div style="width: 80px; height: 80px; background: #eee; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 2rem; color: #888;">
            <ion-icon name="person"></ion-icon>
        </div>
        <div style="flex: 1;">
            <h2 style="margin: 0; font-size: 1.4rem;"><?= htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) ?></h2>
            <p style="margin: 5px 0; color: #666;"><?= htmlspecialchars($employee['position'] ?? 'Employee') ?> &bull; <?= htmlspecialchars($employee['department'] ?? 'General') ?></p>
            <div style="margin-top: 10px; font-size: 0.9rem; color: #555;">
                <span style="margin-right: 20px;"><ion-icon name="mail-outline" style="vertical-align: middle;"></ion-icon> <?= htmlspecialchars($employee['email']) ?></span>
                <span><ion-icon name="call-outline" style="vertical-align: middle;"></ion-icon> <?= htmlspecialchars($employee['phone'] ?? 'N/A') ?></span>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Attendance -->
    <div class="col-md-6 mb-4">
        <div class="card h-100">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <h3 style="margin: 0; font-size: 1.1rem;">Recent Attendance</h3>
                <button class="btn btn-sm btn-outline">Check In</button>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($attendance as $att): ?>
                        <tr>
                            <td><?= date('M d', strtotime($att['check_in'])) ?></td>
                            <td><span class="badge badge-success">Present</span></td>
                            <td><?= date('H:i', strtotime($att['check_in'])) ?> - <?= $att['check_out'] ? date('H:i', strtotime($att['check_out'])) : '...' ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($attendance)): ?>
                        <tr><td colspan="3" style="text-align: center; color: #999;">No recent records.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Payslips -->
    <div class="col-md-6 mb-4">
        <div class="card h-100">
            <h3 style="margin: 0 0 15px 0; font-size: 1.1rem;">Recent Payslips</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Period</th>
                        <th>Net Pay</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($payslips as $pay): ?>
                        <tr>
                            <td><?= date('M Y', strtotime($pay['pay_period_end'])) ?></td>
                            <td>$<?= number_format($pay['net_pay'], 2) ?></td>
                            <td><a href="/erp/payroll/show?id=<?= $pay['id'] ?>&source=portal" target="_blank" class="btn btn-sm btn-outline" style="padding: 2px 8px; font-size: 0.8rem;"><ion-icon name="download-outline"></ion-icon></a></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($payslips)): ?>
                        <tr><td colspan="3" style="text-align: center; color: #999;">No payslips yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card">
    <h3 style="margin: 0 0 15px 0; font-size: 1.1rem;">Upcoming Leave</h3>
    <table class="table">
        <thead>
            <tr>
                <th>Type</th>
                <th>Dates</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($leaves as $leave): ?>
                <tr>
                    <td><?= htmlspecialchars($leave['leave_type']) ?></td>
                    <td><?= date('M d', strtotime($leave['start_date'])) ?> - <?= date('M d', strtotime($leave['end_date'])) ?></td>
                    <td>
                        <?php 
                        $badgeClass = 'badge-info';
                        if($leave['status'] == 'approved') $badgeClass = 'badge-success';
                        if($leave['status'] == 'rejected') $badgeClass = 'badge-danger';
                        ?>
                        <span class="badge <?= $badgeClass ?>"><?= ucfirst($leave['status']) ?></span>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($leaves)): ?>
                <tr><td colspan="3" style="text-align: center; color: #999;">No upcoming leave booked.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

    </main>
</div>
</body>
</html>
