<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Profile | Casjoe ERP</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
<div class="app-container">
    <?php require __DIR__ . '/../../layout/sidebar.php'; ?>
    <main class="main-content">
        <div class="top-bar">
            <h2>My Profile</h2>
            <a href="/erp/my-portal" class="btn" style="background: #666;">Back</a>
        </div>

        <div class="card" style="max-width: 800px; margin: auto;">
             <div style="text-align: center; margin-bottom: 30px;">
                <div style="width: 100px; height: 100px; background: #eee; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 3rem; color: #888; margin-bottom: 10px;">
                    <ion-icon name="person"></ion-icon>
                </div>
                <h2><?= htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) ?></h2>
                <p style="color: #666;"><?= htmlspecialchars($employee['position']) ?></p>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label>Email</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($employee['email']) ?>" readonly>
                </div>
                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($employee['phone']) ?>" readonly>
                </div>
                 <div class="form-group">
                    <label>Department</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($employee['department'] ?? 'General') ?>" readonly>
                </div>
                <div class="form-group">
                    <label>Date Joined</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($employee['date_joined']) ?>" readonly>
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <textarea class="form-control" readonly><?= htmlspecialchars($employee['address'] ?? '') ?></textarea>
                </div>
                 <div class="form-group">
                    <label>Emergency Contact</label>
                    <input type="text" class="form-control" value="Not set" readonly>
                </div>
            </div>
            
            <div style="margin-top: 30px; text-align: right;">
                <button class="btn btn-primary" onclick="alert('Update feature coming soon!')">Request Profile Update</button>
            </div>
        </div>
    </main>
</div>
</body>
</html>
