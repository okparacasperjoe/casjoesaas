<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Request Leave | Casjoe ERP</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
<div class="app-container">
    <?php require __DIR__ . '/../../layout/sidebar.php'; ?>
    <main class="main-content">
        <div class="top-bar">
            <h2>Request Time Off</h2>
            <a href="/erp/my-portal" class="btn" style="background: #666;">Cancel</a>
        </div>

        <div class="card" style="max-width: 600px; margin: auto;">
            <form method="POST" action="/erp/leave/store">
                <input type="hidden" name="employee_id" value="<?= $employee['id'] ?>">
                <input type="hidden" name="source" value="portal">
                
                <div class="form-group">
                    <label>Leave Type</label>
                    <select name="leave_type" class="form-control" required>
                        <option value="annual">Annual Leave</option>
                        <option value="sick">Sick Leave</option>
                        <option value="unpaid">Unpaid Leave</option>
                        <option value="maternity">Maternity/Paternity</option>
                    </select>
                </div>

                <div class="row">
                    <div class="col-md-6 form-group">
                        <label>Start Date</label>
                        <input type="date" name="start_date" class="form-control" required>
                    </div>
                    <div class="col-md-6 form-group">
                        <label>End Date</label>
                        <input type="date" name="end_date" class="form-control" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Reason (Optional)</label>
                    <textarea name="reason" class="form-control" rows="3"></textarea>
                </div>

                <div class="form-group" style="margin-top: 20px;">
                    <button type="submit" class="btn" style="width: 100%;">Submit Request</button>
                    <p style="text-align: center; margin-top: 10px; font-size: 0.8rem; color: #888;">
                        Your request will be sent to your manager for approval.
                    </p>
                </div>
            </form>
        </div>
    </main>
</div>
</body>
</html>
