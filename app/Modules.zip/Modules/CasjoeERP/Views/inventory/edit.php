<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Item | Casjoe ERP</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<div class="app-container">
    <?php require __DIR__ . '/../layout/sidebar.php'; ?>

    <main class="main-content">
        <h2>Edit Inventory Item</h2>
        
        <div class="card" style="max-width: 600px;">
            <form action="/erp/inventory/update" method="POST">
                <input type="hidden" name="id" value="<?= $item['id'] ?>">
                
                <div class="form-group">
                    <label>Product Name</label>
                    <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($item['name']) ?>" required>
                </div>

                <div class="form-group">
                    <label>SKU (Stock Keeping Unit)</label>
                    <input type="text" name="sku" class="form-control" value="<?= htmlspecialchars($item['sku']) ?>" required>
                </div>

                <div class="form-group">
                    <label>Unit Price</label>
                    <input type="number" step="0.01" name="unit_price" class="form-control" value="<?= htmlspecialchars($item['unit_price']) ?>" required>
                </div>

                <div class="form-group">
                    <label>Stock Quantity</label>
                    <input type="number" name="stock_quantity" class="form-control" value="<?= htmlspecialchars($item['stock_quantity']) ?>" required>
                </div>

                <div class="form-actions">
                    <a href="/erp/inventory" class="btn btn-outline">Cancel</a>
                    <button type="submit" class="btn btn-primary">Update Item</button>
                </div>
            </form>
        </div>
    </main>
</div>
</body>
</html>
