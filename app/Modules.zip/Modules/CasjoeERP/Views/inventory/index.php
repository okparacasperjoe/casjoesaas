<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory | Casjoe ERP</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        .stock-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        .stock-ok { background: #e8f5e9; color: #2e7d32; }
        .stock-low { background: #fff3e0; color: #ef6c00; }
        .stock-out { background: #ffebee; color: #c62828; }
        
        .action-icon {
            color: #666;
            font-size: 1.2rem;
            margin-left: 10px;
            cursor: pointer;
            text-decoration: none;
        }
        .action-icon:hover { color: #333; }
        .delete-btn { color: #ef5350; border: none; background: none; padding: 0; cursor: pointer; }
    </style>
</head>
<body>
<div class="app-container">
    <?php require __DIR__ . '/../layout/sidebar.php'; ?>

    <main class="main-content">
        <div class="top-bar">
            <h2>Inventory Management</h2>
            <div class="user-menu">
                <a href="/erp/inventory/create" class="btn btn-primary">
                    <ion-icon name="add-outline"></ion-icon> Add New Item
                </a>
            </div>
        </div>

        <div class="card">
            <table class="data-table">
                <thead>
                    <tr>
                        <th width="50">#</th>
                        <th>Product Name</th>
                        <th>SKU</th>
                        <th style="text-align: right;">Price</th>
                        <th style="text-align: center;">Stock</th>
                        <th>Status</th>
                        <th style="text-align: right;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($items)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 30px; color: #888;">
                            No inventory items found. Add your first product!
                        </td>
                    </tr>
                    <?php else: foreach ($items as $index => $item): 
                        $stockClass = 'stock-ok';
                        $statusText = 'In Stock';
                        if ($item['stock_quantity'] == 0) {
                            $stockClass = 'stock-out'; $statusText = 'Out of Stock';
                        } elseif ($item['stock_quantity'] < 10) {
                            $stockClass = 'stock-low'; $statusText = 'Low Stock';
                        }
                    ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td>
                            <div style="font-weight: 500;"><?= htmlspecialchars($item['name']) ?></div>
                        </td>
                        <td style="font-family: monospace; color: #666;"><?= htmlspecialchars($item['sku']) ?></td>
                        <td style="text-align: right;">₦<?= number_format($item['unit_price'], 2) ?></td>
                        <td style="text-align: center; font-weight: bold;"><?= $item['stock_quantity'] ?></td>
                        <td>
                            <span class="stock-badge <?= $stockClass ?>"><?= $statusText ?></span>
                        </td>
                        <td style="text-align: right; display: flex; justify-content: flex-end; align-items: center;">
                            <a href="/erp/inventory/edit?id=<?= $item['id'] ?>" class="action-icon" title="Edit">
                                <ion-icon name="create-outline"></ion-icon>
                            </a>
                            <form action="/erp/inventory/delete" method="POST" style="display: inline; margin-left: 10px;" onsubmit="return confirm('Are you sure you want to delete this item?');">
                                <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                <button type="submit" class="action-icon delete-btn" title="Delete">
                                    <ion-icon name="trash-outline"></ion-icon>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </main>
    </dialog>
</div>
</body>
</html>
