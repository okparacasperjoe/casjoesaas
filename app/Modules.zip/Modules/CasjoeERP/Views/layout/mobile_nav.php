<div class="mobile-header">
    <div class="mobile-toggle" onclick="toggleSidebar()">
        <ion-icon name="menu-outline"></ion-icon>
    </div>
    <div class="mobile-brand">
        <img src="/assets/casjoe_logo.png" alt="Casjoe" style="height: 30px;">
    </div>
    <div class="mobile-user">
        <ion-icon name="person-circle-outline" style="font-size: 1.8rem; color: white;"></ion-icon>
    </div>
</div>
