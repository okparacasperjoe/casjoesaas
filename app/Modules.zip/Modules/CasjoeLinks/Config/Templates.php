<?php

namespace App\Modules\CasjoeLinks\Config;

class Templates
{
    public static function all()
    {
        return [
            'default' => [
                'name' => 'Clean Slate',
                'bg_color' => '#ffffff',
                'text_color' => '#000000',
                'btn_bg' => '#f8f9fa',
                'btn_text' => '#000000',
                'font' => 'sans-serif'
            ],
            'dark_mode' => [
                'name' => 'Midnight',
                'bg_color' => '#121212',
                'text_color' => '#ffffff',
                'btn_bg' => '#333333',
                'btn_text' => '#ffffff',
                'font' => 'sans-serif'
            ],
            'ocean' => [
                'name' => 'Ocean Breeze',
                'bg_color' => '#e0f7fa',
                'text_color' => '#006064',
                'btn_bg' => '#00acc1',
                'btn_text' => '#ffffff',
                'font' => 'serif'
            ],
            'poppy' => [
                'name' => 'Sunset',
                'bg_color' => '#fff3e0',
                'text_color' => '#bf360c',
                'btn_bg' => '#ff5722',
                'btn_text' => '#ffffff',
                'font' => 'cursive'
            ],
            'forest' => [
                'name' => 'Forest',
                'bg_color' => '#1b5e20',
                'text_color' => '#e8f5e9',
                'btn_bg' => '#2e7d32',
                'btn_text' => '#ffffff',
                'font' => 'sans-serif'
            ],
            'space' => [
                'name' => 'Deep Space',
                'bg_color' => '#000000',
                'bg_image' => 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?ixlib=rb-1.2.1&auto=format&fit=crop&w=1951&q=80',
                'text_color' => '#ffffff',
                'btn_bg' => 'rgba(255, 255, 255, 0.1)',
                'btn_text' => '#ffffff',
                'glass' => true,
                'font' => 'sans-serif'
            ],
            'glass' => [
                'name' => 'Glassmorphism',
                'bg_color' => '#8e2de2',
                'bg_image' => 'https://images.unsplash.com/photo-1557683316-973673baf926?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80', 
                'text_color' => '#ffffff',
                'btn_bg' => 'rgba(255, 255, 255, 0.2)',
                'btn_text' => '#ffffff',
                'glass' => true,
                'font' => 'sans-serif'
            ]
        ];
    }
}
