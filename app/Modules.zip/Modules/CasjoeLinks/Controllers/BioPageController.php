<?php

namespace App\Modules\CasjoeLinks\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\View;

class BioPageController
{
    public function index()
    {
        if (!Auth::check()) {
            header('Location: /login');
            exit;
        }

        $user = Auth::user();
        $db = Database::getInstance();

        $stmt = $db->query("SELECT * FROM links_bio_pages WHERE tenant_id = ? AND user_id = ? ORDER BY created_at DESC", 
            [$user['tenant_id'], $user['id']]);
        $pages = $stmt->fetchAll();

        require __DIR__ . '/../views/bio/index.php';
    }

    public function create()
    {
        if (!Auth::check()) {
            header('Location: /login');
            exit;
        }
        // Load Templates
        $templates = \App\Modules\CasjoeLinks\Config\Templates::all();
        require __DIR__ . '/../views/bio/create.php';
    }

    public function store()
    {
        if (!Auth::check()) {
            header('Location: /login');
            exit;
        }

        $user = Auth::user();
        $db = Database::getInstance();

        $title = $_POST['title'];
        $slug = $_POST['slug'];
        $templateKey = $_POST['template'] ?? 'default';
        
        // Custom overrides
        $customBg = $_POST['bg_color'] ?? null;
        $customText = $_POST['text_color'] ?? null;

        // Basic validation
        if (empty($title) || empty($slug)) {
            // In real app, flash error
            header('Location: /links/bio/create?error=missing_fields');
            exit;
        }
        
        // Get Template Config
        $templates = \App\Modules\CasjoeLinks\Config\Templates::all();
        $themeConfig = $templates[$templateKey] ?? $templates['default'];

        // Apply overrides if provided (Custom Mode)
        if ($customBg) $themeConfig['bg_color'] = $customBg;
        if ($customText) $themeConfig['text_color'] = $customText;

        try {
            $db->query("INSERT INTO links_bio_pages (tenant_id, user_id, title, slug, theme_config, blocks, settings) VALUES (?, ?, ?, ?, ?, ?, ?)", 
                [
                    $user['tenant_id'], 
                    $user['id'], 
                    $title, 
                    $slug, 
                    json_encode($themeConfig), 
                    json_encode([]), // Empty blocks
                    json_encode(['seo_title' => $title])
                ]
            );

            header('Location: /links/bio');
        } catch (\PDOException $e) {
             header('Location: /links/bio/create?error=slug_taken');
        }
    }
    public function view($params)
    {
        $db = Database::getInstance();
        $slug = is_array($params) ? ($params['slug'] ?? '') : $params;

        // Public Access - No Auth Check Required
        
        $stmt = $db->query("SELECT * FROM links_bio_pages WHERE slug = ?", [$slug]);
        $page = $stmt->fetch();

        if (!$page) {
            http_response_code(404);
            echo "Bio Page Not Found";
            return;
        }
        
        // Log View (Advanced)
        (new \App\Modules\CasjoeLinks\Services\AnalyticsService())->log('bio', $page['id']);

        require __DIR__ . '/../views/bio/public.php';
    }
}
