<?php

namespace App\Modules\CasjoeLinks\Controllers;

use App\Core\Auth;
use App\Core\View;

class LinksController
{
    public function dashboard()
    {
        // Require Login
        if (!Auth::check()) {
            header('Location: /login');
            exit;
        }

        $user = Auth::user();

        // Load View
        require __DIR__ . '/../views/dashboard.php';
    }
}
