<?php

namespace App\Modules\CasjoeLinks\Controllers;

use App\Core\Auth;
use App\Core\Database;

class ShortenerController
{
    public function index()
    {
        if (!Auth::check()) {
            header('Location: /login');
            exit;
        }

        $user = Auth::user();
        $db = Database::getInstance();

        $stmt = $db->query("SELECT * FROM links_short_urls WHERE tenant_id = ? AND user_id = ? ORDER BY created_at DESC", 
            [$user['tenant_id'], $user['id']]);
        $urls = $stmt->fetchAll();

        require __DIR__ . '/../views/shortener/index.php';
    }

    public function create()
    {
        if (!Auth::check()) {
            header('Location: /login');
            exit;
        }
        require __DIR__ . '/../views/shortener/create.php';
    }

    public function store()
    {
        if (!Auth::check()) {
            header('Location: /login');
            exit;
        }

        $user = Auth::user();
        $db = Database::getInstance();

        $longUrl = $_POST['long_url'];
        $shortCode = $_POST['short_code'];

        if (empty($longUrl)) {
             header('Location: /links/short/create?error=missing_url');
             exit;
        }

        // Auto-generate code if empty
        if (empty($shortCode)) {
            $shortCode = substr(md5(uniqid()), 0, 6);
        }

        $expiresAt = !empty($_POST['expires_at']) ? $_POST['expires_at'] : null;

        try {
            $db->query("INSERT INTO links_short_urls (tenant_id, user_id, long_url, short_code, expires_at) VALUES (?, ?, ?, ?, ?)", 
                [$user['tenant_id'], $user['id'], $longUrl, $shortCode, $expiresAt]
            );
            header('Location: /links/short');
        } catch (\PDOException $e) {
             header('Location: /links/short/create?error=code_exists');
        }
    }
    public function redirect($params)
    {
        $code = is_array($params) ? ($params['code'] ?? '') : $params;
        $db = Database::getInstance();

        $stmt = $db->query("SELECT * FROM links_short_urls WHERE short_code = ?", [$code]);
        $link = $stmt->fetch();

        if ($link) {
            // Check Expiry
            if ($link['expires_at'] && strtotime($link['expires_at']) < time()) {
                http_response_code(410);
                echo "Link Expired";
                return;
            }

            // Log Analytics & Update Clicks
            (new \App\Modules\CasjoeLinks\Services\AnalyticsService())->log('short', $link['id']);
            
            // Redirect
            header("Location: " . $link['long_url']);
            exit;
        }

        http_response_code(404);
        echo "Link not found";
    }
}
