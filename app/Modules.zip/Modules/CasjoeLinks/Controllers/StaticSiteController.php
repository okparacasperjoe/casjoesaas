<?php

namespace App\Modules\CasjoeLinks\Controllers;

use App\Core\Auth;
use App\Core\Database;

class StaticSiteController
{
    public function index()
    {
        if (!Auth::check()) {
            header('Location: /login');
            exit;
        }

        $user = Auth::user();
        $db = Database::getInstance();

        $stmt = $db->query("SELECT * FROM links_static_sites WHERE tenant_id = ? AND user_id = ? ORDER BY created_at DESC", 
            [$user['tenant_id'], $user['id']]);
        $sites = $stmt->fetchAll();

        require __DIR__ . '/../views/static/index.php';
    }

    public function create()
    {
        if (!Auth::check()) {
            header('Location: /login');
            exit;
        }
        require __DIR__ . '/../views/static/create.php';
    }

    public function store()
    {
        if (!Auth::check()) {
            header('Location: /login');
            exit;
        }

        $user = Auth::user();
        $db = Database::getInstance();

        $subdomain = $_POST['subdomain']; // acting as folder name
        
        if (empty($subdomain) || empty($_FILES['site_file']['name'])) {
             header('Location: /links/static/create?error=missing_fields');
             exit;
        }

        // Validate subdomain (alphanumeric)
        if (!preg_match('/^[a-z0-9-]+$/', $subdomain)) {
             header('Location: /links/static/create?error=invalid_name');
             exit;
        }

        // Check if exists
        $stmt = $db->query("SELECT id FROM links_static_sites WHERE subdomain = ?", [$subdomain]);
        if ($stmt->fetch()) {
             header('Location: /links/static/create?error=name_taken');
             exit;
        }

        // Handle File Upload
        $targetDir = __DIR__ . '/../../../../public/sites/' . $subdomain;
        
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }

        $zipFile = $_FILES['site_file']['tmp_name'];
        $zip = new \ZipArchive;
        if ($zip->open($zipFile) === TRUE) {
            $zip->extractTo($targetDir);
            $zip->close();

            // Save to DB
            $db->query("INSERT INTO links_static_sites (tenant_id, user_id, subdomain, storage_path) VALUES (?, ?, ?, ?)", 
                [$user['tenant_id'], $user['id'], $subdomain, 'public/sites/' . $subdomain]
            );

            header('Location: /links/static');
        } else {
             header('Location: /links/static/create?error=zip_extraction_failed');
             exit;
        }
    }
}
