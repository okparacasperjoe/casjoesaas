<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Choose Template | Casjoe Links</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        .template-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .template-card {
            border: 1px solid #eee;
            border-radius: 12px;
            overflow: hidden;
            transition: transform 0.2s, box-shadow 0.2s;
            cursor: pointer;
            position: relative;
            background: #fff;
        }
        .template-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        .template-preview {
            height: 350px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
            border-bottom: 1px solid #eee;
        }
        .mock-profile-pic {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: rgba(0,0,0,0.1);
            margin-bottom: 15px;
        }
        .mock-btn {
            width: 100%;
            padding: 10px;
            margin-bottom: 8px;
            border-radius: 30px;
            text-align: center;
            font-size: 0.8rem;
            opacity: 0.8;
        }
        .template-info {
            padding: 15px;
            text-align: center;
        }
        .selected-overlay {
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(13, 110, 253, 0.9);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            opacity: 0;
            transition: opacity 0.2s;
        }
        .template-card.active .selected-overlay {
            opacity: 1;
        }
    </style>
</head>
<body>
    <div class="app-container" style="background: #f8f9fa;">
        <main style="max-width: 1200px; margin: 0 auto; padding: 40px 20px; width: 100%;">
            
            <div style="text-align: center; margin-bottom: 40px;">
                <a href="/links/bio" style="text-decoration: none; color: #666; margin-bottom: 10px; display: inline-block;">&larr; Back to Dashboard</a>
                <h1 style="font-size: 2.5rem; margin-bottom: 10px;">Choose a Starting Point</h1>
                <p style="color: #666; font-size: 1.1rem;">Select a template to customize for your Bio Page.</p>
            </div>

            <?php if (isset($_GET['error'])): ?>
                <div style="max-width: 600px; margin: 0 auto 20px; padding: 15px; background: #fee; color: red; border-radius: 8px; text-align: center;">
                    <?= htmlspecialchars($_GET['error']) ?>
                </div>
            <?php endif; ?>

            <form action="/links/bio/store" method="POST" id="createForm">
                <input type="hidden" name="csrf_token" value="<?= \App\Core\Services\CsrfService::generateToken() ?>">
                <input type="hidden" name="template" id="selectedTemplate" value="default">

                <!-- Step 1: Template Gallery -->
                <div class="template-grid">
                    <?php foreach($templates as $key => $tpl): 
                        $bgStyle = "background-color: {$tpl['bg_color']};";
                        if (!empty($tpl['bg_image'])) {
                            $bgStyle .= "background-image: url('{$tpl['bg_image']}'); background-size: cover; background-position: center;";
                        }
                        
                        $glassClass = !empty($tpl['glass']) ? 'glass-effect' : '';
                        $btnStyle = "background-color: {$tpl['btn_bg']}; color: {$tpl['btn_text']};";
                        if (!empty($tpl['glass'])) {
                            $btnStyle .= "backdrop-filter: blur(5px); border: 1px solid rgba(255,255,255,0.2);";
                        }
                    ?>
                        <div class="template-card" onclick="selectTemplate('<?= $key ?>', this)">
                            <div class="template-preview" style="<?= $bgStyle ?> color: <?= $tpl['text_color'] ?>; font-family: <?= $tpl['font'] ?? 'sans-serif' ?>;">
                                <div class="mock-profile-pic" style="<?= !empty($tpl['glass']) ? 'background: rgba(255,255,255,0.2); backdrop-filter: blur(5px);' : '' ?>"></div>
                                <div style="font-weight: bold; margin-bottom: 5px;">@username</div>
                                <div style="font-size: 0.8rem; margin-bottom: 20px; opacity: 0.7;">Bio description here</div>
                                
                                <div class="mock-btn <?= $glassClass ?>" style="<?= $btnStyle ?>">Link One</div>
                                <div class="mock-btn <?= $glassClass ?>" style="<?= $btnStyle ?>">Link Two</div>
                                <div class="mock-btn <?= $glassClass ?>" style="<?= $btnStyle ?>">Link Three</div>
                            </div>
                            <div class="template-info">
                                <h3 style="margin: 0; font-size: 1.1rem;"><?= $tpl['name'] ?></h3>
                            </div>
                            
                            <!-- Selection Overlay -->
                            <div class="selected-overlay">
                                <div style="text-align: center;">
                                    <ion-icon name="checkmark-circle" style="font-size: 3rem; margin-bottom: 10px;"></ion-icon>
                                    <div>Selected</div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Step 2: Final Details (Modal or Bottom Section) -->
                <div id="detailsSection" style="max-width: 600px; margin: 40px auto; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); display: none;">
                    <h3 style="margin-bottom: 20px;">Finalize your Page</h3>
                    
                    <div class="form-group" style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: bold;">Page Name</label>
                        <input type="text" name="title" required placeholder="e.g. My Socials" style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px;">
                    </div>

                    <div class="form-group" style="margin-bottom: 25px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: bold;">URL Slug</label>
                        <div style="display: flex; align-items: center;">
                            <span style="background: #f8f9fa; padding: 12px; border: 1px solid #ddd; border-right: 0; border-radius: 8px 0 0 8px; color: #666;">casjoe.com/bio/</span>
                            <input type="text" name="slug" required placeholder="username" style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 0 8px 8px 0;">
                        </div>
                    </div>

                    <!-- Custom Colors (Collapsible) -->
                     <div style="margin-bottom: 25px;">
                        <div style="cursor: pointer; color: #0d6efd;" onclick="document.getElementById('customColors').style.display = 'block'; this.style.display='none'">
                            + Customize Template Colors
                        </div>
                        <div id="customColors" style="display: none; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                <div>
                                    <label style="display: block; font-size: 0.9rem; margin-bottom: 5px;">Background</label>
                                    <input type="color" name="bg_color" style="width: 100%; height: 40px; cursor: pointer;">
                                </div>
                                <div>
                                    <label style="display: block; font-size: 0.9rem; margin-bottom: 5px;">Text</label>
                                    <input type="color" name="text_color" style="width: 100%; height: 40px; cursor: pointer;">
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary" style="width: 100%; padding: 12px; font-size: 1.1rem; background: #000; color: #fff; border: none; border-radius: 8px; cursor: pointer;">Create Page</button>
                </div>

            </form>
        </main>
    </div>

    <script>
        function selectTemplate(key, card) {
            // Update hidden input
            document.getElementById('selectedTemplate').value = key;
            
            // UI Update
            document.querySelectorAll('.template-card').forEach(el => el.classList.remove('active'));
            card.classList.add('active');

            // Show details form and scroll to it
            const details = document.getElementById('detailsSection');
            details.style.display = 'block';
            details.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    </script>
</body>
</html>
