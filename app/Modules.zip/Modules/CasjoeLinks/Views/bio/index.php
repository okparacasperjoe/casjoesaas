<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bio Pages | Casjoe Links</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="brand">
                <img src="/assets/casjoe_logo.png" alt="Casjoe Links" style="height: 30px;">
            </div>
            <ul class="nav-menu">
                <li class="nav-item"><a href="/links" class="nav-link"><ion-icon name="grid-outline"></ion-icon> Dashboard</a></li>
                <li class="nav-item"><a href="/links/bio" class="nav-link active"><ion-icon name="person-outline"></ion-icon> Bio Pages</a></li>
                <li class="nav-item"><a href="/links/short" class="nav-link"><ion-icon name="link-outline"></ion-icon> Short URLs</a></li>
                <li class="nav-item"><a href="/links/qr" class="nav-link"><ion-icon name="qr-code-outline"></ion-icon> QR Codes</a></li>
                <li class="nav-item"><a href="/links/static" class="nav-link"><ion-icon name="cloud-upload-outline"></ion-icon> Static Hosting</a></li>
                 <li class="nav-item"><a href="/dashboard" class="nav-link"><ion-icon name="arrow-back-outline"></ion-icon> Back to Apps</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h1>Bio Link Pages</h1>
                <a href="/links/bio/create" class="btn">Create New Page</a>
            </div>

            <div class="card">
                <?php if (empty($pages)): ?>
                    <p style="text-align: center; color: #888; padding: 20px;">You haven't created any bio pages yet.</p>
                <?php else: ?>
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="text-align: left; border-bottom: 1px solid #eee;">
                                <th style="padding: 10px;">Name</th>
                                <th style="padding: 10px;">URL</th>
                                <th style="padding: 10px;">Status</th>
                                <th style="padding: 10px;">Views</th>
                                <th style="padding: 10px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($pages as $page): ?>
                                <tr style="border-bottom: 1px solid #f5f5f5;">
                                    <td style="padding: 10px; font-weight: 500;"><?= htmlspecialchars($page['title']) ?></td>
                                    <td style="padding: 10px;"><a href="/bio/<?= htmlspecialchars($page['slug']) ?>" target="_blank" style="color: blue;">/bio/<?= htmlspecialchars($page['slug']) ?></a></td>
                                    <td style="padding: 10px;"><?= htmlspecialchars(ucfirst($page['status'])) ?></td>
                                    <td style="padding: 10px;"><?= $page['views'] ?></td>
                                    <td style="padding: 10px;">
                                        <button class="btn btn-sm" style="background: #eee; color: #333;">Edit</button>
                                        <a href="/links/qr/create?bio=<?= $page['id'] ?>" class="btn btn-sm" style="background: #e3f2fd; color: #0d6efd; text-decoration: none;">QR Code</a>
                                        <button class="btn btn-sm" style="background: #fee; color: red;">Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
