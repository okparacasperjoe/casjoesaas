<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page['title']) ?></title>
    
    <?php 
    $theme = json_decode($page['theme_config'] ?? '{}', true);
    $bgColor = $theme['bg_color'] ?? '#ffffff';
    $textColor = $theme['text_color'] ?? '#000000';
    $blocks = json_decode($page['blocks'] ?? '[]', true);
    ?>

    <style>
        body {
            background-color: <?= $bgColor ?>;
            color: <?= $textColor ?>;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            min-height: 100vh;
        }
        .container {
            width: 100%;
            max-width: 480px;
            padding: 40px 20px;
            text-align: center;
        }
        h1 { font-size: 1.5rem; margin-bottom: 10px; }
        .description { opacity: 0.8; margin-bottom: 30px; }
        
        .block-link {
            display: block;
            background: rgba(0,0,0,0.05); /* Adaptive logic needed ideally */
            border: 2px solid <?= $textColor ?>;
            color: <?= $textColor ?>;
            text-decoration: none;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            font-weight: 600;
            transition: transform 0.2s, background 0.2s;
        }
        .block-link:hover {
            transform: translateY(-2px);
            background: rgba(0,0,0,0.1);
        }
        .block-text { margin-bottom: 20px; line-height: 1.6; }
        
        /* Dark mode checks for fallback */
        <?php if ($theme['bg_mode'] ?? 'light' == 'dark'): ?>
            .block-link { border-color: rgba(255,255,255,0.2); background: rgba(255,255,255,0.1); }
        <?php endif; ?>
    </style>
</head>
<body>
    <div class="container">
        <!-- Avatar would go here if added to schema -->
        
        <h1><?= htmlspecialchars($page['title']) ?></h1>
        <?php if(!empty($page['description'])): ?>
            <p class="description"><?= nl2br(htmlspecialchars($page['description'])) ?></p>
        <?php endif; ?>

        <div class="blocks">
            <?php foreach($blocks as $block): ?>
                <?php if($block['type'] === 'link'): ?>
                    <a href="<?= htmlspecialchars($block['url']) ?>" class="block-link" target="_blank" rel="noopener noreferrer">
                        <?= htmlspecialchars($block['title']) ?>
                    </a>
                <?php elseif($block['type'] === 'text'): ?>
                    <div class="block-text"><?= nl2br(htmlspecialchars($block['content'])) ?></div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>

        <div style="margin-top: 50px; font-size: 0.8rem; opacity: 0.5;">
            Powered by Casjoe Links
        </div>
    </div>
</body>
</html>
