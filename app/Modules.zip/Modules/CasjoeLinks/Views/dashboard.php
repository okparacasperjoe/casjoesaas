<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Casjoe Links | Dashboard</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <style>
        .sidebar .nav-link { color: white !important; }
        .sidebar .nav-link:hover { color: white !important; background: rgba(255, 255, 255, 0.1); }
        .sidebar .nav-link.active { color: white !important; }
        .sidebar .brand { color: white !important; }
    </style>
</head>
<body>
    <?php require_once dirname(__DIR__, 3) . '/core/Views/partials/mobile_nav.php'; ?>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="brand">
                <img src="/assets/casjoe_logo.png" alt="Casjoe Links" style="height: 30px;">
            </div>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="/links" class="nav-link active"><ion-icon name="grid-outline"></ion-icon> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a href="/links/bio" class="nav-link"><ion-icon name="person-outline"></ion-icon> Bio Pages</a>
                </li>
                <li class="nav-item">
                    <a href="/links/short" class="nav-link"><ion-icon name="link-outline"></ion-icon> Short URLs</a>
                </li>
                <li class="nav-item">
                    <a href="/links/qr" class="nav-link"><ion-icon name="qr-code-outline"></ion-icon> QR Codes</a>
                </li>
                <li class="nav-item">
                    <a href="/links/static" class="nav-link"><ion-icon name="cloud-upload-outline"></ion-icon> Static Hosting</a>
                </li>
                 <li class="nav-item">
                    <a href="/dashboard" class="nav-link"><ion-icon name="arrow-back-outline"></ion-icon> Back to Apps</a>
                </li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <div class="top-bar">
                <h1>Casjoe Links Dashboard</h1>
                <div class="user-profile">
                    <?= htmlspecialchars($user['email'] ?? $user['name']) ?>
                </div>
            </div>

            <div class="dashboard-grid">
                <!-- Bio Pages Card -->
                <div class="card">
                    <h3>Bio Link Pages</h3>
                    <div style="font-size: 2rem; font-weight: bold; margin: 10px 0;">0</div>
                    <p style="color: #666; font-size: 0.9rem;">Total Bio Pages Created</p>
                    <a href="/links/bio/create" class="btn" style="margin-top: 15px; display: inline-block;">Create New</a>
                </div>

                <!-- Short URLs Card -->
                <div class="card">
                    <h3>Shortened URLs</h3>
                    <div style="font-size: 2rem; font-weight: bold; margin: 10px 0;">0</div>
                    <p style="color: #666; font-size: 0.9rem;">Active Short Links</p>
                    <a href="/links/short/create" class="btn" style="margin-top: 15px; display: inline-block;">Shorten URL</a>
                </div>

                 <!-- QR Codes Card -->
                <div class="card">
                    <h3>QR Codes</h3>
                    <div style="font-size: 2rem; font-weight: bold; margin: 10px 0;">0</div>
                    <p style="color: #666; font-size: 0.9rem;">Generated QR Codes</p>
                    <a href="/links/qr/create" class="btn" style="margin-top: 15px; display: inline-block;">Generate QR</a>
                </div>

                 <!-- Static Sites Card -->
                <div class="card">
                    <h3>Static Sites</h3>
                    <div style="font-size: 2rem; font-weight: bold; margin: 10px 0;">0</div>
                    <p style="color: #666; font-size: 0.9rem;">Hosted Websites</p>
                    <a href="/links/static/create" class="btn" style="margin-top: 15px; display: inline-block;">Upload Site</a>
                </div>

                <!-- Analytics Card -->
                <div class="card" style="border-left: 5px solid #0d6efd;">
                    <h3>Analytics</h3>
                    <div style="font-size: 2rem; font-weight: bold; margin: 10px 0;">
                        <ion-icon name="stats-chart-outline"></ion-icon>
                    </div>
                    <p style="color: #666; font-size: 0.9rem;">Traffic & Insights</p>
                    <a href="/links/analytics" class="btn btn-primary" style="margin-top: 15px; display: inline-block;">View Reports</a>
                </div>
            </div>
            
             <h2 style="margin-top: 30px;">Recent Analytics</h2>
             <div class="card" style="margin-top: 15px; min-height: 200px; display: flex; align-items: center; justify-content: center; color: #888;">
                No data to display yet.
             </div>
        </main>
    </div>
</body>
</html>
