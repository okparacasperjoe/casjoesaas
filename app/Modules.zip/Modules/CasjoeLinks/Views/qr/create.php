<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create QR Code | Casjoe Links</title>
    <link rel="stylesheet" href="/css/style.css">
    <script src="https://unpkg.com/qr-code-styling@1.5.0/lib/qr-code-styling.js"></script>
</head>
<body>
    <div class="app-container" style="background: #f4f6f9; min-height: 100vh; padding: 20px;">
        <div class="card" style="width: 100%; max-width: 900px; margin: 0 auto; display: flex; gap: 30px;">
            
            <!-- Left: Settings -->
            <div style="flex: 1;">
                 <h2 style="margin-bottom: 20px;">Create QR Code</h2>
                 
                 <form action="/links/qr/store" method="POST" id="qrForm">
                    <input type="hidden" name="csrf_token" value="<?= \App\Core\Services\CsrfService::generateToken() ?>">
                    <input type="hidden" name="design_config" id="designConfig">
                    <input type="hidden" name="type" value="url">

                    <div class="form-group" style="margin-bottom: 15px;">
                        <label style="display: block; margin-bottom: 5px;">Name</label>
                        <input type="text" name="name" value="<?= htmlspecialchars($prefill['name'] ?? '') ?>" required placeholder="e.g. My Website QR" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>

                    <div class="form-group" style="margin-bottom: 15px;">
                        <label style="display: block; margin-bottom: 5px;">Website URL</label>
                        <input type="text" name="content" id="qrContent" value="<?= htmlspecialchars($prefill['content'] ?? '') ?>" required placeholder="https://example.com" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>

                    <div class="form-group" style="margin-bottom: 15px;">
                        <label style="display: block; margin-bottom: 5px;">Dots Color</label>
                        <input type="color" id="dotsColor" value="#000000">
                    </div>
                    
                    <div class="form-group" style="margin-bottom: 15px;">
                        <label style="display: block; margin-bottom: 5px;">Background Color</label>
                        <input type="color" id="bgColor" value="#ffffff">
                    </div>

                    <div style="margin-top: 20px;">
                        <button type="submit" class="btn">Save QR Code</button>
                    </div>
                 </form>
            </div>

            <!-- Right: Preview -->
            <div style="width: 300px; display: flex; flex-direction: column; align-items: center; justify-content: center; background: #eee; padding: 20px; border-radius: 8px;">
                <h3 style="margin-bottom: 15px;">Preview</h3>
                <div id="qr-canvas"></div>
            </div>

        </div>
    </div>
    
    <script>
        const qrCode = new QRCodeStyling({
            width: 250,
            height: 250,
            type: "svg",
            data: "https://casjoe.com",
            dotsOptions: { color: "#000000", type: "rounded" },
            backgroundOptions: { color: "#ffffff" }
        });

        qrCode.append(document.getElementById("qr-canvas"));

        // Live Update
        document.getElementById('qrContent').addEventListener('input', function(e) {
            qrCode.update({ data: e.target.value });
        });

        document.getElementById('dotsColor').addEventListener('input', function(e) {
            qrCode.update({ dotsOptions: { color: e.target.value } });
        });
        
        document.getElementById('bgColor').addEventListener('input', function(e) {
            qrCode.update({ backgroundOptions: { color: e.target.value } });
        });

        // Save Config on Submit
        document.getElementById('qrForm').addEventListener('submit', function(e) {
            const config = {
                dotsOptions: { color: document.getElementById('dotsColor').value },
                backgroundOptions: { color: document.getElementById('bgColor').value }
            };
            document.getElementById('designConfig').value = JSON.stringify(config);
        });
    </script>
</body>
</html>
