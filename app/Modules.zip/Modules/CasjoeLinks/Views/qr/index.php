<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Codes | Casjoe Links</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script src="https://unpkg.com/qr-code-styling@1.5.0/lib/qr-code-styling.js"></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="brand">
                <img src="/assets/casjoe_logo.png" alt="Casjoe Links" style="height: 30px;">
            </div>
            <ul class="nav-menu">
                <li class="nav-item"><a href="/links" class="nav-link"><ion-icon name="grid-outline"></ion-icon> Dashboard</a></li>
                <li class="nav-item"><a href="/links/bio" class="nav-link"><ion-icon name="person-outline"></ion-icon> Bio Pages</a></li>
                <li class="nav-item"><a href="/links/short" class="nav-link"><ion-icon name="link-outline"></ion-icon> Short URLs</a></li>
                <li class="nav-item"><a href="/links/qr" class="nav-link active"><ion-icon name="qr-code-outline"></ion-icon> QR Codes</a></li>
                <li class="nav-item"><a href="/links/static" class="nav-link"><ion-icon name="cloud-upload-outline"></ion-icon> Static Hosting</a></li>
                 <li class="nav-item"><a href="/dashboard" class="nav-link"><ion-icon name="arrow-back-outline"></ion-icon> Back to Apps</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h1>My QR Codes</h1>
                <a href="/links/qr/create" class="btn">Create QR Code</a>
            </div>

             <div class="card">
                <?php if (empty($qrcodes)): ?>
                    <p style="text-align: center; color: #888; padding: 20px;">No QR codes created yet.</p>
                <?php else: ?>
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 20px;">
                        <?php foreach ($qrcodes as $qr): ?>
                            <div style="border: 1px solid #eee; padding: 15px; border-radius: 8px; text-align: center;">
                                <div id="qr-canvas-<?= $qr['id'] ?>" style="margin-bottom: 10px;"></div>
                                <h3 style="font-size: 1rem; margin-bottom: 5px;"><?= htmlspecialchars($qr['name']) ?></h3>
                                <p style="font-size: 0.8rem; color: #666; margin-bottom: 10px;"><?= htmlspecialchars(ucfirst($qr['type'])) ?></p>
                                <button class="btn btn-sm" onclick="downloadQr(<?= $qr['id'] ?>)">Download</button>
                                <button class="btn btn-sm" style="background: #fee; color: red;">Delete</button>

                                <script>
                                    (function() {
                                        const config = <?= $qr['design_config'] ?: '{}' ?>;
                                        const qrCode = new QRCodeStyling({
                                            width: 150,
                                            height: 150,
                                            type: "svg",
                                            data: "<?= htmlspecialchars($qr['content']) ?>",
                                            dotsOptions: config.dotsOptions || {},
                                            backgroundOptions: config.backgroundOptions || {},
                                            image: config.image || null,
                                            cornersSquareOptions: config.cornersSquareOptions || {},
                                            cornersDotOptions: config.cornersDotOptions || {}
                                        });
                                        qrCode.append(document.getElementById("qr-canvas-<?= $qr['id'] ?>"));
                                        
                                        window.downloadQr = function(id) {
                                             if(id === <?= $qr['id'] ?>) qrCode.download({ name: "qr-code-" + id, extension: "png" });
                                        }
                                    })();
                                </script>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
