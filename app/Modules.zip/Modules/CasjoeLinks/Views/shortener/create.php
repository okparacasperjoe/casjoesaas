<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shorten URL | Casjoe Links</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="app-container" style="justify-content: center; align-items: center; background: #f4f6f9;">
        <div class="card" style="width: 500px;">
            <h2 style="margin-bottom: 20px;">Shorten a new URL</h2>
             <?php if (isset($_GET['error'])): ?>
                <div style="background: #fee; color: red; padding: 10px; margin-bottom: 10px; border-radius: 5px;">
                    <?= htmlspecialchars($_GET['error']) ?>
                </div>
            <?php endif; ?>

            <form action="/links/short/store" method="POST">
                <input type="hidden" name="csrf_token" value="<?= \App\Core\Services\CsrfService::generateToken() ?>">
                
                <div class="form-group" style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px;">Long URL</label>
                    <input type="url" name="long_url" required placeholder="https://example.com/very-long-url" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>

                <div class="form-group" style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px;">Custom Alias (Optional)</label>
                    <div style="display: flex; align-items: center;">
                        <span style="background: #eee; padding: 8px; border: 1px solid #ddd; border-right: 0; border-radius: 4px 0 0 4px;">/l/</span>
                        <input type="text" name="short_code" placeholder="alias" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 0 4px 4px 0;">
                    </div>
                </div>

                <div class="form-group" style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px;">Expiration Date (Optional)</label>
                    <input type="datetime-local" name="expires_at" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    <small style="color: #666;">Link will redirect to 410 Gone after this date.</small>
                </div>

                <div style="display: flex; justify-content: space-between;">
                    <a href="/links/short" class="btn" style="background: #eee; color: #333; text-decoration: none;">Cancel</a>
                    <button type="submit" class="btn">Shorten URL</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
