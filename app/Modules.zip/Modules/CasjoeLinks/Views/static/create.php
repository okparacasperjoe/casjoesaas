<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Static Site | Casjoe Links</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="app-container" style="justify-content: center; align-items: center; background: #f4f6f9;">
        <div class="card" style="width: 500px;">
            <h2 style="margin-bottom: 20px;">Upload Static Website</h2>
             <?php if (isset($_GET['error'])): ?>
                <div style="background: #fee; color: red; padding: 10px; margin-bottom: 10px; border-radius: 5px;">
                    <?= htmlspecialchars($_GET['error']) ?>
                </div>
            <?php endif; ?>

            <form action="/links/static/store" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= \App\Core\Services\CsrfService::generateToken() ?>">
                
                <div class="form-group" style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px;">Site Name (Folder Name)</label>
                    <input type="text" name="subdomain" required placeholder="my-awesome-site" pattern="[a-z0-9-]+" title="Lowercase letters, numbers and hyphens only" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>

                <div class="form-group" style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px;">Upload .zip file</label>
                    <input type="file" name="site_file" accept=".zip" required style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    <small style="color: #666;">Must contain index.html at root.</small>
                </div>

                <div style="display: flex; justify-content: space-between;">
                    <a href="/links/static" class="btn" style="background: #eee; color: #333; text-decoration: none;">Cancel</a>
                    <button type="submit" class="btn">Upload & Deploy</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
