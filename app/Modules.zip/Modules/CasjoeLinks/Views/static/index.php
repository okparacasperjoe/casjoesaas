<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Static Sites | Casjoe Links</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="brand">
                <img src="/assets/casjoe_logo.png" alt="Casjoe Links" style="height: 30px;">
            </div>
            <ul class="nav-menu">
                <li class="nav-item"><a href="/links" class="nav-link"><ion-icon name="grid-outline"></ion-icon> Dashboard</a></li>
                <li class="nav-item"><a href="/links/bio" class="nav-link"><ion-icon name="person-outline"></ion-icon> Bio Pages</a></li>
                <li class="nav-item"><a href="/links/short" class="nav-link"><ion-icon name="link-outline"></ion-icon> Short URLs</a></li>
                <li class="nav-item"><a href="/links/qr" class="nav-link"><ion-icon name="qr-code-outline"></ion-icon> QR Codes</a></li>
                <li class="nav-item"><a href="/links/static" class="nav-link active"><ion-icon name="cloud-upload-outline"></ion-icon> Static Hosting</a></li>
                 <li class="nav-item"><a href="/dashboard" class="nav-link"><ion-icon name="arrow-back-outline"></ion-icon> Back to Apps</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h1>Static Websites</h1>
                <a href="/links/static/create" class="btn">Upload New Site</a>
            </div>

            <div class="card">
                <?php if (empty($sites)): ?>
                    <p style="text-align: center; color: #888; padding: 20px;">No static sites hosted yet.</p>
                <?php else: ?>
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="text-align: left; border-bottom: 1px solid #eee;">
                                <th style="padding: 10px;">Site Name</th>
                                <th style="padding: 10px;">URL</th>
                                <th style="padding: 10px;">Status</th>
                                <th style="padding: 10px;">Created</th>
                                <th style="padding: 10px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($sites as $site): ?>
                                <tr style="border-bottom: 1px solid #f5f5f5;">
                                    <td style="padding: 10px; font-weight: 500;"><?= htmlspecialchars($site['subdomain']) ?></td>
                                    <td style="padding: 10px;"><a href="/sites/<?= htmlspecialchars($site['subdomain']) ?>/index.html" target="_blank" style="color: blue;">/sites/<?= htmlspecialchars($site['subdomain']) ?></a></td>
                                    <td style="padding: 10px;"><?= htmlspecialchars(ucfirst($site['status'])) ?></td>
                                    <td style="padding: 10px;"><?= date('M d, Y', strtotime($site['created_at'])) ?></td>
                                    <td style="padding: 10px;">
                                        <button class="btn btn-sm" style="background: #fee; color: red;">Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
