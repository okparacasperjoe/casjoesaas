<?php

use App\Core\Router;
use App\Modules\CasjoeLinks\Controllers\LinksController;

// Dashboard
// Dashboard
Router::get('/links', [LinksController::class, 'dashboard']); // Main Dashboard
Router::get('/links/analytics', [App\Modules\CasjoeLinks\Controllers\AnalyticsController::class, 'dashboard']);

// Bio Pages
Router::get('/links/bio', [App\Modules\CasjoeLinks\Controllers\BioPageController::class, 'index']);
Router::get('/links/bio/create', [App\Modules\CasjoeLinks\Controllers\BioPageController::class, 'create']);
Router::post('/links/bio/store', [App\Modules\CasjoeLinks\Controllers\BioPageController::class, 'store']);

// Shortener
Router::get('/links/short', [App\Modules\CasjoeLinks\Controllers\ShortenerController::class, 'index']);
Router::get('/links/short/create', [App\Modules\CasjoeLinks\Controllers\ShortenerController::class, 'create']);
Router::post('/links/short/store', [App\Modules\CasjoeLinks\Controllers\ShortenerController::class, 'store']);

// QR Codes
Router::get('/links/qr', [App\Modules\CasjoeLinks\Controllers\QrCodeController::class, 'index']);
Router::get('/links/qr/create', [App\Modules\CasjoeLinks\Controllers\QrCodeController::class, 'create']);
Router::post('/links/qr/store', [App\Modules\CasjoeLinks\Controllers\QrCodeController::class, 'store']);

// Static Sites
Router::get('/links/static', [App\Modules\CasjoeLinks\Controllers\StaticSiteController::class, 'index']);
Router::get('/links/static/create', [App\Modules\CasjoeLinks\Controllers\StaticSiteController::class, 'create']);
Router::get('/links/static/store', [App\Modules\CasjoeLinks\Controllers\StaticSiteController::class, 'store']);

// Public Routes
// Public Routes
Router::get('/bio/{slug}', [App\Modules\CasjoeLinks\Controllers\BioPageController::class, 'view']);
Router::get('/go/{code}', [App\Modules\CasjoeLinks\Controllers\ShortenerController::class, 'redirect']);
