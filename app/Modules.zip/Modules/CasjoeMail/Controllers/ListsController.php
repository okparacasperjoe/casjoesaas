<?php

namespace App\Modules\CasjoeMail\Controllers;

use App\Core\Database;
use App\Core\TenantContext;
use App\Core\SubscriptionManager;
use PDO;

class ListsController
{
    private $pdo;
    private $tenantId;

    public function __construct()
    {
        $this->tenantId = TenantContext::getTenantId();
        SubscriptionManager::requireActive($this->tenantId);
        $this->pdo = Database::getInstance()->getConnection();
    }

    public function index()
    {
        // Get all lists with subscriber count
        $stmt = $this->pdo->query("
            SELECT l.*, COUNT(s.id) as subscriber_count 
            FROM cm_lists l 
            LEFT JOIN cm_subscribers s ON l.id = s.list_id 
            WHERE l.tenant_id = {$this->tenantId} 
            GROUP BY l.id
            ORDER BY l.created_at DESC
        ");
        $lists = $stmt->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../views/lists/index.php';
    }

    public function forms()
    {
        // Get all lists for forms page
        $stmt = $this->pdo->query("SELECT * FROM cm_lists WHERE tenant_id = {$this->tenantId} ORDER BY created_at DESC");
        $lists = $stmt->fetchAll(PDO::FETCH_ASSOC);
        require __DIR__ . '/../views/forms/index.php';
    }

    public function create()
    {
        require __DIR__ . '/../views/lists/create.php';
    }

    public function store()
    {
        $name = $_POST['name'] ?? '';

        if (empty($name)) {
            header('Location: /mail/lists/create?error=Name is required');
            exit;
        }

        $stmt = $this->pdo->prepare("INSERT INTO cm_lists (tenant_id, name) VALUES (?, ?)");
        $stmt->execute([$this->tenantId, $name]);

        header('Location: /mail/lists');
        exit;
    }

    public function show()
    {
        $id = $_GET['id'] ?? 0;
        
        // Fetch List
        $stmt = $this->pdo->prepare("SELECT * FROM cm_lists WHERE id = ? AND tenant_id = ?");
        $stmt->execute([$id, $this->tenantId]);
        $list = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$list) {
            header('Location: /mail/lists');
            exit;
        }

        // Fetch Subscribers
        $stmt = $this->pdo->prepare("SELECT * FROM cm_subscribers WHERE list_id = ? AND tenant_id = ? ORDER BY created_at DESC");
        $stmt->execute([$id, $this->tenantId]);
        $subscribers = $stmt->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../views/lists/show.php';
    }

    public function addSubscriber()
    {
        $listId = $_POST['list_id'] ?? 0;
        $email = $_POST['email'] ?? '';
        $firstName = $_POST['first_name'] ?? '';
        $lastName = $_POST['last_name'] ?? '';

        if (empty($email) || empty($listId)) {
            header("Location: /mail/lists/view?id=$listId&error=Email required");
            exit;
        }

        try {
            $stmt = $this->pdo->prepare("INSERT INTO cm_subscribers (tenant_id, list_id, email, first_name, last_name) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$this->tenantId, $listId, $email, $firstName, $lastName]);
        } catch (\PDOException $e) {
            // Likely duplicate email
            header("Location: /mail/lists/view?id=$listId&error=Subscriber already exists");
            exit;
        }

        header("Location: /mail/lists/view?id=$listId");
        exit;
    }
    public function import()
    {
        $listId = $_GET['list_id'] ?? 0;
        if(!$listId) {
             header('Location: /mail/lists');
             exit;
        }
        require __DIR__ . '/../views/lists/import.php';
    }

    public function processImport()
    {
        $listId = $_POST['list_id'] ?? 0;
        $hasHeader = isset($_POST['has_header']);
        
        if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
            header("Location: /mail/lists/import?list_id=$listId&error=Upload Failed");
            exit;
        }

        $tmpName = $_FILES['csv_file']['tmp_name'];
        $handle = fopen($tmpName, 'r');
        
        if ($handle === false) {
             header("Location: /mail/lists/import?list_id=$listId&error=Cannot read file");
             exit;
        }

        if ($hasHeader) {
            fgetcsv($handle); // Skip header
        }

        $count = 0;
        // Updated schema: email, first_name, last_name, company, phone, tags
        $stmt = $this->pdo->prepare("INSERT INTO cm_subscribers (tenant_id, list_id, email, first_name, last_name, company, phone, tags) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE first_name=VALUES(first_name), last_name=VALUES(last_name), company=VALUES(company), phone=VALUES(phone), tags=VALUES(tags)");

        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $email = trim($data[0] ?? '');
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $firstName = trim($data[1] ?? '');
                $lastName = trim($data[2] ?? '');
                $company = trim($data[3] ?? '');
                $phone = trim($data[4] ?? '');
                $tags = trim($data[5] ?? ''); // e.g., "customer, vip"
                
                try {
                    $stmt->execute([$this->tenantId, $listId, $email, $firstName, $lastName, $company, $phone, $tags]);
                    $count++;
                } catch (\PDOException $e) {
                    // Ignore specific row error
                }
            }
        }

        fclose($handle);
        header("Location: /mail/lists/import?list_id=$listId&status=success&count=$count");
        exit;
    }

    public function publicForm()
    {
        $listId = $_GET['id'] ?? 0;
        // Verify list exists (optional but good practice)
        require __DIR__ . '/../views/public/subscribe.php';
    }

    public function processPublicSubscription()
    {
        $listId = $_POST['list_id'] ?? 0;
        $email = $_POST['email'] ?? '';
        $firstName = $_POST['first_name'] ?? '';

        if (empty($email) || empty($listId)) {
             header("Location: /mail/subscribe?id=$listId&error=Email required");
             exit;
        }

        // We need tenantId from the List ID since this is public context and might not have session
        // For simplicity in this mono-repo, we fetch tenant ID from list.
        $stmt = $this->pdo->prepare("SELECT tenant_id FROM cm_lists WHERE id = ?");
        $stmt->execute([$listId]);
        $tenantId = $stmt->fetchColumn();

        if(!$tenantId) {
             die("Invalid List");
        }

        try {
            $stmt = $this->pdo->prepare("INSERT INTO cm_subscribers (tenant_id, list_id, email, first_name) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE first_name=VALUES(first_name)");
            $stmt->execute([$tenantId, $listId, $email, $firstName]);
            header("Location: /mail/subscribe?id=$listId&status=success");
        } catch (\PDOException $e) {
            header("Location: /mail/subscribe?id=$listId&error=Error subscribing");
        }
        exit;
    }

    public function unsubscribe()
    {
        $id = $_GET['id'] ?? 0;
        $hash = $_GET['hash'] ?? '';
        $success = false;
        $listName = 'our mailing list';

        // Verify hash logic here in production

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
             $stmt = $this->pdo->prepare("UPDATE cm_subscribers SET status = 'unsubscribed' WHERE id = ?");
             $stmt->execute([$id]);
             $success = true;
        } else {
             $stmt = $this->pdo->prepare("SELECT l.name FROM cm_subscribers s JOIN cm_lists l ON s.list_id = l.id WHERE s.id = ?");
             $stmt->execute([$id]);
             $listName = $stmt->fetchColumn() ?: 'our mailing list';
        }

        require __DIR__ . '/../views/public/unsubscribe.php';
    }
}
