<?php

namespace App\Modules\CasjoeMail\Controllers;

use App\Core\Database;
use App\Core\TenantContext;
use App\Core\SubscriptionManager;
use App\Core\Services\GeminiService;
use PDO;

class MailController
{
    private $pdo;
    private $tenantId;

    public function __construct()
    {
        // Basic Init
    }

    private function init() {
        $this->tenantId = TenantContext::getTenantId();
        SubscriptionManager::requireActive($this->tenantId);
        $this->pdo = Database::getInstance()->getConnection();
    }

    public function index()
    {
        $this->init();
        
        // Dashboard Stats
        $stats = [
            'campaigns' => $this->pdo->query("SELECT COUNT(*) FROM cm_campaigns WHERE tenant_id = {$this->tenantId}")->fetchColumn(),
            'subscribers' => $this->pdo->query("SELECT COUNT(*) FROM cm_subscribers WHERE tenant_id = {$this->tenantId}")->fetchColumn(),
            'emails_sent' => $this->pdo->query("SELECT COALESCE(SUM(sent_count), 0) FROM cm_campaigns WHERE tenant_id = {$this->tenantId}")->fetchColumn(),
        ];

        // Recent Campaigns
        $recentCampaigns = $this->pdo->query("SELECT * FROM cm_campaigns WHERE tenant_id = {$this->tenantId} ORDER BY created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../views/dashboard.php';
    }

    public function campaigns()
    {
        $this->init();
        $stmt = $this->pdo->query("SELECT * FROM cm_campaigns WHERE tenant_id = {$this->tenantId} ORDER BY created_at DESC");
        $campaigns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        require __DIR__ . '/../views/campaigns/index.php';
    }

    public function templates()
    {
        $this->init();
        $stmt = $this->pdo->prepare("SELECT * FROM cm_templates WHERE tenant_id = ? OR tenant_id IS NULL ORDER BY created_at DESC");
        $stmt->execute([$this->tenantId]);
        $templates = $stmt->fetchAll(PDO::FETCH_ASSOC);
        require __DIR__ . '/../views/templates/index.php'; // Updated path to standard structure
    }

    public function viewTemplate()
    {
        $this->init();
        $id = $_GET['id'] ?? 0;
        $stmt = $this->pdo->prepare("SELECT * FROM cm_templates WHERE id = ? AND (tenant_id = ? OR tenant_id IS NULL)");
        $stmt->execute([$id, $this->tenantId]);
        $template = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$template) {
            header('Location: /mail/templates');
            exit;
        }

        require __DIR__ . '/../views/templates/show.php';
    }

    public function createCampaign()
    {
        $this->init();
        // Fetch User and System Templates
        $stmt = $this->pdo->prepare("SELECT * FROM cm_templates WHERE tenant_id = ? OR tenant_id IS NULL");
        $stmt->execute([$this->tenantId]);
        $templates = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Fetch Lists
        $stmt = $this->pdo->prepare("SELECT * FROM cm_lists WHERE tenant_id = ?");
        $stmt->execute([$this->tenantId]);
        $lists = $stmt->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../views/campaigns/create.php';
    }

    public function generateAiContent()
    {
        header('Content-Type: application/json');
        
        // Basic Security
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }

        $prompt = $_POST['prompt'] ?? '';
        $tone = $_POST['tone'] ?? 'professional';

        if (empty($prompt)) {
            echo json_encode(['error' => 'Prompt is required']);
            exit;
        }

        $gemini = new GeminiService();
        $content = $gemini->generateEmailContent($prompt, $tone);

        echo json_encode(['content' => $content]);
        exit;
    }

    public function templateContent($id)
    {
        $this->init();
        // Return raw content for AJAX
        $id = $_GET['id'] ?? 0;
        $stmt = $this->pdo->prepare("SELECT content FROM cm_templates WHERE id = ? AND (tenant_id = ? OR tenant_id IS NULL)");
        $stmt->execute([$id, $this->tenantId]);
        echo $stmt->fetchColumn();
        exit;
    }

    public function sendCampaign()
    {
        $this->init();
        $id = $_POST['id'] ?? 0;
        
        // Fetch Campaign
        $stmt = $this->pdo->prepare("SELECT * FROM cm_campaigns WHERE id = ? AND tenant_id = ?");
        $stmt->execute([$id, $this->tenantId]);
        $campaign = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$campaign) {
            header('Location: /mail/campaigns?error=Campaign not found');
            exit;
        }

        // Fetch List
        $stmt = $this->pdo->prepare("SELECT * FROM cm_subscribers WHERE list_id = ? AND tenant_id = ?");
        $stmt->execute([$campaign['list_id'], $this->tenantId]);
        $subscribers = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Fetch Settings
        $stmt = $this->pdo->prepare("SELECT setting_key, setting_value FROM cm_settings WHERE tenant_id = ?");
        $stmt->execute([$this->tenantId]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $tenantSettings = [];
        foreach ($rows as $row) $tenantSettings[$row['setting_key']] = $row['setting_value'];

        // Load System Config
        $systemConfig = require __DIR__ . '/../../../../config/mail.php';

        // Merge: System SMTP + Tenant Sender Info
        $settings = array_merge($systemConfig, [
            'from_email' => $tenantSettings['from_email'] ?? $systemConfig['from_email'],
            'from_name' => $tenantSettings['from_name'] ?? $systemConfig['from_name']
        ]);

        require_once __DIR__ . '/../../../Core/Services/SmtpService.php';

        try {
            $smtp = new \App\Core\Services\SmtpService($settings);
            
            $sentCount = 0;
            foreach ($subscribers as $sub) {
                // Generate Tracking Hash
                $hash = bin2hex(random_bytes(16));
                
                // Insert Tracking Record
                $trackStmt = $this->pdo->prepare("INSERT INTO cm_analytics (tenant_id, campaign_id, subscriber_id, hash, status) VALUES (?, ?, ?, ?, 'sent')");
                $trackStmt->execute([$this->tenantId, $id, $sub['id'], $hash]);
                
                // Tracking Pixel URL
                $trackUrl = "http://localhost:8000/mail/track?h=$hash"; // In prod use actual domain
                $pixelHtml = "<img src='$trackUrl' width='1' height='1' style='display:none;' alt='' />";

                // Template Replacement
                $body = str_replace(
                    ['{{subscriber_name}}', '{{company_name}}', '{{unsubscribe_url}}'], 
                    [$sub['first_name'], 'Your Company', "http://localhost:8000/mail/unsubscribe?id=" . $sub['id']], 
                    $campaign['content']
                );
                
                // Append Pixel
                $body .= $pixelHtml;
                
                try {
                    $smtp->send($sub['email'], $campaign['subject'], $body);
                    $sentCount++;
                } catch (\Exception $e) {
                    error_log("Mail Send Error: " . $e->getMessage());
                }
            }

            // Update Campaign Status
            $stmt = $this->pdo->prepare("UPDATE cm_campaigns SET status = 'sent', sent_count = ?, sent_at = NOW() WHERE id = ?");
            $stmt->execute([$sentCount, $id]);

            header('Location: /mail/campaigns?status=sent');

        } catch (\Exception $e) {
            header('Location: /mail/campaigns?error=' . urlencode($e->getMessage()));
        }
        exit;
    }

    public function deleteCampaign()
    {
        $this->init();
        $id = $_POST['id'] ?? 0;
        $stmt = $this->pdo->prepare("DELETE FROM cm_campaigns WHERE id = ? AND tenant_id = ?");
        $stmt->execute([$id, $this->tenantId]);
        header('Location: /mail/campaigns');
        exit;
    }

    public function createCampaignVisual()
    {
        $this->init();
        require __DIR__ . '/../views/campaigns/builder.php';
    }

    public function saveVisualCampaign()
    {
        $this->init();
        $name = $_POST['name'] ?? 'Untitled';
        $subject = $_POST['subject'] ?? $name;
        $content = $_POST['content'] ?? '';
        $listId = $_POST['list_id'] ?? 1; // Todo: Pass real list ID

        $stmt = $this->pdo->prepare("INSERT INTO cm_campaigns (tenant_id, name, subject, content, list_id, status) VALUES (?, ?, ?, ?, ?, 'draft')");
        $stmt->execute([$this->tenantId, $name, $subject, $content, $listId]);
        
        // Return JSON for AJAX
        header('Content-Type: application/json');
        echo json_encode(['status' => 'success', 'id' => $this->pdo->lastInsertId()]);
        exit;
    }

    public function uploadImage()
    {
        header('Content-Type: application/json');
        $this->init();

        if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            echo json_encode(['error' => 'Upload failed']);
            exit;
        }

        $file = $_FILES['image'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (!in_array($ext, $allowed)) {
            echo json_encode(['error' => 'Invalid file type']);
            exit;
        }

        // Storage Path (Public)
        $uploadDir = __DIR__ . '/../../../../public/storage/tenants/' . $this->tenantId . '/cloud';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $filename = uniqid('img_') . '.' . $ext;
        $destPath = $uploadDir . '/' . $filename;

        if (move_uploaded_file($file['tmp_name'], $destPath)) {
            $publicUrl = '/storage/tenants/' . $this->tenantId . '/cloud/' . $filename;
            $size = filesize($destPath);

            // Record in Casjoe Cloud
            $stmt = $this->pdo->prepare("INSERT INTO cloud_files (tenant_id, name, path, type, size_bytes) VALUES (?, ?, ?, 'image', ?)");
            $stmt->execute([$this->tenantId, $file['name'], $publicUrl, $size]);

            echo json_encode(['url' => $publicUrl]);
        } else {
            echo json_encode(['error' => 'Failed to save file']);
        }
        exit;
    }

    public function deleteTemplate()
    {
        $this->init();
        $id = $_POST['id'] ?? 0;
        $stmt = $this->pdo->prepare("DELETE FROM cm_templates WHERE id = ? AND tenant_id = ?");
        $stmt->execute([$id, $this->tenantId]);
        header('Location: /mail/templates');
        exit;
    }
    public function track()
    {
        $hash = $_GET['h'] ?? '';
        if ($hash) {
            $this->init();
            // Update Stats
            $stmt = $this->pdo->prepare("UPDATE cm_analytics SET status = 'opened', opened_at = NOW() WHERE hash = ? AND status != 'opened'");
            $stmt->execute([$hash]);
        }

        // Serve 1x1 GIF
        header('Content-Type: image/gif');
        echo base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
        exit;
    }
}
