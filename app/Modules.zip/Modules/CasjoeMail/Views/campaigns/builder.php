<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Email Builder | Casjoe Mail</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        :root { --primary-color: #000066; --accent-color: #FFA600; --bg-color: #f4f6f8; }
        body { background-color: var(--bg-color); height: 100vh; overflow: hidden; font-family: 'Inter', sans-serif; }
        
        /* Header */
        .builder-header { height: 60px; background: white; border-bottom: 1px solid #ddd; display: flex; align-items: center; justify-content: space-between; padding: 0 20px; }
        .back-link { text-decoration: none; color: #666; font-weight: 500; display: flex; align-items: center; gap: 5px; }
        
        /* Main Layout */
        .builder-container { display: flex; height: calc(100vh - 60px); }
        
        /* Sidebar (Tools) */
        .sidebar { width: 300px; background: white; border-right: 1px solid #ddd; display: flex; flex-direction: column; }
        .sidebar-tabs { display: flex; border-bottom: 1px solid #ddd; }
        .sidebar-tab { flex: 1; padding: 15px; text-align: center; cursor: pointer; font-weight: 600; color: #666; background: #fff; border: none; }
        .sidebar-tab.active { color: var(--primary-color); border-bottom: 2px solid var(--primary-color); }
        .sidebar-content { padding: 20px; overflow-y: auto; flex: 1; }
        
        /* Blocks Grid */
        .blocks-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .draggable-block { 
            background: #f8f9fa; border: 1px solid #ddd; border-radius: 8px; padding: 15px; 
            text-align: center; cursor: grab; transition: all 0.2s; 
        }
        .draggable-block:hover { border-color: var(--primary-color); box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .draggable-block i { font-size: 24px; color: #555; margin-bottom: 5px; display: block; }
        .draggable-block span { font-size: 12px; color: #777; font-weight: 600; }

        /* Canvas */
        .canvas-area { flex: 1; background: #eef1f5; padding: 40px; overflow-y: auto; display: flex; justify-content: center; }
        .email-canvas { 
            width: 600px; min-height: 800px; background: white; box-shadow: 0 4px 25px rgba(0,0,0,0.05); 
            padding: 0; position: relative; 
        }
        .drop-zone { min-height: 100%; padding: 20px; }
        
        /* Canvas Blocks */
        .canvas-block { position: relative; border: 2px solid transparent; min-height: 20px; }
        .canvas-block:hover { border-color: rgba(0, 0, 102, 0.3); }
        .canvas-block.selected { border-color: var(--primary-color); }
        
        .block-actions { 
            position: absolute; right: -30px; top: 0; display: none; flex-direction: column; gap: 5px; 
        }
        .canvas-block:hover .block-actions, .canvas-block.selected .block-actions { display: flex; }
        .action-btn { 
            width: 24px; height: 24px; background: var(--primary-color); color: white; 
            border: none; border-radius: 4px; font-size: 12px; cursor: pointer; display: flex; align-items: center; justify-content: center;
        }
        .action-btn.delete { background: #dc3545; }

        /* Properties Panel */
        .properties-panel { 
            width: 300px; background: white; border-left: 1px solid #ddd; padding: 20px; 
            overflow-y: auto; display: none; /* Hidden by default until selection */
        }
        .properties-panel.active { display: block; }

        /* AI Box */
        .ai-assistant { background: linear-gradient(135deg, #f6f8ff 0%, #f0fff4 100%); border: 1px solid #dce4ff; border-radius: 8px; padding: 15px; margin-bottom: 20px; }
        .ai-title { display: flex; align-items: center; gap: 8px; font-weight: 700; color: var(--primary-color); margin-bottom: 10px; }
        
        /* Ghost Drag */
        .gu-mirror { position: fixed !important; margin: 0 !important; z-index: 9999 !important; opacity: 0.8; }
        .gu-hide { display: none !important; }
        .gu-unselectable { user-select: none !important; }
        .gu-transit { opacity: 0.2; }

    </style>
</head>
<body>

<!-- Header -->
<header class="builder-header">
    <div class="d-flex align-items-center gap-3">
        <a href="/mail" class="back-link"><i class="bi bi-arrow-left"></i> Exit</a>
        <div class="vr mx-2"></div>
        <input type="text" id="campaignName" class="form-control form-control-sm border-0 fw-bold" style="width: 200px;" value="Untitled Campaign">
    </div>
    <div class="d-flex align-items-center gap-2">
        <button class="btn btn-outline-secondary btn-sm" onclick="previewEmail()">Preview</button>
        <button class="btn btn-primary btn-sm" onclick="saveCampaign()">Next: Review & Send <i class="bi bi-arrow-right"></i></button>
    </div>
</header>

<div class="builder-container">
    
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-tabs">
            <button class="sidebar-tab active" onclick="switchTab('blocks')">Content</button>
            <button class="sidebar-tab" onclick="switchTab('ai')"><i class="bi bi-stars text-warning"></i> AI</button>
        </div>

        <!-- Blocks Tab -->
        <div id="tab-blocks" class="sidebar-content">
            <h6 class="text-uppercase text-muted small fw-bold mb-3">Drag to Canvas</h6>
            <div class="blocks-grid">
                <div class="draggable-block" data-type="text">
                    <i class="bi bi-fonts"></i>
                    <span>Text</span>
                </div>
                <div class="draggable-block" data-type="image">
                    <i class="bi bi-image"></i>
                    <span>Image</span>
                </div>
                <div class="draggable-block" data-type="button">
                    <i class="bi bi-bounding-box"></i>
                    <span>Button</span>
                </div>
                <div class="draggable-block" data-type="video">
                    <i class="bi bi-play-btn"></i>
                    <span>Video</span>
                </div>
                <div class="draggable-block" data-type="html">
                    <i class="bi bi-code-slash"></i>
                    <span>HTML</span>
                </div>
                <div class="draggable-block" data-type="divider">
                    <i class="bi bi-hr"></i>
                    <span>Divider</span>
                </div>
                <div class="draggable-block" data-type="spacer">
                    <i class="bi bi-distribute-vertical"></i>
                    <span>Spacer</span>
                </div>
                <div class="draggable-block" data-type="social">
                    <i class="bi bi-share"></i>
                    <span>Social</span>
                </div>
            </div>
            
            <div class="mt-4">
                <label class="form-label small fw-bold text-muted">Page Background</label>
                <div class="mb-2">
                    <label class="small text-muted">Background Color</label>
                    <input type="color" class="form-control form-control-color w-100" id="globalBgColor" value="#ffffff" onchange="updateCanvasBg(this.value)">
                </div>
                <div class="mb-2">
                    <label class="small text-muted">Background Image URL</label>
                    <input type="text" class="form-control form-control-sm" placeholder="https://..." onchange="updateCanvasBgImage(this.value)">
                </div>
            </div>
        </div>

        <!-- AI Tab -->
        <div id="tab-ai" class="sidebar-content" style="display: none;">
            <div class="ai-assistant">
                <div class="ai-title"><i class="bi bi-stars"></i> Casjoe AI Rewrite</div>
                <p class="small text-muted mb-2">Select a text block, then ask AI to improve it.</p>
                <textarea id="aiPrompt" class="form-control mb-2" rows="3" placeholder="e.g. Make this sound exciting..."></textarea>
                <button class="btn btn-primary btn-sm w-100" onclick="generateAI()"><i class="bi bi-magic"></i> Generate</button>
            </div>
        </div>

    </aside>

    <!-- Canvas -->
    <main class="canvas-area">
        <div id="emailCanvas" class="email-canvas">
            <div id="dropZone" class="drop-zone">
                <!-- Drop Content Here -->
                <div class="text-center text-muted py-5 empty-placeholder">
                    <i class="bi bi-arrow-left-circle fs-1 mb-2"></i>
                    <p>Drag content blocks here</p>
                </div>
            </div>
        </div>
    </main>

    <!-- Properties Panel -->
    <aside class="properties-panel" id="propertiesPanel">
        <h6 class="text-uppercase text-muted small fw-bold mb-3">Block Settings</h6>
        <div id="propertiesContent">
            <!-- Dynamic Content -->
        </div>
        <button class="btn btn-danger btn-sm w-100 mt-4" onclick="deleteSelectedBlock()">Remove Block</button>
    </aside>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/dragula/3.7.3/dragula.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dragula/3.7.3/dragula.min.css">

<script>
    // --- State ---
    let selectedBlock = null;
    let drake;

    // --- Init ---
    document.addEventListener('DOMContentLoaded', () => {
        initDragAndDrop();
        initCanvasClicks();
    });

    function initDragAndDrop() {
        const containers = [
            document.querySelector('.blocks-grid'),
            document.getElementById('dropZone')
        ];

        drake = dragula(containers, {
            copy: function (el, source) {
                return source.classList.contains('blocks-grid');
            },
            accepts: function (el, target) {
                return target.id === 'dropZone';
            },
            moves: function (el, container, handle) {
                 return true; 
            }
        });

        drake.on('drop', function (el, target, source) {
            if (target && target.id === 'dropZone') {
                if (source.classList.contains('blocks-grid')) {
                    const type = el.getAttribute('data-type');
                    const newBlock = createBlockElement(type);
                    el.replaceWith(newBlock);
                    selectBlock(newBlock);
                    
                    const placeholder = document.querySelector('.empty-placeholder');
                    if (placeholder) placeholder.remove();
                }
            }
        });
    }

    function createBlockElement(type) {
        const div = document.createElement('div');
        div.className = 'canvas-block';
        div.setAttribute('data-type', type);
        
        let innerHTML = '';
        switch(type) {
            case 'text':
                innerHTML = `<div style="padding: 10px; font-family: sans-serif; color: #333333; font-size: 16px; line-height: 1.5;"><h3>Heading</h3><p>Start writing your email content here...</p></div>`;
                break;
            case 'image':
                innerHTML = `<div style="padding: 10px; text-align: center;"><img src="https://via.placeholder.com/560x200?text=Upload+Image" style="max-width: 100%; height: auto; border-radius: 4px;"></div>`;
                break;
            case 'button':
                innerHTML = `<div style="padding: 20px; text-align: center;"><a href="#" class="btn-element" style="background-color: #000066; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block; font-weight: bold;">Click Me</a></div>`;
                break;
            case 'video':
                innerHTML = `<div style="padding: 10px; text-align: center;"><div style="background:#000; color:#fff; padding:40px; border-radius:8px;">▶ Video Placeholder</div></div>`;
                break;
            case 'html':
                innerHTML = `<div class="html-content" style="padding: 10px; border:1px dashed #ccc;">[Raw HTML Block]</div>`;
                break;
            case 'divider':
                innerHTML = `<div style="padding: 20px 10px;"><hr style="border: 0; border-top: 1px solid #ddd;"></div>`;
                break;
            case 'spacer':
                innerHTML = `<div style="height: 30px;"></div>`;
                break;
            case 'social':
                innerHTML = `<div style="padding: 15px; text-align: center;">
                    <span style="margin: 0 5px; color: #555;">FB</span>
                    <span style="margin: 0 5px; color: #555;">TW</span>
                    <span style="margin: 0 5px; color: #555;">IG</span>
                </div>`;
                break;
        }
        
        div.innerHTML = innerHTML;
        return div;
    }

    // --- Selection & Properties ---

    function initCanvasClicks() {
        document.getElementById('dropZone').addEventListener('click', (e) => {
            const block = e.target.closest('.canvas-block');
            if (block) {
                e.stopPropagation(); 
                selectBlock(block);
            } else {
                deselectAll();
            }
        });
    }

    function selectBlock(block) {
        deselectAll();
        selectedBlock = block;
        block.classList.add('selected');
        
        const panel = document.getElementById('propertiesPanel');
        const content = document.getElementById('propertiesContent');
        panel.classList.add('active');
        
        const type = block.getAttribute('data-type');
        renderProperties(type, block);
    }

    function deselectAll() {
        document.querySelectorAll('.canvas-block.selected').forEach(el => el.classList.remove('selected'));
        selectedBlock = null;
        document.getElementById('propertiesPanel').classList.remove('active');
    }

    function renderProperties(type, block) {
        const container = document.getElementById('propertiesContent');
        container.innerHTML = '';
        
        container.innerHTML += `
            <div class="mb-3">
                <label class="form-label small text-muted">Padding (Vertical)</label>
                <input type="range" class="form-range" min="0" max="60" value="10" oninput="updateBlockPadding(this.value)">
            </div>
        `;

        if (type === 'text') {
            const div = block.querySelector('div');
            const currentFontSize = parseInt(div.style.fontSize) || 16;
            const currentColor = rgbToHex(div.style.color) || '#333333';
            const currentFont = div.style.fontFamily.replace(/"/g, '') || 'sans-serif';

            container.innerHTML += `
                <div class="mb-3">
                    <label class="form-label small text-muted">Text Content</label>
                    <textarea class="form-control" rows="5" oninput="updateTextContent(this.value)">${block.innerText}</textarea>
                </div>
                
                <div class="row g-2 mb-3">
                    <div class="col-6">
                         <label class="form-label small text-muted">Font Family</label>
                         <select class="form-select form-select-sm" onchange="updateFontFamily(this.value)">
                            <option value="sans-serif" ${currentFont.includes('sans-serif') ? 'selected' : ''}>Sans Serif</option>
                            <option value="Arial, sans-serif" ${currentFont.includes('Arial') ? 'selected' : ''}>Arial</option>
                            <option value="'Helvetica Neue', Helvetica, sans-serif" ${currentFont.includes('Helvetica') ? 'selected' : ''}>Helvetica</option>
                            <option value="'Times New Roman', Times, serif" ${currentFont.includes('Times') ? 'selected' : ''}>Times New Roman</option>
                            <option value="'Courier New', Courier, monospace" ${currentFont.includes('Courier') ? 'selected' : ''}>Courier New</option>
                            <option value="Verdana, sans-serif" ${currentFont.includes('Verdana') ? 'selected' : ''}>Verdana</option>
                            <option value="Georgia, serif" ${currentFont.includes('Georgia') ? 'selected' : ''}>Georgia</option>
                         </select>
                    </div>
                    <div class="col-6">
                        <label class="form-label small text-muted">Text Color</label>
                        <input type="color" class="form-control form-control-color w-100" value="${currentColor}" oninput="updateTextColor(this.value)">
                    </div>
                </div>

                <div class="row g-2 mb-3">
                    <div class="col-6">
                        <label class="form-label small text-muted">Font Size (px)</label>
                        <input type="number" class="form-control form-control-sm" value="${currentFontSize}" min="8" max="200" oninput="updateFontSize(this.value)">
                    </div>
                    <div class="col-6">
                        <label class="form-label small text-muted">Text Align</label>
                        <select class="form-select form-select-sm" onchange="updateTextAlign(this.value)">
                            <option value="left">Left</option>
                            <option value="center">Center</option>
                            <option value="right">Right</option>
                            <option value="justify">Justify</option>
                        </select>
                    </div>
                </div>
            `;
        }

        if (type === 'button') {
            const btn = block.querySelector('a');
            const text = btn.innerText;
            const url = btn.getAttribute('href');

            container.innerHTML += `
                <div class="mb-3">
                    <label class="form-label small text-muted">Button Text</label>
                    <input type="text" class="form-control" value="${text}" oninput="updateBtnText(this.value)">
                </div>
                <div class="mb-3">
                    <label class="form-label small text-muted">Link URL</label>
                    <input type="text" class="form-control" value="${url}" oninput="updateBtnLink(this.value)">
                </div>
                <div class="mb-3">
                    <label class="form-label small text-muted">Button Color</label>
                    <input type="color" class="form-control form-control-color w-100" value="#000066" onchange="updateBtnColor(this.value)">
                </div>
            `;
        }
        
        if (type === 'image') {
            container.innerHTML += `
                 <div class="mb-3">
                    <label class="form-label small text-muted">Image URL</label>
                    <input type="text" class="form-control" id="imgUrlInput" placeholder="https://..." onchange="updateImageSrc(this.value)">
                    <div class="mt-2">
                        <label class="form-label small text-muted">Or Upload File</label>
                        <input type="file" class="form-control form-control-sm" id="imgUploadInput" accept="image/*" onchange="uploadImageHandler(this)">
                        <small class="text-muted d-block mt-1">Saves to Casjoe Cloud</small>
                    </div>
                </div>
            `;
        }

        if (type === 'video') {
             container.innerHTML += `
                <div class="mb-3">
                    <label class="form-label small text-muted">Video URL (YouTube/Vimeo)</label>
                    <input type="text" class="form-control" placeholder="https://youtube.com/..." onchange="updateVideoSrc(this.value)">
                </div>
            `;
        }

        if (type === 'html') {
             container.innerHTML += `
                <div class="mb-3">
                    <label class="form-label small text-muted">Raw HTML</label>
                    <textarea class="form-control font-monospace" rows="8" oninput="updateHtmlContent(this.value)"></textarea>
                </div>
            `;
        }
    }

    // --- Update Logic ---

    function updateTextContent(val) {
         if(selectedBlock) selectedBlock.querySelector('div').innerHTML = val;
    }
    
    function updateTextAlign(val) {
        if(selectedBlock) selectedBlock.querySelector('div').style.textAlign = val;
    }

    function updateFontFamily(val) {
        if(selectedBlock) selectedBlock.querySelector('div').style.fontFamily = val;
    }

    function updateTextColor(val) {
        if(selectedBlock) selectedBlock.querySelector('div').style.color = val;
    }

    function updateFontSize(val) {
        if(selectedBlock) selectedBlock.querySelector('div').style.fontSize = val + 'px';
        // Also update h3/p inside if generic
        if(selectedBlock) {
             // Optional: Force elements inside to inherit or scale? 
             // Ideally we set font-size on parent DIV and let em/rem or inheritance work. 
             // But if h3 has specific size, we might need to override.
             // For simplicity, let's assume inheritance for now or direct style.
        }
    }

    function rgbToHex(rgb) {
        if(!rgb || rgb.startsWith('#')) return rgb;
        var separator = rgb.indexOf(",") > -1 ? "," : " ";
        rgb = rgb.substr(4).split(")")[0].split(separator);
        var r = (+rgb[0]).toString(16),
            g = (+rgb[1]).toString(16),
            b = (+rgb[2]).toString(16);
        if (r.length == 1) r = "0" + r;
        if (g.length == 1) g = "0" + g;
        if (b.length == 1) b = "0" + b;
        return "#" + r + g + b;
    }

    function updateBtnText(val) {
        if(selectedBlock) selectedBlock.querySelector('a').innerText = val;
    }
    
    function updateBtnLink(val) {
        if(selectedBlock) selectedBlock.querySelector('a').setAttribute('href', val);
    }
    
    function updateBtnColor(val) {
        if(selectedBlock) selectedBlock.querySelector('a').style.backgroundColor = val;
    }
    
    function updateImageSrc(val) {
         if(selectedBlock) selectedBlock.querySelector('img').src = val;
    }

    function updateVideoSrc(val) {
        if(selectedBlock) {
             // Generate standard thumbnail based on URL
             let thumb = 'https://via.placeholder.com/560x315?text=Video+Thumbnail';
             // Simple YouTube ID extraction
             const ytMatch = val.match(/(?:youtube\.com\/.*v=|youtu\.be\/)([^&]+)/);
             if(ytMatch) {
                 thumb = `https://img.youtube.com/vi/${ytMatch[1]}/hqdefault.jpg`;
             }
             
             selectedBlock.querySelector('div').innerHTML = `
                <a href="${val}" target="_blank" style="text-decoration:none; display:block; position:relative;">
                    <img src="${thumb}" style="width:100%; border-radius:8px;">
                    <div style="position:absolute; top:50%; left:50%; transform:translate(-50%, -50%); background:rgba(0,0,0,0.7); width:60px; height:40px; border-radius:10px; display:flex; align-items:center; justify-content:center;">
                        <span style="color:#fff; font-size:20px;">▶</span>
                    </div>
                </a>`;
        }
    }

    function updateHtmlContent(val) {
        if(selectedBlock) {
            selectedBlock.querySelector('.html-content').innerHTML = val;
        }
    }

    function updateCanvasBg(val) {
        document.getElementById('emailCanvas').style.backgroundColor = val;
    }

    function updateCanvasBgImage(val) {
        const url = val ? `url('${val}')` : 'none';
        document.getElementById('emailCanvas').style.backgroundImage = url;
        document.getElementById('emailCanvas').style.backgroundSize = 'cover';
    }

    async function uploadImageHandler(input) {
        if (input.files && input.files[0]) {
            const formData = new FormData();
            formData.append('image', input.files[0]);

            const btn = input;
            btn.disabled = true;

            try {
                const res = await fetch('/mail/upload-image', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                
                if (data.url) {
                    updateImageSrc(data.url);
                    document.getElementById('imgUrlInput').value = data.url;
                } else {
                    alert('Upload Failed: ' + (data.error || 'Unknown Error'));
                }
            } catch (e) {
                alert('Connection Error');
            } finally {
                btn.disabled = false;
            }
        }
    }

    function deleteSelectedBlock() {
        if(selectedBlock) {
            selectedBlock.remove();
            deselectAll();
        }
    }
    
    function switchTab(tab) {
        document.querySelectorAll('.sidebar-tab').forEach(el => el.classList.remove('active'));
        document.querySelectorAll('.sidebar-content').forEach(el => el.style.display = 'none');
        
        document.querySelector(`.sidebar-tab[onclick="switchTab('${tab}')"]`).classList.add('active');
        document.getElementById(`tab-${tab}`).style.display = 'block';
    }

    function saveCampaign() {
        const canvas = document.getElementById('dropZone').cloneNode(true);
        canvas.querySelectorAll('.canvas-block').forEach(el => {
            el.classList.remove('canvas-block', 'selected');
            el.style.border = 'none';
        });
        
        const htmlContent = canvas.innerHTML;
        const name = document.getElementById('campaignName').value;
        const listId = '1'; 

        const formData = new FormData();
        formData.append('name', name);
        formData.append('subject', name); 
        formData.append('content', htmlContent);
        formData.append('list_id', listId);
        
        fetch('/mail/campaigns/save-visual', { method: 'POST', body: formData })
        .then(res => { window.location.href = '/mail/campaigns'; });
    }

    function previewEmail() {
        const canvas = document.getElementById('dropZone').cloneNode(true);
        canvas.querySelectorAll('.canvas-block').forEach(el => {
            el.classList.remove('canvas-block', 'selected');
            el.style.border = 'none';
            const actions = el.querySelector('.block-actions');
            if(actions) actions.remove();
        });
        const html = canvas.innerHTML;

        const modalBody = document.querySelector('#previewModal .modal-body');
        modalBody.innerHTML = `
            <div style="background:#fff; padding:20px; max-width:600px; margin:0 auto; border:1px solid #ddd;">
                ${html}
            </div>
        `;
        const modal = new bootstrap.Modal(document.getElementById('previewModal'));
        modal.show();
    }

</script>

<!-- Preview Modal -->
<div class="modal fade" id="previewModal" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content bg-light">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Campaign Preview</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <!-- Content goes here -->
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
