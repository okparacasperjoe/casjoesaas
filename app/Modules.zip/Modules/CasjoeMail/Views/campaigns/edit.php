<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Campaign | Casjoe Mail</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        .editor-container {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 20px;
            height: calc(100vh - 100px);
        }
        .tools-panel {
            background: white;
            padding: 20px;
            border-radius: 10px;
            overflow-y: auto;
            border: 1px solid var(--glass-border);
        }
        .preview-panel {
            background: white;
            padding: 0;
            border-radius: 10px;
            border: 1px solid #ccc;
            overflow: hidden;
        }
        .editor {
            width: 100%;
            height: 100%;
            border: none;
            padding: 20px;
            resize: none;
            outline: none;
            font-family: monospace;
            font-size: 14px;
        }
    </style>
</head>
<body>
<div class="app-container">
    <aside class="sidebar">
        <div class="brand">
            <ion-icon name="mail-unread-outline" style="color: var(--secondary); font-size: 1.8rem;"></ion-icon>
            <span>Casjoe Mail</span>
        </div>
        <ul class="nav-menu">
            <li class="nav-item"><a href="/mail" class="nav-link"><ion-icon name="speedometer-outline"></ion-icon> Dashboard</a></li>
            <li class="nav-item"><a href="/mail/campaigns" class="nav-link active"><ion-icon name="paper-plane-outline"></ion-icon> Campaigns</a></li>
            <li class="nav-item"><a href="/mail/lists" class="nav-link"><ion-icon name="people-outline"></ion-icon> Subscribers</a></li>
            <li class="nav-item"><a href="/mail/templates" class="nav-link"><ion-icon name="duplicate-outline"></ion-icon> Templates</a></li>
             <li class="nav-item"><a href="/dashboard" class="nav-link"><ion-icon name="arrow-back-outline"></ion-icon> Back to Apps</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <form action="/mail/campaigns/update" method="POST" style="height: 100%;">
            <input type="hidden" name="id" value="<?= $campaign['id'] ?>">
            
            <div class="top-bar">
                <h2>Edit Campaign</h2>
                <div>
                     <a href="/mail/campaigns" class="btn" style="background: transparent; color: #333; border: 1px solid #ccc; margin-right: 10px;">Cancel</a>
                    <button type="submit" class="btn">Save Changes</button>
                </div>
            </div>

            <div class="editor-container">
                <div class="tools-panel">
                    <div class="form-group">
                        <label>Campaign Name</label>
                        <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($campaign['name']) ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Email Subject</label>
                        <input type="text" name="subject" class="form-control" value="<?= htmlspecialchars($campaign['subject']) ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Recipient List</label>
                        <select name="list_id" class="form-control" required>
                            <option value="">-- Select List --</option>
                            <?php foreach ($lists as $list): ?>
                                <option value="<?= $list['id'] ?>" <?= $campaign['list_id'] == $list['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($list['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">
                    
                    <div class="form-group">
                         <label>Load Template (Overwrites Content)</label>
                         <select class="form-control" onchange="loadTemplate(this.value)">
                            <option value="">-- Select Template --</option>
                            <?php foreach ($templates as $t): ?>
                                <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="preview-panel">
                    <textarea name="content" id="editorContent" class="editor" placeholder="HTML Content" required><?= htmlspecialchars($campaign['content']) ?></textarea>
                </div>
            </div>
        </form>
    </main>
</div>

<script>
    async function loadTemplate(id) {
        if(!id) return;
        if(!confirm('This will overwrite current content. Continue?')) return;
        
        const res = await fetch('/mail/template/get?id=' + id);
        const text = await res.text();
        document.getElementById('editorContent').value = text;
    }
</script>
</body>
</html>
