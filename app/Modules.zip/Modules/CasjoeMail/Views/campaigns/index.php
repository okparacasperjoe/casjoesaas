<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Campaigns | Casjoe Mail</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <!-- Sidebar -->
        <?php $active = 'campaigns'; include __DIR__ . '/../partials/sidebar.php'; ?>

        <main class="main-content">
            <div class="top-bar">
                <h1>Email Campaigns</h1>
                <a href="/mail/campaigns/create" class="btn">Create New Campaign</a>
            </div>

            <div class="card app-card-white" style="align-items: stretch; text-align: left;">
                <?php if (empty($campaigns)): ?>
                    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
                        <ion-icon name="mail-open-outline" style="font-size: 3rem; margin-bottom: 10px;"></ion-icon>
                        <p>No campaigns found. Start by creating your first email campaign!</p>
                    </div>
                <?php else: ?>
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="border-bottom: 1px solid var(--glass-border);">
                                <th style="padding: 15px; text-align: left;">Name</th>
                                <th style="padding: 15px; text-align: left;">Subject</th>
                                <th style="padding: 15px; text-align: left;">Status</th>
                                <th style="padding: 15px; text-align: left;">Sent To</th>
                                <th style="padding: 15px; text-align: left;">Date</th>
                                <th style="padding: 15px; text-align: right;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($campaigns as $campaign): ?>
                                <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);">
                                    <td style="padding: 15px; font-weight: 500;"><?= htmlspecialchars($campaign['name']) ?></td>
                                    <td style="padding: 15px; color: var(--text-muted);"><?= htmlspecialchars($campaign['subject']) ?></td>
                                    <td style="padding: 15px;">
                                        <span class="status-badge status-<?= $campaign['status'] == 'sent' ? 'active' : 'pending' ?>">
                                            <?= ucfirst($campaign['status']) ?>
                                        </span>
                                    </td>
                                    <td style="padding: 15px;"><?= $campaign['sent_count'] ?? 0 ?></td>
                                    <td style="padding: 15px; font-size: 0.9rem;"><?= date('M d, Y', strtotime($campaign['created_at'])) ?></td>
                                    <td style="padding: 15px; text-align: right; display: flex; justify-content: flex-end; gap: 5px;">
                                        <?php if ($campaign['status'] == 'draft'): ?>
                                            <form action="/mail/campaigns/send" method="POST" style="display:inline;" onsubmit="return confirm('Send this campaign to all subscribers?');">
                                                <input type="hidden" name="id" value="<?= $campaign['id'] ?>">
                                                <button type="submit" class="btn-sm" style="color: var(--secondary); background: none; border: none; cursor: pointer;" title="Send Now"><ion-icon name="paper-plane-outline"></ion-icon></button>
                                            </form>
                                        <?php endif; ?>
                                        
                                        <a href="/mail/campaigns/edit?id=<?= $campaign['id'] ?>" class="btn-sm" style="color: var(--primary); text-decoration: none;"><ion-icon name="create-outline"></ion-icon></a>
                                        
                                        <form action="/mail/campaigns/delete" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure?');">
                                            <input type="hidden" name="id" value="<?= $campaign['id'] ?>">
                                            <button type="submit" class="btn-sm" style="color: red; background: none; border: none; cursor: pointer;"><ion-icon name="trash-outline"></ion-icon></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
