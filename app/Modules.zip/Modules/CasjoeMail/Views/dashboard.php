<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mail Marketing | Casjoe Apps</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
<?php require_once dirname(__DIR__, 3) . '/core/Views/partials/mobile_nav.php'; ?>
<div class="app-container">
    <?php require __DIR__ . '/partials/sidebar.php'; ?>

    <main class="main-content">
        <div class="top-bar">
            <h2>Email Marketing Dashboard</h2>
            <a href="/mail/campaigns/create" class="btn btn-primary">+ New Campaign</a>
        </div>

        <!-- KPI Cards -->
        <div class="grid-3">
             <div class="card fintech-card">
                <h3>Total Subscribers</h3>
                <div style="font-size: 2.5rem; font-weight: bold; color: #000066;"><?= number_format($stats['subscribers']) ?></div>
                <small class="text-muted">Active contacts</small>
             </div>
             <div class="card fintech-card">
                <h3>Emails Sent</h3>
                <div style="font-size: 2.5rem; font-weight: bold; color: #FFA600;"><?= number_format($stats['emails_sent']) ?></div>
                <small class="text-muted">Lifetime volume</small>
             </div>
             <div class="card fintech-card">
                <h3>Campaigns Created</h3>
                <div style="font-size: 2.5rem; font-weight: bold; color: #333;"><?= number_format($stats['campaigns']) ?></div>
                <small class="text-muted">Drafts & Sent</small>
             </div>
        </div>

        <!-- Recent Activity & Quick Actions -->
        <div class="row mt-4" style="display:flex; gap:20px;">
            <div class="col-8" style="flex:2;">
                <div class="card">
                    <div class="card-header" style="display:flex; justify-content:space-between; align-items:center;">
                        <h3>Recent Campaigns</h3>
                        <a href="/mail/campaigns" class="btn btn-sm btn-outline">View All</a>
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Sent</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(empty($recentCampaigns)): ?>
                                <tr><td colspan="4" class="text-center">No campaigns yet. <a href="/mail/campaigns/create">Create one!</a></td></tr>
                            <?php else: ?>
                                <?php foreach($recentCampaigns as $camp): ?>
                                    <tr>
                                        <td><strong><?= htmlspecialchars($camp['name']) ?></strong></td>
                                        <td>
                                            <span class="badge badge-<?= $camp['status'] === 'sent' ? 'success' : 'warning' ?>">
                                                <?= ucfirst($camp['status']) ?>
                                            </span>
                                        </td>
                                        <td><?= number_format($camp['sent_count']) ?></td>
                                        <td><?= date('M j, Y', strtotime($camp['created_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="col-4" style="flex:1;">
                <div class="card">
                    <h3>Quick Actions</h3>
                    <ul class="list-group">
                        <li><a href="/mail/lists/import" class="btn-link-block">📂 Import Contacts</a></li>
                        <li><a href="/mail/campaigns/create" class="btn-link-block">✨ Create Visual Email</a></li>
                        <li><a href="/mail/templates" class="btn-link-block">🎨 Manage Templates</a></li>
                        <li><a href="/mail/forms" class="btn-link-block">📝 Signup Forms</a></li>
                    </ul>
                </div>
            </div>
        </div>

    </main>
</div>
<style>
    .fintech-card { border-left: 4px solid #000066; }
    .btn-link-block { display: block; padding: 10px; border-bottom: 1px solid #eee; text-decoration: none; color: #333; transition: background 0.2s; }
    .btn-link-block:hover { background: #f9f9f9; padding-left: 15px; }
    .card-header h3 { margin: 0; }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
    .badge { padding: 4px 8px; border-radius: 4px; font-size: 0.8rem; }
    .badge-draft { background: #eee; color: #555; }
    .badge-sent { background: #d4edda; color: #155724; }
</style>
</body>
</html>