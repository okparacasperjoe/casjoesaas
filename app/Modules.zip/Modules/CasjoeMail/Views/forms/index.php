<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Forms | Casjoe Mail</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <?php $active = 'forms'; include __DIR__ . '/../partials/sidebar.php'; ?>

        <main class="main-content">
            <div class="top-bar">
                <h1>Signup Forms</h1>
                <p>Manage subscription forms for your lists.</p>
            </div>

            <div class="card app-card-white" style="align-items: stretch; text-align: left;">
                <?php if (empty($lists)): ?>
                    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
                        <p>No lists found. Create a list first to generate a form.</p>
                        <a href="/mail/lists/create" class="btn">Create List</a>
                    </div>
                <?php else: ?>
                    <div style="display: grid; gap: 20px;">
                        <?php foreach ($lists as $list): ?>
                            <div style="border: 1px solid #eee; padding: 20px; border-radius: 8px;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                                    <h3 style="margin: 0;"><?= htmlspecialchars($list['name']) ?></h3>
                                    <a href="/mail/subscribe?id=<?= $list['id'] ?>" target="_blank" class="btn-sm" style="color: var(--primary); text-decoration: none;">
                                        <ion-icon name="open-outline"></ion-icon> View Live Form
                                    </a>
                                </div>
                                
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                                    <div>
                                        <label style="font-size: 11px; font-weight: bold; color: #666;">SHAREABLE LINK</label>
                                        <input type="text" readonly value="<?= 'http://' . $_SERVER['HTTP_HOST'] . '/mail/subscribe?id=' . $list['id'] ?>" 
                                            class="form-control" style="font-size: 13px; color: #555; background: #f9f9f9;">
                                    </div>
                                    <div>
                                        <label style="font-size: 11px; font-weight: bold; color: #666;">EMBED CODE</label>
                                        <textarea readonly class="form-control" style="height: 40px; font-size: 11px; color: #555; background: #f9f9f9; resize: none;"><iframe src="http://<?= $_SERVER['HTTP_HOST'] ?>/mail/subscribe?id=<?= $list['id'] ?>" width="100%" height="500" frameborder="0"></iframe></textarea>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
