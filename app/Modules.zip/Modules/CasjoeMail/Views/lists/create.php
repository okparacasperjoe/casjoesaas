<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create List | Casjoe Mail</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="brand">
                <ion-icon name="mail-unread-outline" style="color: var(--secondary); font-size: 1.8rem;"></ion-icon>
                <span>Casjoe Mail</span>
            </div>
            <ul class="nav-menu">
                <li class="nav-item"><a href="/mail" class="nav-link"><ion-icon name="speedometer-outline"></ion-icon> Dashboard</a></li>
                <li class="nav-item"><a href="/mail/campaigns" class="nav-link"><ion-icon name="paper-plane-outline"></ion-icon> Campaigns</a></li>
                <li class="nav-item"><a href="/mail/lists" class="nav-link active"><ion-icon name="people-outline"></ion-icon> Subscribers</a></li>
                <li class="nav-item"><a href="/mail/templates" class="nav-link"><ion-icon name="duplicate-outline"></ion-icon> Templates</a></li>
                <li class="nav-item"><a href="/dashboard" class="nav-link"><ion-icon name="arrow-back-outline"></ion-icon> Back to Apps</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h1>Create Subscriber List</h1>
                <a href="/mail/lists" class="btn-sm" style="color: var(--text-color);"><ion-icon name="arrow-back-outline"></ion-icon> Back</a>
            </div>

            <div style="max-width: 600px; padding: 0;">
                <div class="card app-card-white" style="align-items: stretch; text-align: left;">
                     <form action="/mail/lists/store" method="POST">
                        <div class="form-group">
                            <label>List Name</label>
                            <input type="text" name="name" class="form-control" placeholder="e.g. Newsletter Subscribers" required style="color: #333; background: #fff; border: 1px solid #ddd;">
                        </div>
                        <button type="submit" class="btn">Create List</button>
                     </form>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
