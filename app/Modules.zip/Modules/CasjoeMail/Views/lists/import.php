<?php require __DIR__ . '/../../../../views/partials/header.php'; ?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800">Import Subscribers</h1>
        <a href="/mail/lists/view?id=<?= $listId ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Back to List
        </a>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Upload CSV File</h6>
        </div>
        <div class="card-body">
            
            <?php if(isset($_GET['status']) && $_GET['status'] == 'success'): ?>
                <div class="alert alert-success">Import successful! <?= $_GET['count'] ?? 0 ?> subscribers added.</div>
            <?php endif; ?>
            
            <?php if(isset($_GET['error'])): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
            <?php endif; ?>

            <form action="/mail/lists/import-process" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="list_id" value="<?= $listId ?>">
                
                <div class="mb-4">
                    <label class="form-label fw-bold">Select CSV File</label>
                    <input type="file" name="csv_file" class="form-control" accept=".csv" required>
                    <div class="form-text mt-2">
                        <strong>Expected Columns:</strong> <code>email, first_name, last_name, company, phone, tags</code>
                        <br>
                        <em>Example:</em> <code>john@doe.com, John, Doe, Acme Corp, +12345678, "vip, lead"</code>
                    </div>
                </div>
                
                <div class="alert alert-info small">
                    <i class="bi bi-info-circle me-1"></i>
                    Does your file have headers?
                    <div class="form-check mt-2">
                         <input class="form-check-input" type="checkbox" name="has_header" id="hasHeader" checked>
                         <label class="form-check-label" for="hasHeader">Yes, skip first row</label>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-cloud-upload me-2"></i> Upload & Import
                </button>
            </form>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../../../../views/partials/footer.php'; ?>
