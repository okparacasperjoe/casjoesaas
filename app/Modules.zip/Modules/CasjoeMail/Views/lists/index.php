<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subscribers Lists | Casjoe Mail</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <!-- Sidebar -->
        <!-- Sidebar -->
        <?php $active = 'lists'; include __DIR__ . '/../partials/sidebar.php'; ?>

        <main class="main-content">
            <div class="top-bar">
                <h1>Subscriber Lists</h1>
                <a href="/mail/lists/create" class="btn">Create New List</a>
            </div>

            <div class="card app-card-white" style="align-items: stretch; text-align: left;">
                <?php if (empty($lists)): ?>
                    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
                        <ion-icon name="people-outline" style="font-size: 3rem; margin-bottom: 10px;"></ion-icon>
                        <p>No lists found. Create a list to start adding subscribers.</p>
                    </div>
                <?php else: ?>
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="border-bottom: 1px solid var(--glass-border);">
                                <th style="padding: 15px; text-align: left;">Name</th>
                                <th style="padding: 15px; text-align: left;">Subscribers</th>
                                <th style="padding: 15px; text-align: left;">Created</th>
                                <th style="padding: 15px; text-align: right;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($lists as $list): ?>
                                <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);">
                                    <td style="padding: 15px; font-weight: 500;"><?= htmlspecialchars($list['name']) ?></td>
                                    <td style="padding: 15px;"><?= $list['subscriber_count'] ?></td>
                                    <td style="padding: 15px; font-size: 0.9rem;"><?= date('M d, Y', strtotime($list['created_at'])) ?></td>
                                    <td style="padding: 15px; text-align: right;">
                                        <a href="/mail/lists/import?list_id=<?= $list['id'] ?>" class="btn-sm" style="color: var(--secondary); text-decoration: none; border: 1px solid var(--secondary); padding: 4px 10px; border-radius: 4px; margin-right: 5px;">
                                            <ion-icon name="cloud-upload-outline"></ion-icon> Import
                                        </a>
                                        <a href="/mail/lists/view?id=<?= $list['id'] ?>" class="btn-sm" style="color: var(--primary); text-decoration: none; margin-right: 10px;">Manage</a>
                                        <button class="btn-sm" style="color: red; background: none; border: none; cursor: pointer;">Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
