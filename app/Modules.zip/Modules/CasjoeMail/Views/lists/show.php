<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage List | Casjoe Mail</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="brand">
                <ion-icon name="mail-unread-outline" style="color: var(--secondary); font-size: 1.8rem;"></ion-icon>
                <span>Casjoe Mail</span>
            </div>
            <ul class="nav-menu">
                <li class="nav-item"><a href="/mail" class="nav-link"><ion-icon name="speedometer-outline"></ion-icon> Dashboard</a></li>
                <li class="nav-item"><a href="/mail/campaigns" class="nav-link"><ion-icon name="paper-plane-outline"></ion-icon> Campaigns</a></li>
                <li class="nav-item"><a href="/mail/lists" class="nav-link active"><ion-icon name="people-outline"></ion-icon> Subscribers</a></li>
                <li class="nav-item"><a href="/mail/templates" class="nav-link"><ion-icon name="duplicate-outline"></ion-icon> Templates</a></li>
                <li class="nav-item"><a href="/dashboard" class="nav-link"><ion-icon name="arrow-back-outline"></ion-icon> Back to Apps</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <h1><?= htmlspecialchars($list['name']) ?></h1>
                <a href="/mail/lists" class="btn-sm" style="color: var(--text-color);"><ion-icon name="arrow-back-outline"></ion-icon> Back</a>
            </div>
            
            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
                <!-- Subscribers List -->
                <div class="card app-card-white" style="align-items: stretch; text-align: left;">
                    <h3 style="margin-bottom: 20px;">Subscribers</h3>
                    <?php if (empty($subscribers)): ?>
                        <p style="color: var(--text-muted);">No subscribers yet.</p>
                    <?php else: ?>
                        <table style="width: 100%; border-collapse: collapse;">
                            <thead>
                                <tr style="border-bottom: 1px solid var(--glass-border);">
                                    <th style="padding: 10px; text-align: left;">Email</th>
                                    <th style="padding: 10px; text-align: left;">Name</th>
                                    <th style="padding: 10px; text-align: left;">Status</th>
                                    <th style="padding: 10px; text-align: right;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($subscribers as $sub): ?>
                                    <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);">
                                        <td style="padding: 10px;"><?= htmlspecialchars($sub['email']) ?></td>
                                        <td style="padding: 10px;"><?= htmlspecialchars($sub['first_name'] . ' ' . $sub['last_name']) ?></td>
                                        <td style="padding: 10px;"><span class="status-badge status-active">Active</span></td>
                                        <td style="padding: 10px; text-align: right;">
                                            <button style="color: red; background: none; border: none; cursor: pointer;">&times;</button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <!-- Add Subscriber Form -->
                <div class="card app-card-white" style="align-items: stretch; text-align: left; height: fit-content;">
                    <h3 style="margin-bottom: 20px;">Add Subscriber</h3>
                    <form action="/mail/lists/add-subscriber" method="POST">
                        <input type="hidden" name="list_id" value="<?= $list['id'] ?>">
                        <div class="form-group">
                            <label>Email Address</label>
                            <input type="email" name="email" class="form-control" required style="color: #333; background: #fff; border: 1px solid #ddd;">
                        </div>
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name="first_name" class="form-control" style="color: #333; background: #fff; border: 1px solid #ddd;">
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" name="last_name" class="form-control" style="color: #333; background: #fff; border: 1px solid #ddd;">
                        </div>
                        <button type="submit" class="btn" style="width: 100%">Add Subscriber</button>
                    </form>
                </div>

                <!-- Tools Card -->
                <div class="card app-card-white" style="align-items: stretch; text-align: left; height: fit-content; margin-top: 20px;">
                    <h3 style="margin-bottom: 20px;">List Tools</h3>
                    
                    <div class="mb-4">
                        <label style="font-size: 12px; font-weight: bold; color: #666; display: block; margin-bottom: 5px;">BULK IMPORT</label>
                        <a href="/mail/lists/import?list_id=<?= $list['id'] ?>" class="btn-outline" style="width: 100%; display: block; text-align: center; padding: 8px; border: 1px dashed var(--primary); color: var(--primary); border-radius: 4px; text-decoration: none;">
                            <ion-icon name="cloud-upload-outline"></ion-icon> Upload CSV
                        </a>
                    </div>

                    <div class="mb-4">
                        <label style="font-size: 12px; font-weight: bold; color: #666; display: block; margin-bottom: 5px;">PUBLIC SIGNUP LINK</label>
                        <div style="background: #f8f9fa; padding: 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 12px; word-break: break-all;">
                            <a href="/mail/subscribe?id=<?= $list['id'] ?>" target="_blank">/mail/subscribe?id=<?= $list['id'] ?></a>
                        </div>
                    </div>

                    <div>
                        <label style="font-size: 12px; font-weight: bold; color: #666; display: block; margin-bottom: 5px;">EMBED CODE</label>
                        <textarea readonly style="width: 100%; height: 80px; font-size: 11px; color: #555; border: 1px solid #ddd; border-radius: 4px; padding: 5px; resize: none;"><iframe src="http://<?= $_SERVER['HTTP_HOST'] ?>/mail/subscribe?id=<?= $list['id'] ?>" width="100%" height="500" frameborder="0"></iframe></textarea>
                    </div>

                </div>
            </div>
        </main>
    </div>
</body>
</html>
