<aside class="sidebar">
    <div class="brand">
        <ion-icon name="mail-unread-outline" style="color: var(--secondary); font-size: 1.8rem;"></ion-icon>
        <span>Casjoe Mail</span>
    </div>
    <ul class="nav-menu">
        <li class="nav-item"><a href="/mail" class="nav-link <?= $active == 'dashboard' ? 'active' : '' ?>"><ion-icon name="speedometer-outline"></ion-icon> Dashboard</a></li>
        <li class="nav-item"><a href="/mail/campaigns" class="nav-link <?= $active == 'campaigns' ? 'active' : '' ?>"><ion-icon name="paper-plane-outline"></ion-icon> Campaigns</a></li>
        <li class="nav-item"><a href="/mail/lists" class="nav-link <?= $active == 'lists' ? 'active' : '' ?>"><ion-icon name="people-outline"></ion-icon> Subscribers</a></li>
        <li class="nav-item"><a href="/mail/forms" class="nav-link <?= $active == 'forms' ? 'active' : '' ?>"><ion-icon name="clipboard-outline"></ion-icon> Signup Forms</a></li>
        <li class="nav-item"><a href="/mail/templates" class="nav-link <?= $active == 'templates' ? 'active' : '' ?>"><ion-icon name="duplicate-outline"></ion-icon> Templates</a></li>
        <li class="nav-item"><a href="/mail/settings" class="nav-link <?= $active == 'settings' ? 'active' : '' ?>"><ion-icon name="settings-outline"></ion-icon> Settings</a></li>
        <li class="nav-item"><a href="/dashboard" class="nav-link"><ion-icon name="arrow-back-outline"></ion-icon> Back to Apps</a></li>
    </ul>
</aside>
