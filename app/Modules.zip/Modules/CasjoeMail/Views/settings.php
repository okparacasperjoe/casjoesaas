<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mail Settings | Casjoe Mail</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <!-- Sidebar -->
        <?php $active = 'settings'; include __DIR__ . '/partials/sidebar.php'; ?>

        <main class="main-content">
            <div class="top-bar">
                <h1>Mail Configuration</h1>
            </div>

            <div class="card app-card-white" style="align-items: stretch; text-align: left; max-width: 600px;">
                <?php if (isset($_GET['status']) && $_GET['status'] == 'saved'): ?>
                    <div style="background: rgba(0, 128, 0, 0.1); padding: 15px; border-radius: 8px; color: green; margin-bottom: 20px; border: 1px solid green;">
                        Settings saved successfully!
                    </div>
                <?php endif; ?>

                <form method="POST" action="/mail/settings/save">
                    <h3 style="margin-bottom: 15px; color: var(--primary);">Sender Profile</h3>
                    <p style="margin-bottom: 20px; color: var(--text-muted); font-size: 0.9rem;">
                        This is how you will appear in your subscribers' inboxes. The delivery server is managed by the system administrator.
                    </p>

                    <div class="form-group">
                        <label>From Name</label>
                        <input type="text" name="from_name" class="form-control" value="<?= htmlspecialchars($settings['from_name'] ?? '') ?>" placeholder="e.g. Casjoe Sales Team" required style="color: #333; background: #fff; border: 1px solid #ddd;">
                    </div>

                    <div class="form-group">
                        <label>From Email</label>
                        <input type="email" name="from_email" class="form-control" value="<?= htmlspecialchars($settings['from_email'] ?? '') ?>" placeholder="e.g. sales@yourdomain.com" required style="color: #333; background: #fff; border: 1px solid #ddd;">
                    </div>

                    <button type="submit" class="btn" style="margin-top: 10px;">Save Changes</button>
                </form>
            </div>
        </main>
    </div>
</body>
</html>