<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Template | Casjoe Mail</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        .editor-container {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 20px;
            height: calc(100vh - 100px);
        }
        .tools-panel {
            background: white;
            padding: 20px;
            border-radius: 10px;
            border: 1px solid var(--glass-border);
        }
        .preview-panel {
            background: white;
            padding: 0;
            border-radius: 10px;
            border: 1px solid #ccc;
            overflow: hidden;
        }
        .editor {
            width: 100%;
            height: 100%;
            border: none;
            padding: 20px;
            resize: none;
            outline: none;
            font-family: monospace;
            font-size: 14px;
        }
        .preview-frame {
            width: 100%;
            height: 100%;
            border: none;
            background: #fff;
        }
        .tab-btn {
            padding: 10px 20px;
            background: #f4f6f9;
            border: none;
            cursor: pointer;
            border-right: 1px solid #ddd;
            border-bottom: 1px solid #ddd;
        }
        .tab-btn.active {
            background: white;
            border-bottom: none;
            font-weight: bold;
        }
    </style>
</head>
<body>
<div class="app-container">
    <aside class="sidebar">
        <div class="brand">
            <ion-icon name="mail-unread-outline" style="color: var(--secondary); font-size: 1.8rem;"></ion-icon>
            <span>Casjoe Mail</span>
        </div>
        <ul class="nav-menu">
            <li class="nav-item"><a href="/mail" class="nav-link"><ion-icon name="speedometer-outline"></ion-icon> Dashboard</a></li>
            <li class="nav-item"><a href="/mail/campaigns" class="nav-link"><ion-icon name="paper-plane-outline"></ion-icon> Campaigns</a></li>
            <li class="nav-item"><a href="/mail/templates" class="nav-link active"><ion-icon name="duplicate-outline"></ion-icon> Templates</a></li>
             <li class="nav-item"><a href="/dashboard" class="nav-link"><ion-icon name="arrow-back-outline"></ion-icon> Back to Apps</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <form action="/mail/templates/update" method="POST" style="height: 100%;">
            <input type="hidden" name="id" value="<?= $template['id'] ?>">
            
            <div class="top-bar">
                <h2>Edit Template</h2>
                <div>
                     <a href="/mail/templates" class="btn" style="background: transparent; color: #333; border: 1px solid #ccc; margin-right: 10px;">Cancel</a>
                    <button type="submit" class="btn">Save Template</button>
                </div>
            </div>

            <div class="editor-container">
                <div class="tools-panel">
                    <div class="form-group">
                        <label>Template Name</label>
                        <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($template['name']) ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Default Subject</label>
                        <input type="text" name="subject" class="form-control" value="<?= htmlspecialchars($template['subject']) ?>" required>
                    </div>
                </div>

                <div class="preview-panel" style="display: flex; flex-direction: column;">
                     <div style="background: #f4f6f9; border-bottom: 1px solid #ccc;">
                        <button type="button" class="tab-btn active" onclick="switchTab('code')">HTML Code</button>
                        <button type="button" class="tab-btn" onclick="switchTab('preview')">Live Preview</button>
                    </div>
                    <div id="codeView" style="flex: 1;">
                        <textarea name="content" id="editorContent" class="editor" required oninput="updatePreview()"><?= htmlspecialchars($template['content']) ?></textarea>
                    </div>
                    <div id="previewView" style="flex: 1; display: none;">
                        <iframe id="previewFrame" class="preview-frame"></iframe>
                    </div>
                </div>
            </div>
        </form>
    </main>
</div>

<script>
    function switchTab(tab) {
        if(tab === 'code') {
            document.getElementById('codeView').style.display = 'block';
            document.getElementById('previewView').style.display = 'none';
            document.querySelectorAll('.tab-btn')[0].classList.add('active');
            document.querySelectorAll('.tab-btn')[1].classList.remove('active');
        } else {
            updatePreview();
            document.getElementById('codeView').style.display = 'none';
            document.getElementById('previewView').style.display = 'block';
            document.querySelectorAll('.tab-btn')[0].classList.remove('active');
            document.querySelectorAll('.tab-btn')[1].classList.add('active');
        }
    }

    function updatePreview() {
        const html = document.getElementById('editorContent').value;
        document.getElementById('previewFrame').srcdoc = html;
    }
</script>
</body>
</html>
