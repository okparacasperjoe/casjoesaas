<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Templates | Casjoe Mail</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <!-- Sidebar -->
        <?php $active = 'templates'; include __DIR__ . '/../partials/sidebar.php'; ?>

        <main class="main-content">
            <div class="top-bar">
                <h1>Email Templates</h1>
                <a href="/mail/templates/create" class="btn">Create Template</a>
            </div>

            <div class="card app-card-white" style="align-items: stretch; text-align: left;">
                <?php if (empty($templates)): ?>
                    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
                        <ion-icon name="duplicate-outline" style="font-size: 3rem; margin-bottom: 10px;"></ion-icon>
                        <p>No templates found.</p>
                    </div>
                <?php else: ?>
                    <div class="dashboard-grid" style="grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));">
                        <?php foreach ($templates as $template): ?>
                            <div class="card" style="padding: 15px; border: 1px solid var(--glass-border);">
                                <h3 style="margin-top: 0; font-size: 1.1rem;"><?= htmlspecialchars($template['name']) ?></h3>
                                <div style="width: 100%; padding-top: 100%; position: relative; overflow: hidden; background: #f9f9f9; border-bottom: 1px solid #eee; margin-bottom: 15px;">
                                    <iframe 
                                        srcdoc="<?= htmlspecialchars($template['content']) ?>" 
                                        style="position: absolute; top: 0; left: 0; width: 400%; height: 400%; border: 0; transform: scale(0.25); transform-origin: 0 0; pointer-events: none; background: #fff;"
                                        scrolling="no"
                                    ></iframe>
                                </div>
                                <div style="display: flex; gap: 10px; align-items: center;">
                                    <a href="/mail/templates/view?id=<?= $template['id'] ?>" class="btn-sm" style="color: var(--primary);"><ion-icon name="eye-outline"></ion-icon> View</a>
                                    <a href="/mail/templates/edit?id=<?= $template['id'] ?>" class="btn-sm" style="color: var(--text-color);">Edit</a>
                                    <form action="/mail/templates/delete" method="POST" style="margin: 0;" onsubmit="return confirm('Delete this template?');">
                                        <input type="hidden" name="id" value="<?= $template['id'] ?>">
                                        <button type="submit" class="btn-sm" style="color: red; background: none; border: none; cursor: pointer;">Delete</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
