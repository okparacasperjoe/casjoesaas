<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preview Template | Casjoe Mail</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        .preview-container {
            background: white;
            border: 1px solid var(--glass-border);
            border-radius: 8px;
            padding: 20px;
            margin-top: 20px;
            min-height: 400px;
            box-shadow: var(--glass-shadow);
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="brand">
                <ion-icon name="mail-unread-outline" style="color: var(--secondary); font-size: 1.8rem;"></ion-icon>
                <span>Casjoe Mail</span>
            </div>
            <ul class="nav-menu">
                <li class="nav-item"><a href="/mail" class="nav-link"><ion-icon name="speedometer-outline"></ion-icon> Dashboard</a></li>
                <li class="nav-item"><a href="/mail/campaigns" class="nav-link"><ion-icon name="paper-plane-outline"></ion-icon> Campaigns</a></li>
                <li class="nav-item"><a href="/mail/templates" class="nav-link active"><ion-icon name="duplicate-outline"></ion-icon> Templates</a></li>
                <li class="nav-item"><a href="/mail/settings" class="nav-link"><ion-icon name="settings-outline"></ion-icon> Settings</a></li>
                <li class="nav-item"><a href="/dashboard" class="nav-link"><ion-icon name="arrow-back-outline"></ion-icon> Back to Apps</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <a href="/mail/templates" class="btn-sm" style="color: var(--text-color);"><ion-icon name="arrow-back-outline"></ion-icon> Back</a>
                    <h1>Preview: <?= htmlspecialchars($template['name']) ?></h1>
                </div>
                <div>
                     <a href="/mail/templates/edit?id=<?= $template['id'] ?>" class="btn">Edit Template</a>
                </div>
            </div>

            <!-- Preview Area -->
            <div class="preview-container">
                <iframe srcdoc="<?= htmlspecialchars($template['content']) ?>" style="width: 100%; height: 600px; border: none; background: #fff;"></iframe>
            </div>
        </main>
    </div>
</body>
</html>
