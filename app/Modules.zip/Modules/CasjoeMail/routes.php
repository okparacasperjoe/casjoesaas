<?php

use App\Core\Router;
use App\Modules\CasjoeMail\Controllers\MailController;
use App\Modules\CasjoeMail\Controllers\ListsController;
use App\Modules\CasjoeMail\Controllers\SettingsController;

// Dashboard
Router::get('/mail', [MailController::class, 'index']);
Router::get('/mail', [MailController::class, 'index']);
Router::get('/mail/settings', [SettingsController::class, 'index']);
Router::post('/mail/settings/save', [SettingsController::class, 'save']);

// Campaigns
Router::get('/mail/campaigns', [MailController::class, 'campaigns']);
Router::get('/mail/campaigns/create', [MailController::class, 'createCampaignVisual']); // Switched to Visual
Router::get('/mail/campaigns/create-legacy', [MailController::class, 'createCampaign']);
Router::post('/mail/campaigns/save-visual', [MailController::class, 'saveVisualCampaign']);
Router::post('/mail/upload-image', [MailController::class, 'uploadImage']);
Router::post('/mail/campaigns/send', [MailController::class, 'sendCampaign']);
Router::post('/mail/campaigns/delete', [MailController::class, 'deleteCampaign']);
Router::get('/mail/campaigns/edit', [MailController::class, 'editCampaign']);
Router::post('/mail/campaigns/update', [MailController::class, 'updateCampaign']);

// Lists & Forms
Router::get('/mail/lists', [ListsController::class, 'index']);
Router::get('/mail/forms', [ListsController::class, 'forms']);
Router::get('/mail/lists/create', [ListsController::class, 'create']);
Router::post('/mail/lists/store', [ListsController::class, 'store']);
Router::get('/mail/lists/view', [ListsController::class, 'show']);
Router::post('/mail/lists/add-subscriber', [ListsController::class, 'addSubscriber']);
Router::get('/mail/lists/import', [ListsController::class, 'import']);
Router::post('/mail/lists/import-process', [ListsController::class, 'processImport']);

// Public Signup
Router::get('/mail/subscribe', [ListsController::class, 'publicForm']);
Router::post('/mail/subscribe/store', [ListsController::class, 'processPublicSubscription']);
Router::get('/mail/unsubscribe', [ListsController::class, 'unsubscribe']);
Router::post('/mail/unsubscribe', [ListsController::class, 'unsubscribe']);
Router::get('/mail/track', [MailController::class, 'track']);

// AI & Templates
Router::get('/mail/templates', [MailController::class, 'templates']);
Router::get('/mail/templates/view', [MailController::class, 'viewTemplate']);
Router::post('/mail/templates/delete', [MailController::class, 'deleteTemplate']);
Router::get('/mail/templates/edit', [MailController::class, 'editTemplate']);
Router::post('/mail/templates/update', [MailController::class, 'updateTemplate']);
Router::post('/mail/ai/generate', [MailController::class, 'generateAiContent']);
Router::get('/mail/template/get', [MailController::class, 'templateContent']);
