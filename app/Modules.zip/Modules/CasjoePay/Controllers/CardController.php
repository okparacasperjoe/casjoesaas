<?php

namespace App\Modules\CasjoePay\Controllers;

use App\Core\Database;
use App\Core\Auth;
use App\Core\TenantContext;
use App\Core\Services\CurrencyService;
use App\Modules\CasjoePay\Services\SudoService;

class CardController
{
    public function index()
    {
        $user = Auth::user();
        $db = Database::getInstance();

        $stmt = $db->query("SELECT * FROM cp_virtual_cards WHERE user_id = ?", [$user['id']]);
        $cards = $stmt->fetchAll();
        
        // Fetch Fee
        $stmt = $db->query("SELECT setting_value FROM system_settings WHERE setting_key = 'virtual_card_fee'");
        $creationFee = $stmt->fetchColumn() ?: 0;

        require __DIR__ . '/../views/cards.php';
    }

    public function create()
    {
        $user = Auth::user();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
             header("Location: /pay/cards"); exit;
        }

        $fundingAmountUSD = (float) $_POST['amount']; // Amount to put on card (USD)
        $paymentCurrency = $_POST['currency'] ?? 'NGN'; // Wallet to pay from
        
        $db = Database::getInstance();

        // 1. Get Settings & Fee
        $stmt = $db->query("SELECT setting_key, setting_value FROM system_settings");
        $settings = $stmt->fetchAll(\PDO::FETCH_KEY_PAIR);
        $provider = $settings['virtual_card_provider'] ?? 'sudo';
        $feeNGN = (float)($settings['virtual_card_fee'] ?? 0); // Fee is in NGN usually

        $currencyService = new CurrencyService();
        
        // Convert Fee to USD to get Total USD Cost
        $ngnToUsdRate = $currencyService->getExchangeRate('NGN', 'USD');
        $feeUSD = $feeNGN * $ngnToUsdRate;

        // Total Required in USD
        $totalUSD = $fundingAmountUSD + $feeUSD;

        // Convert Total USD to Payment Currency
        // Rate: USD -> Payment Currency
        $exchangeRate = $currencyService->getExchangeRate('USD', $paymentCurrency);
        $totalCost = $totalUSD * $exchangeRate;

        // Validation
        if ($fundingAmountUSD < 1) { 
             $_SESSION['error'] = "Minimum funding is $1.00";
             header("Location: /pay/cards"); exit;
        }

        // 2. Check Wallet Balance
        $stmt = $db->query("SELECT balance FROM cp_wallets WHERE user_id = ? AND currency = ?", [$user['id'], $paymentCurrency]);
        $wallet = $stmt->fetch();
        $balance = $wallet['balance'] ?? 0;

        if ($balance < $totalCost) {
             $_SESSION['error'] = "Insufficient $paymentCurrency balance. Cost: " . number_format($totalCost, 2) . " $paymentCurrency (Funding $$fundingAmountUSD + Fee)";
             header("Location: /pay/cards"); exit;
        }

        // 3. Process Transaction
        $db->beginTransaction();
        try {
            // Debit Wallet
            $db->query("UPDATE cp_wallets SET balance = balance - ? WHERE user_id = ? AND currency = ?", [$totalCost, $user['id'], $paymentCurrency]);
            
            // Call Provider (Sudo/StroWallet)
            if ($provider === 'sudo') {
                $service = new SudoService();
                $cust = $service->createCustomer($user['email'], $user['name'] ?? 'User');
                $custId = $cust['data']['_id'] ?? $cust['_id'] ?? 'sudo_cust_'.uniqid();
                
                // Note: Sudo might expect NGN or USD depending on setup, usually USD for card funding if balancing from USD source.
                // Assuming our SudoService handles the API call which usually takes USD amount for the card.
                $res = $service->createCard($custId, 'USD', $fundingAmountUSD);
                 
                $cardId = $res['data']['_id'] ?? $res['_id'] ?? 'sudo_card_'.uniqid();
                $pan = $res['data']['maskedPan'] ?? $res['maskedPan'] ?? '5399****0000';
                $expM = 12; $expY = 28; 
            } else {
                // StroWallet
                $service = new \App\Modules\CasjoePay\Services\StroWalletService();
                $cust = $service->createCustomer($user['email'], $user['name']);
                $res = $service->createCard($cust['user_id'] ?? 'sw_user_'.uniqid(), 'USD', $fundingAmountUSD);
                
                $cardId = $res['card_id'] ?? 'sw_card_'.uniqid();
                $pan = $res['card_number'] ?? '4000****0000';
                $expM = 12; $expY = 29;
            }

            // Record Card
            $db->query(
                "INSERT INTO cp_virtual_cards (user_id, tenant_id, card_id, provider, start_month, start_year, masked_pan, currency, balance, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'USD', ?, 'active')",
                [$user['id'], TenantContext::getTenantId(), $cardId, $provider, $expM, $expY, $pan, $fundingAmountUSD]
            );

            // Log Transaction
            $desc = "Card Issue ($$fundingAmountUSD) + Fee. Paid with $paymentCurrency";
            $db->query("INSERT INTO cp_transactions (tenant_id, user_id, reference, amount, currency, status, type, description) VALUES (?, ?, ?, ?, ?, 'successful', 'debit', ?)", 
                [TenantContext::getTenantId(), $user['id'], 'CRD-'.uniqid(), $totalCost, $paymentCurrency, $desc]);

            $db->commit();
            header("Location: /pay/cards?success=created");

        } catch (\Exception $e) {
            $db->rollBack();
            $_SESSION['error'] = "Creation Failed: " . $e->getMessage();
            header("Location: /pay/cards");
        }
    }

    public function fundCard()
    {
        // Implementation for funding existing card
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
             // ... Similar logic ...
        }
    }
}
