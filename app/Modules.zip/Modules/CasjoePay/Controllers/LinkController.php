<?php

namespace App\Modules\CasjoePay\Controllers;

use App\Core\Database;

class LinkController
{
    private $pdo;
    private $tenantId;
    private $userId;

    public function __construct() {
        $this->pdo = Database::getInstance()->getConnection();
    }

    public function index()
    {
        // requireAuth
        if (!isset($_SESSION['user_id'])) { header('Location: /login'); exit; }
        $this->userId = $_SESSION['user_id'];
        
        $stmt = $this->pdo->prepare("SELECT * FROM cp_payment_links WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->execute([$this->userId]);
        $links = $stmt->fetchAll();

        require __DIR__ . '/../views/links/index.php';
    }

    public function create()
    {
        if (!isset($_SESSION['user_id'])) { header('Location: /login'); exit; }
        $this->userId = $_SESSION['user_id'];
        $this->tenantId = \App\Core\TenantContext::getTenantId();

        $title = $_POST['title'];
        $currency = $_POST['currency'];
        $amount = $_POST['amount'] ?: 0.00; // 0 means open
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title))) . '-' . uniqid();

        $stmt = $this->pdo->prepare("INSERT INTO cp_payment_links (tenant_id, user_id, title, slug, amount, currency) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$this->tenantId, $this->userId, $title, $slug, $amount, $currency]);

        header("Location: /pay/links");
    }

    public function pay($params)
    {
        $slug = is_array($params) ? $params['slug'] : $params; 
        $stmt = $this->pdo->prepare("SELECT * FROM cp_payment_links WHERE slug = ?");
        $stmt->execute([$slug]);
        $link = $stmt->fetch();

        if (!$link) {
            http_response_code(404);
            die("Payment Link Not Found");
        }

        // Handle Callback / Verification
        if (isset($_GET['status']) && $_GET['status'] == 'successful' && isset($_GET['tx_ref'])) {
            $this->verifyPayment($link, $_GET['tx_ref']);
            return;
        }

        // Increment Views
        $stmt = $this->pdo->prepare("UPDATE cp_payment_links SET views = views + 1 WHERE id = ?");
        $stmt->execute([$link['id']]);

        require __DIR__ . '/../views/public_pay.php';
    }

    public function process($params)
    {
        $slug = is_array($params) ? $params['slug'] : $params;
        $stmt = $this->pdo->prepare("SELECT * FROM cp_payment_links WHERE slug = ?");
        $stmt->execute([$slug]);
        $link = $stmt->fetch();

        if (!$link) die("Invalid Link");

        $amount = (float) ($_POST['amount'] ?? $link['amount']);
        // If link fixed amount, enforce it? Or logic:
        if ($link['amount'] > 0 && $amount != $link['amount']) $amount = $link['amount'];

        $email = $_POST['email'];
        $name = $_POST['name'] ?? 'Anonymous';
        $ref = 'PAY-' . uniqid() . '-' . time();
        
        try {
            $gateway = new \App\Core\Services\PaymentGatewayService();
            // Callback URL: The same link page but with query params
            $callbackUrl = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]/pay/link/$slug"; 
            
            $authUrl = $gateway->initializePayment($email, $amount, $link['currency'], $ref, $callbackUrl, [
                'name' => $name,
                'description' => $link['title'],
                'link_slug' => $slug
            ]);
            
            // Redirect user
            header("Location: $authUrl");
            exit;

        } catch (\Exception $e) {
            die("Payment Initialization Failed: " . $e->getMessage());
        }
    }

    private function verifyPayment($link, $ref)
    {
        // 1. Check if already processed
        $stmt = $this->pdo->prepare("SELECT id FROM cp_transactions WHERE reference = ?");
        $stmt->execute([$ref]);
        if ($stmt->fetch()) {
             // Already processed, just show success
             $success = true;
             $amount = 0; // display logic...
             require __DIR__ . '/../views/public_pay_success.php'; // or reuse public_pay with success flag
             return;
        }

        // 2. Verify with Gateway
        try {
            $gateway = new \App\Core\Services\PaymentGatewayService();
            $res = $gateway->verifyTransaction($ref);
            
            if (($res['status'] ?? '') === 'success' && ($res['data']['status'] ?? '') === 'successful') {
                 $txnData = $res['data'];
                 $verifiedAmount = $txnData['amount'];
                 $verifiedCurrency = $txnData['currency'];
                 
                 // 3. Credit Wallet
                 // Ensure wallet exists
                 $stmt = $this->pdo->prepare("INSERT IGNORE INTO cp_wallets (tenant_id, user_id, currency, balance) VALUES (?, ?, ?, 0.00)");
                 $stmt->execute([$link['tenant_id'], $link['user_id'], $verifiedCurrency]);
        
                 $stmt = $this->pdo->prepare("UPDATE cp_wallets SET balance = balance + ? WHERE user_id = ? AND currency = ?");
                 $stmt->execute([$verifiedAmount, $link['user_id'], $verifiedCurrency]);

                 // 4. Log Transaction
                 $desc = "Payment from " . ($txnData['customer']['email'] ?? 'User') . " for " . $link['title'];
                 $stmt = $this->pdo->prepare("INSERT INTO cp_transactions (tenant_id, user_id, reference, type, amount, currency, status, description, meta) VALUES (?, ?, ?, 'credit', ?, ?, 'successful', ?, ?)");
                 $stmt->execute([$link['tenant_id'], $link['user_id'], $ref, $verifiedAmount, $verifiedCurrency, $desc, json_encode($txnData)]);
                 
                 // Show Success
                 $success = true;
                 $amount = $verifiedAmount;
                 require __DIR__ . '/../views/public_pay_success.php';
            } else {
                 die("Payment Verification Failed or Pending.");
            }

        } catch (\Exception $e) {
             die("Verification Error: " . $e->getMessage());
        }
    }
}
