<?php

namespace App\Modules\CasjoePay\Controllers;

use App\Core\Database;
use App\Core\View;
use App\Core\Auth;
use App\Core\TenantContext;
use App\Core\SubscriptionManager;
use App\Core\Services\CurrencyService;
use App\Core\Services\CsrfService;
use PDO;

class PayController
{
    private $pdo;
    private $tenantId;
    private $userId;

    public function __construct()
    {
    }

    public function index()
    {
        $tenantId = TenantContext::getTenantId();
        SubscriptionManager::requireActive($tenantId);

        if (!isset($_SESSION['user_id'])) { // Basic auth check
            header('Location: /login');
            exit;
        }

        $this->pdo = Database::getInstance()->getConnection();
        $this->userId = $_SESSION['user_id'];
        
        // Fetch Tenant ID
        $stmt = $this->pdo->prepare("SELECT tenant_id FROM users WHERE id = ?");
        $stmt->execute([$this->userId]);
        $this->tenantId = $stmt->fetchColumn();

        // 1. Get All Wallets
        $stmt = $this->pdo->prepare("SELECT * FROM cp_wallets WHERE user_id = ?");
        $stmt->execute([$this->userId]);
        $wallets = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Ensure Default User Currency Wallet Exists
        $userCurrency = Auth::user()['currency'] ?? 'USD';
        $currencies = array_column($wallets, 'currency');
        if (!in_array($userCurrency, $currencies)) {
            $this->_createWallet($userCurrency);
            // Refresh
            $stmt->execute([$this->userId]);
            $wallets = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        // Default active wallet (User Preference)
        $activeWallet = $wallets[0] ?? ['balance' => 0, 'currency' => $userCurrency];
        foreach ($wallets as $w) {
            if ($w['currency'] === $userCurrency) $activeWallet = $w;
        }

        // 2. Get Recent Transactions
        $stmt = $this->pdo->prepare("SELECT * FROM cp_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
        $stmt->execute([$this->userId]);
        $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 3. Get Active Cards
        $stmt = $this->pdo->prepare("SELECT * FROM cp_virtual_cards WHERE user_id = ? AND status = 'active' LIMIT 3");
        $stmt->execute([$this->userId]);
        $myCards = $stmt->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../views/dashboard.php';
    }

    public function fund()
    {
        require __DIR__ . '/../views/fund.php';
    }

    public function processFund()
    {
        $this->pdo = Database::getInstance()->getConnection();
        $this->userId = $_SESSION['user_id'];
        $this->tenantId = TenantContext::getTenantId();

        $amount = $_POST['amount'];
        $currency = $_POST['currency'] ?? Auth::user()['currency'] ?? 'USD';
        $method = $_POST['method'] ?? 'card';
        $email = Auth::user()['email'] ?? $_SESSION['user_email'] ?? '';
        
        $ref = 'FLW-' . uniqid();
        
        // Metadata for payment
        $meta = json_encode(['method' => $method, 'initiated_via' => 'web']);
        
        // Create Pending Transaction
        $stmt = $this->pdo->prepare("INSERT INTO cp_transactions (tenant_id, user_id, reference, type, amount, currency, status, description, meta) VALUES (?, ?, ?, 'credit', ?, ?, 'pending', 'Wallet Funding', ?)");
        $stmt->execute([$this->tenantId, $this->userId, $ref, $amount, $currency, $meta]);
        
        // Flutterwave V4 Standard Payload
        $payload = [
            'tx_ref' => $ref,
            'amount' => $amount,
            'currency' => $currency,
            'redirect_url' => 'https://' . $_SERVER['HTTP_HOST'] . '/pay/fund/verify',
            'payment_options' => $method === 'card' ? 'card' : ($method === 'momo' ? 'mobilemoneyghana,mobilemoneyrwanda,mobilemoneyuganda,mobilemoneyzambia' : 'account,ussd,banktransfer'),
            'customer' => [
                'email' => $email,
                'name' => Auth::user()['name'] ?? 'Casjoe User'
            ],
            'customizations' => [
                'title' => 'Casjoe Pay - Wallet Funding',
                'description' => "Funding $currency wallet"
            ]
        ];

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => 'https://api.flutterwave.com/v3/payments',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . FLUTTERWAVE_SECRET_KEY,
                'Content-Type: application/json'
            ],
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            die("Payment Initialization Failed: " . $err);
        }

        $res = json_decode($response, true);
        if (isset($res['status']) && $res['status'] === 'success') {
            header('Location: ' . $res['data']['link']);
            exit;
        } else {
            die("Error from payment gateway: " . ($res['message'] ?? 'Unknown error'));
        }
    }

    public function verifyFund()
    {
        $this->pdo = Database::getInstance()->getConnection();
        $this->userId = $_SESSION['user_id'];

        $status = $_GET['status'] ?? '';
        $txRef = $_GET['tx_ref'] ?? '';
        $transactionId = $_GET['transaction_id'] ?? '';

        if (($status === 'successful' || $status === 'completed') && !empty($transactionId)) {
            
            // Verify with Flutterwave
            $curl = curl_init();
            curl_setopt_array($curl, [
                CURLOPT_URL => "https://api.flutterwave.com/v3/transactions/{$transactionId}/verify",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => [
                    "Content-Type: application/json",
                    "Authorization: Bearer " . FLUTTERWAVE_SECRET_KEY
                ],
            ]);
            
            $response = curl_exec($curl);
            $res = json_decode($response, true);
            curl_close($curl);

            if (isset($res['status']) && $res['status'] === 'success') {
                $amount = $res['data']['amount'];
                $currency = $res['data']['currency'];
                $ref = $res['data']['tx_ref'];

                $stmt = $this->pdo->prepare("UPDATE cp_transactions SET status = 'successful' WHERE reference = ? AND status = 'pending'");
                $stmt->execute([$ref]);
                
                if ($stmt->rowCount() > 0) {
                    $this->tenantId = TenantContext::getTenantId();
                    // Ensure wallet exists for this currency
                    $this->_createWallet($currency);

                    $stmt = $this->pdo->prepare("UPDATE cp_wallets SET balance = balance + ? WHERE user_id = ? AND currency = ?");
                    $stmt->execute([$amount, $this->userId, $currency]);
                    
                    header('Location: /pay?success=funded');
                    exit;
                }
            }
        }

        header('Location: /pay?error=funding_failed');
    }

    public function transfer()
    {
        require __DIR__ . '/../views/transfer.php';
    }

    public function processTransfer()
    {
        $this->pdo = Database::getInstance()->getConnection();
        $this->userId = $_SESSION['user_id'];
        $this->tenantId = TenantContext::getTenantId();

        $type = $_POST['type'] ?? 'internal';
        $amount = $_POST['amount'];
        $currency = $_POST['currency'] ?? Auth::user()['currency'] ?? 'USD'; // Sender currency

        if ($amount <= 0) die("Invalid amount");

        // 1. Debit Source Wallet
        $stmt = $this->pdo->prepare("SELECT balance FROM cp_wallets WHERE user_id = ? AND currency = ?");
        $stmt->execute([$this->userId, $currency]);
        $balance = $stmt->fetchColumn();

        if ($balance < $amount) {
            die("Insufficient Funds in $currency Wallet");
        }

        $this->pdo->beginTransaction();

        try {
            // Debit Sender
            $stmt = $this->pdo->prepare("UPDATE cp_wallets SET balance = balance - ? WHERE user_id = ? AND currency = ?");
            $stmt->execute([$amount, $this->userId, $currency]);

            if ($type === 'internal') {
                $email = $_POST['email'];
                $stmt = $this->pdo->prepare("SELECT id FROM users WHERE email = ?");
                $stmt->execute([$email]);
                $recipientId = $stmt->fetchColumn();
    
                if (!$recipientId) throw new \Exception("User not found: $email");

                // Internal Transfer: Credit Recipient
                // Ensure recipient uses same currency or auto-convert? 
                // For simplicity MVP: Same currency transfer only.
                
                // Credit Recipient
                // Helper to create wallet if needed
                // We can't use $this->_createWallet logic easily inside transaction without refactor
                // So manual Insert Ignore
                $stmt = $this->pdo->prepare("INSERT IGNORE INTO cp_wallets (tenant_id, user_id, currency, balance) VALUES (?, ?, ?, 0.00)");
                $stmt->execute([$this->tenantId, $recipientId, $currency]);

                $stmt = $this->pdo->prepare("UPDATE cp_wallets SET balance = balance + ? WHERE user_id = ? AND currency = ?");
                $stmt->execute([$amount, $recipientId, $currency]);

                $descSender = "Transfer to $email";
                $descreceiver = "Received from " . $this->_getUserEmail($this->userId);

            } elseif ($type === 'bank') {
                $bankCode = $_POST['bank_code'];
                $accNum = $_POST['account_number'];
                $descSender = "Bank Transfer to $accNum ($bankCode)";
                // External Payout: No local credit
                // In real world: Call Gateway API here
                // We'll mark as successful for simulation or pending
            } elseif ($type === 'momo') {
                $provider = $_POST['momo_provider'];
                $phone = $_POST['phone_number'];
                $descSender = "MoMo Transfer to $phone ($provider)";
                // External Payout: No local credit
            }

            // Record Sender Debit
            $ref = 'TRF-' . uniqid();
            $meta = json_encode(['type' => $type, 'details' => $_POST]);
            $stmt = $this->pdo->prepare("INSERT INTO cp_transactions (tenant_id, user_id, reference, type, amount, currency, status, description, meta) VALUES (?, ?, ?, 'debit', ?, ?, 'successful', ?, ?)");
            $stmt->execute([$this->tenantId, $this->userId, $ref, $amount, $currency, $descSender, $meta]);

            // If Internal, Record Recipient Credit
            if ($type === 'internal' && isset($recipientId)) {
                $ref2 = 'REC-' . uniqid();
                $stmt = $this->pdo->prepare("INSERT INTO cp_transactions (tenant_id, user_id, reference, type, amount, currency, status, description) VALUES (?, ?, ?, 'credit', ?, ?, 'successful', ?)");
                $stmt->execute([$this->tenantId, $recipientId, $ref2, $amount, $currency, $descreceiver]);
            }

            $this->pdo->commit();
            header('Location: /pay?success=transfer_complete');

        } catch (\Exception $e) {
            $this->pdo->rollBack();
            die("Transfer Failed: " . $e->getMessage());
        }
    }

    private function _getUserEmail($id) {
        $stmt = $this->pdo->prepare("SELECT email FROM users WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetchColumn();
    }
    private function _createWallet($currency)
    {
        $stmt = $this->pdo->prepare("INSERT IGNORE INTO cp_wallets (tenant_id, user_id, currency, balance) VALUES (?, ?, ?, 0.00)");
        $stmt->execute([$this->tenantId, $this->userId, $currency]);
    }

    // --- Currency Conversion ---

    public function convert()
    {
        // Setup Context for Convert View
        $tenantId = TenantContext::getTenantId();
        $this->pdo = Database::getInstance()->getConnection();
        $this->userId = $_SESSION['user_id'];
        
        $stmt = $this->pdo->prepare("SELECT * FROM cp_wallets WHERE user_id = ?");
        $stmt->execute([$this->userId]);
        $wallets = $stmt->fetchAll(PDO::FETCH_ASSOC);

        require __DIR__ . '/../views/convert.php';
    }

    public function getRate()
    {
        header('Content-Type: application/json');
        $from = $_GET['from'] ?? 'USD';
        $to = $_GET['to'] ?? 'NGN';
        
        $service = new CurrencyService();
        $rate = $service->getExchangeRate($from, $to);
        
        echo json_encode(['rate' => $rate]);
        exit;
    }

    public function processConversion()
    {
        if (!CsrfService::verifyToken($_POST['csrf_token'] ?? '')) {
             die("CSRF Token Verification Failed");
        }

        $this->pdo = Database::getInstance()->getConnection();
        $this->userId = $_SESSION['user_id'];
        $this->tenantId = TenantContext::getTenantId();

        $from = $_POST['from_currency'];
        $to = $_POST['to_currency'];
        $amount = (float)$_POST['amount'];

        if ($from === $to) {
            header('Location: /pay/convert?error=Same currency selected');
            exit;
        }

        // 1. Check Balance
        $stmt = $this->pdo->prepare("SELECT balance FROM cp_wallets WHERE user_id = ? AND currency = ?");
        $stmt->execute([$this->userId, $from]);
        $balance = $stmt->fetchColumn();

        if ($balance < $amount) {
            header("Location: /pay/convert?error=Insufficient $from balance");
            exit;
        }

        // 2. Get Rate
        $service = new CurrencyService();
        $result = $service->convert($amount, $from, $to);
        $targetAmount = $result['amount'];
        $rate = $result['rate'];

        if ($rate <= 0) {
            header('Location: /pay/convert?error=Exchange rate unavailable');
            exit;
        }

        // 3. Process Transaction
        $this->pdo->beginTransaction();
        try {
            // Debit Source
            $stmt = $this->pdo->prepare("UPDATE cp_wallets SET balance = balance - ? WHERE user_id = ? AND currency = ?");
            $stmt->execute([$amount, $this->userId, $from]);

            // Ensure Target Wallet Exists
            $this->_createWallet($to);

            // Credit Target
            $stmt = $this->pdo->prepare("UPDATE cp_wallets SET balance = balance + ? WHERE user_id = ? AND currency = ?");
            $stmt->execute([$targetAmount, $this->userId, $to]);

            // Record Transactions
            $ref = 'CNV-' . uniqid();
            
            // Debit Record
            $tStmt = $this->pdo->prepare("INSERT INTO cp_transactions (tenant_id, user_id, reference, type, amount, currency, status, description) VALUES (?, ?, ?, 'debit', ?, ?, 'successful', ?)");
            $tStmt->execute([$this->tenantId, $this->userId, $ref . '-D', $amount, $from, "Converted to $to"]);

            // Credit Record
            $tStmt->execute([$this->tenantId, $this->userId, $ref . '-C', $targetAmount, $to, "Converted from $from (@ $rate)"]);

            $this->pdo->commit();
            header('Location: /pay?success=conversion_complete');

        } catch (\Exception $e) {
            $this->pdo->rollBack();
            header('Location: /pay/convert?error=Transaction failed');
        }
    }
}
