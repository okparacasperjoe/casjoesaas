<?php

namespace App\Modules\CasjoePay\Services;

class StroWalletService
{
    private $publicKey;
    private $secretKey;
    private $baseUrl = 'https://api.strowallet.com/v1'; // Verify actual URL

    public function __construct()
    {
        $this->publicKey = defined('STROWALLET_PUBLIC_KEY') ? STROWALLET_PUBLIC_KEY : '';
        $this->secretKey = defined('STROWALLET_SECRET_KEY') ? STROWALLET_SECRET_KEY : '';
    }

    private function request($endpoint, $method = 'GET', $data = [])
    {
        $curl = curl_init();
        
        $headers = [
            'Authorization: Bearer ' . $this->secretKey, // Or Public depending on endpoint
            'Content-Type: application/json',
            'Accept: application/json'
        ];

        $options = [
            CURLOPT_URL => $this->baseUrl . $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
        ];

        if ($method === 'POST' || $method === 'PUT') {
            $options[CURLOPT_POSTFIELDS] = json_encode($data);
        }

        curl_setopt_array($curl, $options);
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) throw new \Exception("StroWallet API Error: " . $err);

        return json_decode($response, true);
    }

    public function createCustomer($email, $name, $phone = '')
    {
        // StroWallet often requires creating a user first
        return $this->request('/create-user', 'POST', [
            'email' => $email,
            'name' => $name,
            'phone' => $phone
        ]);
    }

    public function createCard($customerId, $currency = 'USD', $amount = 0)
    {
        // Assuming endpoint structure
        return $this->request('/create-card', 'POST', [
            'user_id' => $customerId, // or email
            'card_type' => 'virtual',
            'amount' => $amount
        ]);
        // Note: Actual payload depends on docs, using generic assumption
    }

    public function fundCard($cardId, $amount)
    {
        return $this->request("/fund-card", 'POST', [
            'card_id' => $cardId,
            'amount' => $amount
        ]);
    }
}
