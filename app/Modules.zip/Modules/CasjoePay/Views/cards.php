<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cards | Casjoe Pay</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <style>
        .virtual-card {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 20px;
            padding: 25px;
            color: white;
            width: 340px;
            height: 215px; /* Credit Card Ratio */
            position: relative;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.5);
            display: inline-block;
            margin-right: 25px;
            margin-bottom: 25px;
            vertical-align: top;
            border: 1px solid rgba(255, 255, 255, 0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .virtual-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6);
        }
        /* Glass Effect Overlay */
        .virtual-card::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 60%);
            transform: rotate(30deg);
            pointer-events: none;
        }

        .card-brand {
            position: absolute;
            top: 25px;
            right: 25px;
            font-size: 1.5rem;
            font-weight: bold;
            font-style: italic;
            opacity: 0.8;
        }

        .card-chip {
            width: 50px;
            height: 35px;
            background: linear-gradient(135deg, #ffd700 0%, #b8860b 100%);
            border-radius: 6px;
            margin-bottom: 30px;
            margin-top: 10px;
            position: relative;
            box-shadow: inset 0 1px 3px rgba(0,0,0,0.3);
        }
        /* Chip Lines */
        .card-chip::after {
            content: '';
            position: absolute;
            top: 50%; left: 0; width: 100%; height: 1px; background: rgba(0,0,0,0.3);
        }
        .card-chip::before {
            content: '';
            position: absolute; left: 50%; top: 0; height: 100%; width: 1px; background: rgba(0,0,0,0.3);
        }

        .card-number {
            font-size: 1.4rem;
            letter-spacing: 3px;
            margin-bottom: 25px;
            font-family: 'Courier New', monospace;
            text-shadow: 0 2px 4px rgba(0,0,0,0.5);
        }

        .card-meta {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .card-holder {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        .card-expiry {
            text-align: right;
        }
        .dummy-label { font-size: 0.6rem; opacity: 0.6; margin-bottom: 2px; display: block; }
    </style>
</head>

<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="brand">
                <ion-icon name="card"></ion-icon>
                Casjoe<span>Pay</span>
            </div>
        <ul class="nav-menu">
            <li class="nav-item"><a href="/dashboard" class="nav-link"><ion-icon name="speedometer-outline"></ion-icon> Dashboard</a></li>
            <li class="nav-item"><a href="/pay" class="nav-link"><ion-icon name="wallet-outline"></ion-icon> Casjoe Pay</a></li>
            <li class="nav-item"><a href="/pay/fund" class="nav-link"><ion-icon name="add-circle-outline"></ion-icon> Fund Wallet</a></li>
            <li class="nav-item"><a href="/pay/transfer" class="nav-link"><ion-icon name="paper-plane-outline"></ion-icon> Transfer</a></li>
            <li class="nav-item"><a href="/pay/cards" class="nav-link active"><ion-icon name="card-outline"></ion-icon> Virtual Cards</a></li>
            <li class="nav-item"><a href="/pay/links" class="nav-link"><ion-icon name="link-outline"></ion-icon> Payment Links</a></li>
            <li class="nav-item"><a href="/pay/convert" class="nav-link"><ion-icon name="swap-horizontal-outline"></ion-icon> Convert Currency</a></li>
            <li class="nav-item"><a href="/logout" class="nav-link"><ion-icon name="log-out-outline"></ion-icon> Logout</a></li>
        </ul>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <div class="top-bar">
                <h1>Virtual Cards</h1>
            </div>

            <div style="margin-bottom: 30px;">
                <?php if (empty($cards)): ?>
                    <div
                        style="background: rgba(255,255,255,0.05); padding: 30px; border-radius: 10px; text-align: center;">
                        <ion-icon name="card-outline" style="font-size: 48px; opacity: 0.5;"></ion-icon>
                        <p>No virtual cards found.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($cards as $card): ?>
                        <div class="virtual-card">
                            <div class="card-brand">VISA</div>
                            <div class="card-chip"></div>
                            <div class="card-number"><?= htmlspecialchars($card['masked_pan']) ?></div>
                            <div class="card-meta">
                                <div>
                                    <span class="dummy-label">Card Holder</span>
                                    <span class="card-holder"><?= htmlspecialchars($_SESSION['user_name'] ?? 'CASJOE USER') ?></span>
                                </div>
                                <div class="card-expiry">
                                    <span class="dummy-label">Expires</span>
                                    <span><?= $card['start_month'] ?>/<?= $card['start_year'] ?></span>
                                </div>
                            </div>
                            <div style="position: absolute; bottom: 25px; right: 25px; font-weight: bold; font-size: 0.8rem; background: rgba(0,255,0,0.2); padding: 2px 8px; border-radius: 4px; color: #4cd137;">
                                <?= htmlspecialchars($card['status']) ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Create Card Form -->
            <div class="card" style="max-width: 500px;">
                <h3>Create New Card</h3>
                <form method="POST" action="/pay/cards/create">
                    <div class="form-group" style="margin-bottom: 15px;">
                        <label>Card Funding Amount ($ USD)</label>
                        <input type="number" name="amount" min="1" step="1" placeholder="e.g. 10" required class="form-control"
                            style="width: 100%; padding: 10px; border-radius: 5px; border: 1px solid #ccc; margin-top: 5px;">
                    </div>

                    <div class="form-group" style="margin-bottom: 15px;">
                        <label>Pay With</label>
                        <select name="currency" class="form-control" style="width: 100%; padding: 10px; border-radius: 5px; border: 1px solid #ccc; margin-top: 5px;">
                            <option value="NGN">NGN Wallet</option>
                            <option value="USD">USD Wallet</option>
                            <option value="CJC">CJC (Casjoe Token)</option>
                        </select>
                    </div>

                    <p style="font-size: 0.9rem; color: #666; margin-bottom: 20px;">
                        <strong>Note:</strong> A creation fee of ₦<?= number_format($creationFee, 2) ?> (approx $<?= number_format($creationFee / 1500, 2) ?>) applies.
                    </p>
                    <button type="submit" class="btn" style="width: 100%;">Create Card</button>
                </form>
            </div>

        </main>
    </div>
</body>

</html>