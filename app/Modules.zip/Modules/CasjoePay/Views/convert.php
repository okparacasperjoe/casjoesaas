<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Convert Currency | Casjoe Pay</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        .convert-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 30px;
            max-width: 500px;
            margin: 40px auto;
            color: #fff;
        }
        .form-group { margin-bottom: 20px; }
        .form-control {
            background: rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: #fff;
            padding: 12px;
            border-radius: 10px;
            width: 100%;
        }
        .btn-convert {
            background: var(--secondary);
            color: #000;
            font-weight: bold;
            width: 100%;
            padding: 15px;
            border-radius: 10px;
            border: none;
            cursor: pointer;
            transition: 0.3s;
        }
        .btn-convert:hover { background: #e69500; }
        .rate-display {
            text-align: center;
            margin-bottom: 20px;
            color: #aaa;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
<div class="app-container">
    <aside class="sidebar">
        <div class="brand">
             <img src="/assets/casjoe_logo.png" alt="Casjoe Apps" style="height: 40px;">
        </div>
        <ul class="nav-menu">
            <li class="nav-item"><a href="/dashboard" class="nav-link"><ion-icon name="speedometer-outline"></ion-icon> Dashboard</a></li>
            <li class="nav-item"><a href="/pay" class="nav-link"><ion-icon name="wallet-outline"></ion-icon> Casjoe Pay</a></li>
            <li class="nav-item"><a href="/pay/fund" class="nav-link"><ion-icon name="add-circle-outline"></ion-icon> Fund Wallet</a></li>
            <li class="nav-item"><a href="/pay/transfer" class="nav-link"><ion-icon name="paper-plane-outline"></ion-icon> Transfer</a></li>
            <li class="nav-item"><a href="/pay/cards" class="nav-link"><ion-icon name="card-outline"></ion-icon> Virtual Cards</a></li>
            <li class="nav-item"><a href="/pay/links" class="nav-link"><ion-icon name="link-outline"></ion-icon> Payment Links</a></li>
            <li class="nav-item"><a href="/pay/convert" class="nav-link active"><ion-icon name="swap-horizontal-outline"></ion-icon> Convert Currency</a></li>
            <li class="nav-item"><a href="/logout" class="nav-link"><ion-icon name="log-out-outline"></ion-icon> Logout</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <div class="top-bar">
            <h2><a href="/pay" style="text-decoration:none; color:white;"><ion-icon name="arrow-back-outline"></ion-icon></a> Convert Currency</h2>
        </div>

        <div class="convert-card">
            <h3 class="text-center mb-4">Swap Currencies</h3>
            
            <?php if(isset($_GET['error'])): ?>
                <div style="background: rgba(255,0,0,0.2); color: #ff6b6b; padding: 10px; border-radius: 8px; margin-bottom: 20px;">
                    <?= htmlspecialchars($_GET['error']) ?>
                </div>
            <?php endif; ?>

            <form action="/pay/convert/process" method="POST" id="convertForm">
                <input type="hidden" name="csrf_token" value="<?= \App\Core\Services\CsrfService::generateToken() ?>">
                
                <div class="form-group">
                    <label>From (Source Wallet)</label>
                    <select name="from_currency" class="form-control" id="from_currency" onchange="updateRate()">
                        <?php foreach($wallets as $w): ?>
                            <option value="<?= $w['currency'] ?>" data-balance="<?= $w['balance'] ?>">
                                <?= $w['currency'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div style="margin-top: 5px; font-size: 0.9rem; color: #FFA600;">
                        Available Balance: <strong id="avail-balance">---</strong>
                    </div>
                </div>

                <div class="form-group">
                    <label>To (Target Currency)</label>
                    <select name="to_currency" class="form-control" id="to_currency" onchange="updateRate()">
                         <option value="NGN">NGN (Nigerian Naira)</option>
                         <option value="USD">USD (US Dollar)</option>
                         <option value="GBP">GBP (British Pound)</option>
                         <option value="EUR">EUR (Euro)</option>
                         <option value="CJC">CJC (Casjoe Token)</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Amount to Convert</label>
                    <input type="number" name="amount" id="amount" class="form-control" placeholder="0.00" step="0.01" min="1" required oninput="calculateOutput()">
                </div>

                <div class="rate-display">
                    Exchange Rate: <span id="rate">Loading...</span><br>
                    You will receive approx: <strong id="output" style="color:white; font-size:1.2rem;">0.00</strong> <span id="target-curr"></span>
                </div>

                <button type="submit" class="btn-convert">Convert Now</button>
            </form>
        </div>
    </main>
</div>

<script>
    async function updateRate() {
        const fromSel = document.getElementById('from_currency');
        const from = fromSel.value;
        const to = document.getElementById('to_currency').value;
        const amount = document.getElementById('amount').value;
        
        // Update Balance Display
        const bal = parseFloat(fromSel.options[fromSel.selectedIndex].dataset.balance || 0);
        document.getElementById('avail-balance').innerText = bal.toLocaleString(undefined, {minimumFractionDigits: 2}) + ' ' + from;

        document.getElementById('target-curr').innerText = to;
        document.getElementById('rate').innerText = 'Fetching...';

        try {
            const formData = new FormData();
            formData.append('from', from);
            formData.append('to', to);
            
            // Call internal API or Controller endpoint to get rate
            // Since we don't have a dedicated API endpoint yet, we might need one.
            // For MVP, we can fetch via a GET param to the page or simple AJAX if path exists.
            // Let's create a simple rate lookup endpoint in controller or use hardcoded check for now in JS? 
            // Better: fetch from a lightweight controller action.
            
            const res = await fetch(`/pay/api/rate?from=${from}&to=${to}`);
            const data = await res.json();
            
            if(data.rate) {
                window.currentRate = data.rate;
                document.getElementById('rate').innerText = `1 ${from} = ${data.rate} ${to}`;
                calculateOutput();
            } else {
                document.getElementById('rate').innerText = 'Unavailable';
            }
        } catch (e) {
            console.error(e);
            document.getElementById('rate').innerText = 'Error';
        }
    }

    function calculateOutput() {
        if(!window.currentRate) return;
        const amount = parseFloat(document.getElementById('amount').value) || 0;
        const final = amount * window.currentRate;
        document.getElementById('output').innerText = final.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
    }

    // Initial load
    updateRate();
</script>
</body>
</html>
