<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Casjoe Pay | Dashboard</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        .wallet-card {
            background: linear-gradient(135deg, #000044 0%, #000066 100%);
            border-radius: 20px;
            padding: 30px;
            color: white;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 10px 30px rgba(0,0,102,0.3);
        }
        .balance-label { font-size: 0.9rem; opacity: 0.8; margin-bottom: 5px; }
        .balance-amount { font-size: 2.5rem; font-weight: 700; color: #FFA600; }
        .action-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        .action-card {
            background: rgba(255,255,255,0.05); /* Glass */
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.1);
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            text-decoration: none;
            color: var(--text-color);
            transition: transform 0.3s;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .action-card:hover { transform: translateY(-5px); background: rgba(255,255,255,0.1); }
        .action-icon { font-size: 2rem; margin-bottom: 10px; color: #FFA600; }
        .txn-table { width: 100%; border-collapse: collapse; }
        .txn-table td { padding: 15px; border-bottom: 1px solid rgba(255,255,255,0.05); }
        .txn-amount.credit { color: #2ed573; }
        .txn-amount.debit { color: #ff4757; }
    </style>
</head>
<body>
<?php require_once dirname(__DIR__, 3) . '/core/Views/partials/mobile_nav.php'; ?>
<div class="app-container">
    <aside class="sidebar">
        <div class="brand">
             <img src="/assets/casjoe_logo.png" alt="Casjoe Apps" style="height: 40px;">
        </div>
        <ul class="nav-menu">
            <li class="nav-item"><a href="/dashboard" class="nav-link"><ion-icon name="speedometer-outline"></ion-icon> Dashboard</a></li>
            <li class="nav-item"><a href="/pay" class="nav-link active"><ion-icon name="wallet-outline"></ion-icon> Casjoe Pay</a></li>
            <li class="nav-item"><a href="/pay/fund" class="nav-link"><ion-icon name="add-circle-outline"></ion-icon> Fund Wallet</a></li>
            <li class="nav-item"><a href="/pay/transfer" class="nav-link"><ion-icon name="paper-plane-outline"></ion-icon> Transfer</a></li>
            <li class="nav-item"><a href="/pay/cards" class="nav-link"><ion-icon name="card-outline"></ion-icon> Virtual Cards</a></li>
            <li class="nav-item"><a href="/pay/links" class="nav-link"><ion-icon name="link-outline"></ion-icon> Payment Links</a></li>
            <li class="nav-item"><a href="/pay/convert" class="nav-link"><ion-icon name="swap-horizontal-outline"></ion-icon> Convert Currency</a></li>
            <li class="nav-item"><a href="/logout" class="nav-link"><ion-icon name="log-out-outline"></ion-icon> Logout</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <div class="top-bar">
            <h2>Casjoe Pay</h2>
            <div class="btn" style="background: rgba(255,166,0,0.2); border: 1px solid #FFA600; color: #FFA600;">Wallet ID: <?= $_SESSION['user_id'] ?></div>
        </div>

        <!-- Currency Tabs -->
        <div class="modern-tabs">
            <?php foreach ($wallets as $w): ?>
                <button onclick="switchWallet('<?= $w['currency'] ?>', <?= $w['balance'] ?>)" 
                        class="modern-tab-btn" 
                        id="tab-<?= $w['currency'] ?>">
                    <?= $w['currency'] ?>
                </button>
            <?php endforeach; ?>
             <button type="button" onclick="alert('Multi-currency creation coming next update!')" class="modern-tab-btn" style="border-left: 1px solid #333; color: #888;">+ Add</button>
        </div>

        <div class="wallet-card" style="background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%); border: 1px solid #333;">
            <div>
                <div class="balance-label" style="color: #aaa;">Available Balance (<span id="active-currency"><?= $activeWallet['currency'] ?></span>)</div>
                <div class="balance-amount" style="color: #fff;">
                    <span id="currency-symbol" style="color: #FFA600;"><?= $activeWallet['currency'] == 'NGN' ? '₦' : ($activeWallet['currency'] == 'USD' ? '$' : $activeWallet['currency']) ?></span> 
                    <span id="wallet-balance"><?= number_format($activeWallet['balance'] ?? 0, 2) ?></span>
                </div>
            </div>
            <div>
                <a href="/pay/fund" class="fintech-btn" style="padding: 10px 25px; width: auto;">+ Fund Wallet</a>
            </div>
        </div>

        <script>
            function switchWallet(curr, bal) {
                // Update Balance
                document.getElementById('wallet-balance').innerText = new Intl.NumberFormat('en-US', {minimumFractionDigits: 2}).format(bal);
                document.getElementById('active-currency').innerText = curr;
                
                // Update Symbol
                let sym = curr;
                if(curr === 'NGN') sym = '₦';
                if(curr === 'USD') sym = '$';
                if(curr === 'GHS') sym = '₵';
                if(curr === 'GBP') sym = '£';
                document.getElementById('currency-symbol').innerText = sym;

                // Update Active Tab Style
                document.querySelectorAll('.modern-tab-btn').forEach(el => el.classList.remove('active'));
                
                const activeTab = document.getElementById('tab-' + curr);
                if(activeTab) activeTab.classList.add('active');
            }
            // Init
            window.onload = function() {
                switchWallet('<?= $activeWallet['currency'] ?>', <?= $activeWallet['balance'] ?>);
            };
        </script>

        <div class="action-grid">
            <a href="/pay/fund" class="fintech-card" style="align-items: center; justify-content: center; text-align: center; text-decoration: none; color: #fff; transition: transform 0.3s; padding: 25px;">
                <ion-icon name="add-circle-outline" style="font-size: 2.5rem; color: #FFA600; margin-bottom: 10px;"></ion-icon>
                <span style="font-weight: 600;">Fund Wallet</span>
            </a>
            <a href="/pay/transfer" class="fintech-card" style="align-items: center; justify-content: center; text-align: center; text-decoration: none; color: #fff; transition: transform 0.3s; padding: 25px;">
                <ion-icon name="paper-plane-outline" style="font-size: 2.5rem; color: #FFA600; margin-bottom: 10px;"></ion-icon>
                <span style="font-weight: 600;">Transfer</span>
            </a>
            <a href="/pay/links" class="fintech-card" style="align-items: center; justify-content: center; text-align: center; text-decoration: none; color: #fff; transition: transform 0.3s; padding: 25px;">
                <ion-icon name="link-outline" style="font-size: 2.5rem; color: #FFA600; margin-bottom: 10px;"></ion-icon>
                <span style="font-weight: 600;">Payment Links</span>
            </a>
            <a href="/pay/convert" class="fintech-card" style="align-items: center; justify-content: center; text-align: center; text-decoration: none; color: #fff; transition: transform 0.3s; padding: 25px;">
                <ion-icon name="swap-horizontal-outline" style="font-size: 2.5rem; color: #FFA600; margin-bottom: 10px;"></ion-icon>
                <span style="font-weight: 600;">Convert</span>
                <span style="font-weight: 600;">Convert</span>
            </a>
            <a href="/pay/cards" class="fintech-card" style="align-items: center; justify-content: center; text-align: center; text-decoration: none; color: #fff; transition: transform 0.3s; padding: 25px;">
                <ion-icon name="card-outline" style="font-size: 2.5rem; color: #FFA600; margin-bottom: 10px;"></ion-icon>
                <span style="font-weight: 600;">Virtual Cards</span>
            </a>
        </div>

        <div style="margin-bottom: 30px;">
            <h3 class="fintech-header" style="text-align: left; font-size: 1.2rem; margin-bottom: 15px;">My Cards</h3>
            
            <?php if (!empty($myCards)): ?>
                <div style="display: flex; gap: 15px; overflow-x: auto; padding-bottom: 5px;">
                    <?php foreach ($myCards as $card): ?>
                        <a href="/pay/cards" style="text-decoration: none;">
                        <div style="background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); border-radius: 12px; padding: 15px; width: 220px; color: white; box-shadow: 0 5px 15px rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1);">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                                <ion-icon name="wifi" style="transform: rotate(90deg); opacity: 0.7;"></ion-icon>
                                <span style="font-weight: bold; font-style: italic; opacity: 0.6;">VISA</span>
                            </div>
                            <div style="font-family: monospace; letter-spacing: 2px; font-size: 1.1rem; margin-bottom: 10px;">
                                <?= $card['masked_pan'] ?>
                            </div>
                            <div style="font-size: 0.8rem; opacity: 0.7;">
                                EXP <?= $card['start_month'] ?>/<?= $card['start_year'] ?>
                            </div>
                        </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <!-- Placeholder Card for Users without Cards -->
                <a href="/pay/cards" style="text-decoration: none;">
                    <div style="background: linear-gradient(135deg, #333 0%, #444 100%); border-radius: 12px; padding: 15px; width: 220px; color: white; box-shadow: 0 5px 15px rgba(0,0,0,0.3); border: 1px dashed rgba(255,255,255,0.3); opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=0.8">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <ion-icon name="wifi" style="transform: rotate(90deg); opacity: 0.3;"></ion-icon>
                            <span style="font-weight: bold; font-style: italic; opacity: 0.3;">VISA</span>
                        </div>
                        <div style="font-family: monospace; letter-spacing: 2px; font-size: 1.1rem; margin-bottom: 10px; opacity: 0.5;">
                            **** **** **** ****
                        </div>
                        <div style="font-size: 0.8rem; opacity: 0.7; color: #FFA600; text-transform: uppercase; font-weight: bold;">
                            <ion-icon name="add-circle"></ion-icon> Activate Card
                        </div>
                    </div>
                </a>
            <?php endif; ?>
        </div>

        <div class="fintech-card">
            <h3 class="fintech-header" style="text-align: left; font-size: 1.2rem; margin-bottom: 20px;">Recent Transactions</h3>
            <?php if (empty($transactions)): ?>
                <p style="color: #666; text-align: center; padding: 20px;">No transactions yet.</p>
            <?php else: ?>
                <table class="txn-table">
                    <?php foreach ($transactions as $txn): ?>
                        <tr>
                            <td>
                                <div style="font-weight: bold; color: #eee;"><?= htmlspecialchars($txn['description'] ?? 'Transaction') ?></div>
                                <div style="font-size: 0.8rem; color: #888;"><?= $txn['created_at'] ?></div>
                            </td>
                            <td style="text-align: right;">
                                <div class="txn-amount <?= $txn['type'] ?>" style="font-weight: 600;">
                                    <?= $txn['type'] == 'credit' ? '+' : '-' ?> <?= $txn['currency'] ?? 'NGN' ?> <?= number_format($txn['amount'], 2) ?>
                                </div>
                                <div style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: #aaa;">
                                    <?= $txn['status'] ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php endif; ?>
        </div>
    </main>
</div>
</body>
</html>