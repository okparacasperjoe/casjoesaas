<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Fund Wallet | Casjoe Pay</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        .form-container { max-width: 500px; margin: 60px auto; }
        .method-label {
            display: flex; 
            align-items: center; 
            padding: 15px; 
            border: 1px solid #333; 
            border-radius: 12px; 
            cursor: pointer;
            background: #111;
            transition: all 0.3s;
            color: #ccc;
        }
        .method-label:hover { border-color: #666; background: #1a1a1a; }
        .method-label input:checked + span { color: #fff; font-weight: bold; }
        .method-label:has(input:checked) { border-color: #FFA600; background: rgba(255, 166, 0, 0.05); }
    </style>
</head>
<body>
<div class="app-container">
    <aside class="sidebar">
        <div class="brand">
             <img src="/assets/casjoe_logo.png" alt="Casjoe Apps" style="height: 40px;">
        </div>
        <ul class="nav-menu">
            <li class="nav-item"><a href="/dashboard" class="nav-link"><ion-icon name="speedometer-outline"></ion-icon> Dashboard</a></li>
            <li class="nav-item"><a href="/pay" class="nav-link"><ion-icon name="wallet-outline"></ion-icon> Casjoe Pay</a></li>
            <li class="nav-item"><a href="/pay/fund" class="nav-link active"><ion-icon name="add-circle-outline"></ion-icon> Fund Wallet</a></li>
            <li class="nav-item"><a href="/pay/transfer" class="nav-link"><ion-icon name="paper-plane-outline"></ion-icon> Transfer</a></li>
            <li class="nav-item"><a href="/pay/cards" class="nav-link"><ion-icon name="card-outline"></ion-icon> Virtual Cards</a></li>
            <li class="nav-item"><a href="/pay/links" class="nav-link"><ion-icon name="link-outline"></ion-icon> Payment Links</a></li>
            <li class="nav-item"><a href="/pay/convert" class="nav-link"><ion-icon name="swap-horizontal-outline"></ion-icon> Convert Currency</a></li>
            <li class="nav-item"><a href="/logout" class="nav-link"><ion-icon name="log-out-outline"></ion-icon> Logout</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <div class="form-container">
            <div class="fintech-card">
                <h2 class="fintech-header">Fund Wallet</h2>
                <form method="POST" action="/pay/fund">
                    <div style="margin-bottom: 25px; display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div>
                            <label class="fintech-label">Currency</label>
                            <select name="currency" class="fintech-select">
                                <option value="NGN">NGN (Naira)</option>
                                <option value="USD">USD (Dollar)</option>
                                <option value="GHS">GHS (Cedis)</option>
                                <option value="KES">KES (Shilling)</option>
                                <option value="ZAR">ZAR (Rand)</option>
                            </select>
                        </div>
                        <div>
                            <label class="fintech-label">Amount</label>
                            <input type="number" name="amount" placeholder="0.00" class="fintech-input" min="10" required step="0.01">
                        </div>
                    </div>

                    <div style="margin-bottom: 30px;">
                        <label class="fintech-label">Payment Method</label>
                        <div style="display: flex; flex-direction: column; gap: 12px;">
                            <label class="method-label">
                                <input type="radio" name="method" value="card" checked style="margin-right: 15px;">
                                <span><ion-icon name="card-outline" style="vertical-align: middle; margin-right: 5px; color: #FFA600;"></ion-icon> Card (Visa/Mastercard)</span>
                            </label>

                            <label class="method-label">
                                <input type="radio" name="method" value="momo" style="margin-right: 15px;">
                                <span><ion-icon name="phone-portrait-outline" style="vertical-align: middle; margin-right: 5px; color: #FFA600;"></ion-icon> Mobile Money</span>
                            </label>

                            <label class="method-label">
                                <input type="radio" name="method" value="bank_transfer" style="margin-right: 15px;">
                                <span><ion-icon name="business-outline" style="vertical-align: middle; margin-right: 5px; color: #FFA600;"></ion-icon> Bank Transfer</span>
                            </label>
                        </div>
                    </div>
                    
                    <button type="submit" class="fintech-btn">Fund With Flutterwave</button>
                    <p style="text-align: center; font-size: 0.8rem; color: #555; margin-top: 15px;"><ion-icon name="lock-closed-outline"></ion-icon> Secured by Flutterwave</p>
                </form>
            </div>
        </div>
    </main>
</div>
</body>
</html>
