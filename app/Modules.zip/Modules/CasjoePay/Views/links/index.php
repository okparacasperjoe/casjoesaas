<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Links | Casjoe Pay</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<div class="app-container">
    <aside class="sidebar">
        <div class="brand">
             <img src="/assets/casjoe_logo.png" alt="Casjoe Apps" style="height: 40px;">
        </div>
        <ul class="nav-menu">
            <li class="nav-item"><a href="/dashboard" class="nav-link"><ion-icon name="speedometer-outline"></ion-icon> Dashboard</a></li>
            <li class="nav-item"><a href="/pay" class="nav-link"><ion-icon name="wallet-outline"></ion-icon> Casjoe Pay</a></li>
            <li class="nav-item"><a href="/pay/fund" class="nav-link"><ion-icon name="add-circle-outline"></ion-icon> Fund Wallet</a></li>
            <li class="nav-item"><a href="/pay/transfer" class="nav-link"><ion-icon name="paper-plane-outline"></ion-icon> Transfer</a></li>
            <li class="nav-item"><a href="/pay/cards" class="nav-link"><ion-icon name="card-outline"></ion-icon> Virtual Cards</a></li>
            <li class="nav-item"><a href="/pay/links" class="nav-link active"><ion-icon name="link-outline"></ion-icon> Payment Links</a></li>
            <li class="nav-item"><a href="/pay/convert" class="nav-link"><ion-icon name="swap-horizontal-outline"></ion-icon> Convert Currency</a></li>
            <li class="nav-item"><a href="/logout" class="nav-link"><ion-icon name="log-out-outline"></ion-icon> Logout</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <div class="top-bar">
            <h2>Payment Links</h2>
        </div>

        <div class="row">
            <!-- Create Form -->
            <div class="col-md-5 mb-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-header bg-white py-3">
                        <h5 class="fw-bold mb-0">Create Payment Link</h5>
                    </div>
                    <div class="card-body">
                        <form action="/pay/links/create" method="POST">
                            <div class="mb-3">
                                <label class="form-label fw-bold small text-uppercase">Title</label>
                                <input type="text" name="title" class="form-control" placeholder="e.g. Consultation Fee" required>
                            </div>
                            
                            <div class="row g-2 mb-3">
                                <div class="col-6">
                                    <label class="form-label fw-bold small text-uppercase">Currency</label>
                                    <select name="currency" class="form-select">
                                        <option value="NGN">NGN (Naira)</option>
                                        <option value="USD">USD (Dollar)</option>
                                        <option value="GHS">GHS (Cedis)</option>
                                        <option value="KES">KES (Shilling)</option>
                                        <option value="ZAR">ZAR (Rand)</option>
                                    </select>
                                </div>
                                <div class="col-6">
                                    <label class="form-label fw-bold small text-uppercase">Amount</label>
                                    <input type="number" name="amount" class="form-control" step="0.01" placeholder="Optional">
                                </div>
                            </div>
                            <div class="form-text text-muted mb-3 small">Leave amount empty to allow customers to enter any amount.</div>

                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-plus-lg"></i> Create Link
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Link List -->
            <div class="col-md-7">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                        <h5 class="fw-bold mb-0">Your Active Links</h5>
                        <span class="badge bg-light text-dark"><?= count($links) ?> Links</span>
                    </div>
                    <div class="list-group list-group-flush">
                        <?php if (empty($links)): ?>
                            <div class="text-center py-5 text-muted">
                                <i class="bi bi-link-45deg fs-1"></i>
                                <p>No payment links created yet.</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($links as $link): ?>
                            <div class="list-group-item py-3">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <div>
                                        <h6 class="fw-bold mb-1"><?= htmlspecialchars($link['title']) ?></h6>
                                        <div class="text-muted small">
                                            <?= $link['amount'] > 0 ? $link['currency'] . ' ' . number_format($link['amount']) : 'Open Amount (' . $link['currency'] . ')' ?>
                                            &bull; <span class="text-primary"><i class="bi bi-eye"></i> <?= $link['views'] ?> Views</span>
                                        </div>
                                    </div>
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-link text-dark" data-bs-toggle="dropdown"><i class="bi bi-three-dots-vertical"></i></button>
                                        <ul class="dropdown-menu dropdown-menu-end">
                                            <li><a class="dropdown-item" href="/pay/link/<?= $link['slug'] ?>" target="_blank"><i class="bi bi-box-arrow-up-right"></i> View Page</a></li>
                                            <li><button class="dropdown-item" onclick="copyLink('<?= $link['slug'] ?>')"><i class="bi bi-clipboard"></i> Copy URL</button></li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li><a class="dropdown-item text-danger" href="#"><i class="bi bi-trash"></i> Delete</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="input-group input-group-sm">
                                    <input type="text" class="form-control" value="<?= $_SERVER['HTTP_HOST'] ?>/pay/link/<?= $link['slug'] ?>" readonly>
                                    <button class="btn btn-outline-secondary" type="button" onclick="copyLink('<?= $link['slug'] ?>')">Copy</button>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function copyLink(slug) {
        const url = window.location.origin + '/pay/link/' + slug;
        navigator.clipboard.writeText(url).then(() => {
            alert('Link copied to clipboard!');
        });
    }
</script>
</body>
</html>
