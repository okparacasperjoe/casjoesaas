<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($link['title']) ?> | Secure Payment</title>
    <link rel="stylesheet" href="/css/style.css">
    <style>
        :root {
            --primary: #000066;
            --secondary: #FFA600;
            --bg-light: #F8FAFC;
        }
        body {
            background-color: var(--primary);
            background-image: linear-gradient(135deg, #00004D 0%, #000066 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            font-family: 'Inter', sans-serif;
            color: #333;
        }
        .checkout-container {
            background: white;
            padding: 40px;
            border-radius: 24px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 480px;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .checkout-header { margin-bottom: 30px; }
        .amount-display {
            font-size: 2.5rem; font-weight: 800; color: var(--primary); margin: 10px 0;
        }
        .pay-btn {
            background: var(--secondary);
            color: var(--primary);
            width: 100%; padding: 16px; border-radius: 12px; border: none;
            font-size: 1.1rem; font-weight: 700; cursor: pointer;
            transition: all 0.2s ease; margin-top: 20px;
            box-shadow: 0 4px 15px rgba(255, 166, 0, 0.3);
        }
        .pay-btn:hover {
            transform: translateY(-2px); box-shadow: 0 8px 25px rgba(255, 166, 0, 0.4);
            background: #ffb733;
        }
        .input-group { text-align: left; margin-bottom: 20px; }
        .input-group label {
            display: block; margin-bottom: 8px; color: #4b5563; font-size: 0.9rem; font-weight: 600;
        }
        .input-group input {
            width: 100%; padding: 14px; border: 2px solid #e5e7eb; border-radius: 12px;
            font-size: 1rem; box-sizing: border-box; transition: border-color 0.2s;
        }
        .input-group input:focus { border-color: var(--primary); outline: none; }
        .powered-by { margin-top: 30px; font-size: 0.85rem; color: #9ca3af; }
    </style>
</head>
<body>

<div class="checkout-container">
    <div class="checkout-header">
        <div style="width: 60px; height: 60px; background: #eee; border-radius: 50%; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; font-weight: bold; color: var(--primary);">
            <?= strtoupper(substr($link['title'], 0, 1)) ?>
        </div>
        <h2 style="margin: 0; color: #333;"><?= htmlspecialchars($link['title']) ?></h2>
        <p style="color: #666; font-size: 0.9rem;">Pay securely via Casjoe Pay</p>
    </div>

    <?php if ($link['amount'] > 0): ?>
        <div class="amount-display"><?= $link['currency'] ?> <?= number_format($link['amount'], 2) ?></div>
        <input type="hidden" name="amount" value="<?= $link['amount'] ?>">
    <?php else: ?>
        <div class="input-group">
            <label>Amount (<?= $link['currency'] ?>)</label>
            <input type="number" name="amount" placeholder="Enter amount" required min="1" step="0.01">
        </div>
    <?php endif; ?>

    <form method="POST" action="/pay/process/<?= $link['slug'] ?>"> <!-- Placeholder action -->
        <div class="input-group">
            <label>Full Name</label>
            <input type="text" name="name" placeholder="John Doe" required>
        </div>
        <div class="input-group">
            <label>Email Address</label>
            <input type="email" name="email" placeholder="john@example.com" required>
        </div>

        <button type="submit" class="pay-btn">Pay Now</button>
    </form>

    <div class="powered-by">
        Powered by <strong style="color: var(--primary);">Casjoe Pay</strong>
    </div>
</div>

</body>
</html>
