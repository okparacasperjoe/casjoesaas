<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Transfer | Casjoe Pay</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        .form-container { max-width: 480px; margin: 60px auto; }
        .tab-center { display: flex; justify-content: center; }
    </style>
</head>
<body>
<div class="app-container">
    <aside class="sidebar">
        <div class="brand">
             <img src="/assets/casjoe_logo.png" alt="Casjoe Apps" style="height: 40px;">
        </div>
        <ul class="nav-menu">
            <li class="nav-item"><a href="/pay" class="nav-link"><ion-icon name="arrow-back-outline"></ion-icon> Back to Wallet</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <div class="form-container">
            <div class="fintech-card">
                <h2 class="fintech-header">Transfer Money</h2>
                
                <div class="tab-center">
                    <div class="modern-tabs">
                        <button type="button" class="modern-tab-btn active" onclick="switchTab('internal')" id="tab-btn-internal">Internal</button>
                        <button type="button" class="modern-tab-btn" onclick="switchTab('bank')" id="tab-btn-bank">Bank</button>
                        <button type="button" class="modern-tab-btn" onclick="switchTab('momo')" id="tab-btn-momo">Mobile Money</button>
                    </div>
                </div>

                <form method="POST" action="/pay/transfer">
                    <input type="hidden" name="type" id="transfer_type" value="internal">

                    <!-- Internal Transfer -->
                    <div id="form-internal" class="transfer-section">
                        <div class="fintech-input-group">
                            <label class="fintech-label">Recipient Email (Casjoe User)</label>
                            <input type="email" name="email" placeholder="user@casjoe.com" class="fintech-input">
                        </div>
                    </div>

                    <!-- Bank Transfer -->
                    <div id="form-bank" class="transfer-section" style="display: none;">
                        <div class="fintech-input-group">
                            <label class="fintech-label">Bank Name</label>
                            <select name="bank_code" class="fintech-select">
                                <option value="044">Access Bank</option>
                                <option value="058">GTBank</option>
                                <option value="033">United Bank for Africa (UBA)</option>
                                <option value="057">Zenith Bank</option>
                                <option value="011">First Bank</option>
                                <option value="214">FCMB</option>
                                <option value="000">Other (Select in Production)</option>
                            </select>
                        </div>
                        <div class="fintech-input-group">
                            <label class="fintech-label">Account Number</label>
                            <input type="text" name="account_number" placeholder="1234567890" class="fintech-input" maxlength="10">
                        </div>
                    </div>

                    <!-- Mobile Money -->
                    <div id="form-momo" class="transfer-section" style="display: none;">
                         <div class="fintech-input-group">
                            <label class="fintech-label">Provider</label>
                            <select name="momo_provider" class="fintech-select">
                                <option value="mtn">MTN MoMo</option>
                                <option value="airtel">Airtel Money</option>
                                <option value="mpesa">M-Pesa</option>
                            </select>
                        </div>
                        <div class="fintech-input-group">
                            <label class="fintech-label">Phone Number</label>
                            <input type="tel" name="phone_number" placeholder="+234..." class="fintech-input">
                        </div>
                    </div>

                    <div class="fintech-input-group">
                        <label class="fintech-label">Amount</label>
                        <div class="input-with-addon">
                            <select name="currency" class="currency-select">
                                <option value="NGN">NGN</option>
                                <option value="USD">USD</option>
                            </select>
                            <input type="number" name="amount" placeholder="0.00" class="amount-input" min="10" required step="0.01">
                        </div>
                    </div>
                    
                    <button type="submit" class="fintech-btn">Proceed with Transfer</button>
                    <p style="text-align: center; color: #555; margin-top: 15px; font-size: 0.8rem;">Secure 256-bit Encryption</p>
                </form>

                <script>
                    function switchTab(type) {
                        // Update hidden input
                        document.getElementById('transfer_type').value = type;

                        // Toggle Forms
                        document.querySelectorAll('.transfer-section').forEach(el => el.style.display = 'none');
                        document.getElementById('form-' + type).style.display = 'block';

                        // Toggle Tabs
                        document.querySelectorAll('.modern-tab-btn').forEach(el => el.classList.remove('active'));
                        document.getElementById('tab-btn-' + type).classList.add('active');
                    }
                </script>
            </div>
        </div>
    </main>
</div>
</body>
</html>