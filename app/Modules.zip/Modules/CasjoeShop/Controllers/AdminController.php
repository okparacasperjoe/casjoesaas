<?php

namespace App\Modules\CasjoeShop\Controllers;

use App\Core\Database;
use App\Core\TenantContext;

class AdminController
{
    private $db;
    private $tenantId;

    public function __construct()
    {
        // Simple Admin Auth Check (role check or exact email check should be here)
        if (!isset($_SESSION['user_id'])) {
            header('Location: /login');
            exit;
        }

        $this->db = Database::getInstance();
        $this->tenantId = TenantContext::getTenantId();
    }

    public function dashboard()
    {
        // KPI: Total Vendors
        $stmt = $this->db->query("SELECT COUNT(*) FROM shop_vendors WHERE tenant_id = ?", [$this->tenantId]);
        $totalVendors = $stmt->fetchColumn();

        // KPI: Total Products
        $stmt = $this->db->query("SELECT COUNT(*) FROM shop_products WHERE status = 'active'");
        $totalProducts = $stmt->fetchColumn();

        // KPI: Total Orders
        $stmt = $this->db->query("SELECT COUNT(*) FROM shop_orders WHERE tenant_id = ?", [$this->tenantId]);
        $totalOrders = $stmt->fetchColumn();

        // KPI: Revenue
        $stmt = $this->db->query("SELECT SUM(total_amount) FROM shop_orders WHERE tenant_id = ? AND status='paid'", [$this->tenantId]);
        $revenue = $stmt->fetchColumn() ?: 0;

        // Pending Vendors
        $stmt = $this->db->query("SELECT * FROM shop_vendors WHERE tenant_id = ? AND status = 'pending' ORDER BY created_at DESC LIMIT 5", [$this->tenantId]);
        $pendingVendors = $stmt->fetchAll();

        require_once __DIR__ . '/../Views/admin/dashboard.php';
    }

    public function vendors()
    {
        $stmt = $this->db->query("SELECT * FROM shop_vendors WHERE tenant_id = ? ORDER BY created_at DESC", [$this->tenantId]);
        $vendors = $stmt->fetchAll();

        require_once __DIR__ . '/../Views/admin/vendors.php';
    }

    public function approveVendor($params)
    {
        $id = is_array($params) ? $params['id'] : $params;
        
        $this->db->query("UPDATE shop_vendors SET status = 'approved' WHERE id = ? AND tenant_id = ?", [$id, $this->tenantId]);
        
        header('Location: /admin/shop/vendors');
        exit;
    }

    public function ads()
    {
        $stmt = $this->db->query("SELECT * FROM shop_ads_settings WHERE tenant_id = ?", [$this->tenantId]);
        $ads = $stmt->fetchAll();
        
        // Re-key by location for easier access in view
        $adsByLocation = [];
        foreach ($ads as $ad) {
            $adsByLocation[$ad['banner_location']] = $ad;
        }

        require_once __DIR__ . '/../Views/admin/ads.php';
    }

    public function updateAds()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $locations = ['top', 'middle'];

            foreach ($locations as $loc) {
                if (isset($_POST[$loc])) {
                    $data = $_POST[$loc];
                    $isActive = isset($data['is_active']) ? 1 : 0;
                    
                    // Check if exists
                    $stmt = $this->db->query("SELECT id FROM shop_ads_settings WHERE tenant_id = ? AND banner_location = ?", [$this->tenantId, $loc]);
                    $exists = $stmt->fetchColumn();

                    if ($exists) {
                        $sql = "UPDATE shop_ads_settings SET 
                                title = ?, description = ?, button_text = ?, button_link = ?, image_url = ?, is_active = ?
                                WHERE tenant_id = ? AND banner_location = ?";
                        $this->db->query($sql, [
                            $data['title'], $data['description'], $data['button_text'], $data['button_link'], $data['image_url'], $isActive,
                            $this->tenantId, $loc
                        ]);
                    } else {
                        $sql = "INSERT INTO shop_ads_settings (tenant_id, banner_location, title, description, button_text, button_link, image_url, is_active)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                        $this->db->query($sql, [
                            $this->tenantId, $loc, $data['title'], $data['description'], $data['button_text'], $data['button_link'], $data['image_url'], $isActive
                        ]);
                    }
                }
            }
            
            header('Location: /admin/shop/ads?success=1');
            exit;
        }
    }
}
