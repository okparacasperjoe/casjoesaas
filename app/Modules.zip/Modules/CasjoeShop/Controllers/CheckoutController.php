<?php

namespace App\Modules\CasjoeShop\Controllers;

use App\Core\Database;
use App\Core\TenantContext;

class CheckoutController
{
    private $db;
    private $tenantId;

    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $this->db = Database::getInstance();
        $this->tenantId = TenantContext::getTenantId();
    }

    public function index()
    {
        // Require Login used for MVP checkout to track orders easily
        if (!isset($_SESSION['user_id'])) {
            // Store return url
            $_SESSION['return_to'] = '/shop/checkout';
            header('Location: /login?msg=Please login to checkout');
            exit;
        }

        // Re-calculate total
        $subtotal = 0;
        $serviceFee = 0;
        $shippingZones = [];
        $hasPhysicalItems = false;
        
        if (!empty($_SESSION['cart'])) {
            $ids = implode(',', array_keys($_SESSION['cart']));
            $inQuery = implode(',', array_fill(0, count($_SESSION['cart']), '?'));
            
            // Join shop_vendors to get fee_bearer
            $stmt = $this->db->prepare("SELECT p.price, p.id, p.vendor_id, p.type, v.fee_bearer 
                                      FROM shop_products p 
                                      JOIN shop_vendors v ON p.vendor_id = v.id 
                                      WHERE p.id IN ($inQuery)");
            $stmt->execute(array_keys($_SESSION['cart']));
            $products = $stmt->fetchAll();
            
            $vendorIds = [];

            foreach ($products as $p) {
                $qty = $_SESSION['cart'][$p['id']];
                $lineTotal = $p['price'] * $qty;
                $subtotal += $lineTotal;
                
                if ($p['fee_bearer'] === 'customer') {
                    $serviceFee += $lineTotal * 0.05; // 5% Service Fee
                }

                if ($p['type'] !== 'digital') {
                    $hasPhysicalItems = true;
                    if (!in_array($p['vendor_id'], $vendorIds)) {
                        $vendorIds[] = $p['vendor_id'];
                    }
                }
            }

            // Fetch Shipping Zones for relevant vendors (Merge them for now, assuming single vendor checkout or max cost)
            // MVP Simplification: If multi-vendor, we just list all unique zones and user picks one "Region".
            // In reality, each vendor needs shipping. For this MVP, we'll assume the user picks a delivery location 
            // and we match that name across vendors, or just show a consolidated list?
            // Let's do: Fetch ALL zones for these vendors.
            if ($hasPhysicalItems && !empty($vendorIds)) {
                $vIds = implode(',', $vendorIds);
                $stmt = $this->db->query("SELECT * FROM shop_shipping_zones WHERE vendor_id IN ($vIds)");
                $shippingZones = $stmt->fetchAll();
            }
        }
        
        // Apply Coupon (If exists in session)
        $discountAmount = 0;
        $couponError = null;
        if (!empty($_SESSION['coupon'])) {
            $c = $_SESSION['coupon'];
            if ($subtotal >= $c['min_spend']) {
                if ($c['type'] == 'percent') {
                    $discountAmount = $subtotal * ($c['value'] / 100);
                } else {
                    $discountAmount = $c['value'];
                }
                if ($discountAmount > $subtotal) $discountAmount = $subtotal;
            } else {
                $couponError = "Minimum spend of $" . number_format($c['min_spend'], 2) . " required.";
                unset($_SESSION['coupon']);
            }
        }
        
        $total = $subtotal + $serviceFee - $discountAmount;
        if ($total < 0) $total = 0;
        
        if ($subtotal == 0 && empty($_SESSION['cart'])) { header('Location: /shop/cart'); exit; }

        require_once __DIR__ . '/../Views/checkout/index.php';
    }

    public function process()
    {
        if (!isset($_SESSION['user_id'])) { header('Location: /login'); exit; }
        
        $userId = $_SESSION['user_id'];
        
        // RE-CALCULATE SERVER SIDE (Security Best Practice)
        $subtotal = 0;
        $serviceFee = 0;
        $shippingCost = 0;
        $shippingZoneName = null;
        
        if (!empty($_SESSION['cart'])) {
             $ids = implode(',', array_keys($_SESSION['cart']));
             $inQuery = implode(',', array_fill(0, count($_SESSION['cart']), '?'));
             
             // Join shop_vendors to get fee_bearer
             $stmt = $this->db->prepare("SELECT p.price, p.id, p.vendor_id, p.type, v.fee_bearer 
                                       FROM shop_products p 
                                       JOIN shop_vendors v ON p.vendor_id = v.id 
                                       WHERE p.id IN ($inQuery)");
             $stmt->execute(array_keys($_SESSION['cart']));
             $products = $stmt->fetchAll();
             
             foreach ($products as $p) {
                 $qty = $_SESSION['cart'][$p['id']];
                 $lineTotal = $p['price'] * $qty;
                 $subtotal += $lineTotal;
                 
                 if ($p['fee_bearer'] === 'customer') {
                     $serviceFee += $lineTotal * 0.05; // 5% Service Fee
                 }
             }

             // Handle Shipping
             if (isset($_POST['shipping_zone_id'])) {
                 $zoneId = $_POST['shipping_zone_id'];
                 $stmt = $this->db->prepare("SELECT * FROM shop_shipping_zones WHERE id = ?");
                 $stmt->execute([$zoneId]);
                 $zone = $stmt->fetch();
                 if ($zone) {
                     $shippingCost = $zone['cost'];
                     $shippingZoneName = $zone['zone_name'];
                 }
             }

             // Handle Coupon
             if (!empty($_SESSION['coupon'])) {
                 $code = $_SESSION['coupon']['code'];
                 // Re-verify Validity (race condition check)
                 $stmt = $this->db->prepare("SELECT * FROM shop_coupons WHERE code = ? AND tenant_id = ?");
                 $stmt->execute([$code, $this->tenantId]);
                 $coupon = $stmt->fetch();

                 if ($coupon && (!$coupon['expires_at'] || strtotime($coupon['expires_at']) >= time()) && ($coupon['usage_limit'] == 0 || $coupon['used_count'] < $coupon['usage_limit']) && ($subtotal >= $coupon['min_spend'])) {
                     
                     // Calculate Discount
                     if ($coupon['type'] == 'percent') {
                         $discountAmount = $subtotal * ($coupon['value'] / 100);
                     } else {
                         $discountAmount = $coupon['value'];
                     }
                     // Ensure discount doesn't exceed subtotal
                     if ($discountAmount > $subtotal) $discountAmount = $subtotal;
                     
                     $couponCode = $code;
                     $couponId = $coupon['id'];
                 } else {
                     // Invalid, clear it
                     unset($_SESSION['coupon']);
                 }
             }
        }
        
        $total = $subtotal + $serviceFee + $shippingCost - $discountAmount;
        if ($total < 0) $total = 0;

        // 1. Create Order
        $this->db->query("INSERT INTO shop_orders (tenant_id, user_id, total_amount, service_fee, shipping_cost, shipping_zone_name, discount_amount, coupon_code, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')", 
            [$this->tenantId, $userId, $total, $serviceFee, $shippingCost, $shippingZoneName, $discountAmount, $couponCode]);
        $orderId = $this->db->lastInsertId();

        // Increment Coupon Usage
        if ($couponId) {
            $this->db->query("UPDATE shop_coupons SET used_count = used_count + 1 WHERE id = ?", [$couponId]);
        }

        // 2. Create Order Items & Generate Digital Access
        foreach ($_SESSION['cart'] as $prodId => $qty) {
            $stmt = $this->db->query("SELECT * FROM shop_products WHERE id = ?", [$prodId]);
            $product = $stmt->fetch();
            
            // Insert Item
            $this->db->query("INSERT INTO shop_order_items (order_id, vendor_id, product_id, quantity, price) VALUES (?, ?, ?, ?, ?)",
                [$orderId, $product['vendor_id'], $prodId, $qty, $product['price']]);
            $itemId = $this->db->lastInsertId();

            // Link Digital Access if needed
            if ($product['type'] == 'digital') {
                $token = bin2hex(random_bytes(32));
                $this->db->query("INSERT INTO shop_digital_access (order_item_id, token, max_downloads) VALUES (?, ?, 5)", [$itemId, $token]);
            }
        }

        // 3. Process Payment (Mock Casjoe Pay)
        // In real life, redirect to /pay/checkout and use callback.
        // For MVP, we auto-mark as paid if 'casjoe_pay' is selected.
        
        $this->db->query("UPDATE shop_orders SET status = 'paid', payment_ref = 'MOCK-PAY-".uniqid()."' WHERE id = ?", [$orderId]);

        // 4. Clear Cart & Coupon
        unset($_SESSION['cart']);
        unset($_SESSION['coupon']);

        // 5. Success Page (with download links)
        require_once __DIR__ . '/../Views/checkout/success.php';
    }

    public function applyCoupon()
    {
        $code = strtoupper(trim($_POST['code'] ?? ''));
        if (empty($code)) { header('Location: /shop/checkout'); exit; }

        $stmt = $this->db->prepare("SELECT * FROM shop_coupons WHERE code = ? AND tenant_id = ?");
        $stmt->execute([$code, $this->tenantId]);
        $coupon = $stmt->fetch();

        if (!$coupon) {
            $_SESSION['coupon_error'] = "Invalid coupon code.";
        } elseif ($coupon['expires_at'] && strtotime($coupon['expires_at']) < time()) {
            $_SESSION['coupon_error'] = "Coupon has expired.";
        } elseif ($coupon['usage_limit'] > 0 && $coupon['used_count'] >= $coupon['usage_limit']) {
            $_SESSION['coupon_error'] = "Coupon usage limit reached.";
        } else {
            $_SESSION['coupon'] = [
                'code' => $coupon['code'],
                'type' => $coupon['type'],
                'value' => $coupon['value'],
                'min_spend' => $coupon['min_spend']
            ];
            $_SESSION['coupon_success'] = "Coupon applied!";
        }

        header('Location: /shop/checkout');
        exit;
    }

    public function removeCoupon()
    {
        unset($_SESSION['coupon']);
        header('Location: /shop/checkout');
        exit;
    }
}
