<?php

namespace App\Modules\CasjoeShop\Controllers;

use App\Core\Database;
use App\Core\TenantContext;

class ShopController
{
    private $db;
    private $tenantId;

    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $this->db = Database::getInstance();
        $this->tenantId = TenantContext::getTenantId();
    }

    public function index()
    {
        $params = $_GET;
        $sql = "SELECT * FROM shop_products WHERE status = 'active'";
        $bindings = [];

        if (!empty($params['q'])) {
            $sql .= " AND (name LIKE ? OR description LIKE ?)";
            $bindings[] = '%' . $params['q'] . '%';
            $bindings[] = '%' . $params['q'] . '%';
        }

        if (!empty($params['category'])) {
            $sql .= " AND category = ?";
            $bindings[] = $params['category'];
        }

        if (!empty($params['min_price'])) {
            $sql .= " AND price >= ?";
            $bindings[] = $params['min_price'];
        }

        if (!empty($params['max_price'])) {
            $sql .= " AND price <= ?";
            $bindings[] = $params['max_price'];
        }

        $sql .= " ORDER BY created_at DESC";

        $stmt = $this->db->query($sql, $bindings);
        $products = $stmt->fetchAll();

        // Fetch categories for sidebar
        $catStmt = $this->db->query("SELECT DISTINCT category FROM shop_products WHERE status='active' AND category IS NOT NULL AND category != '' ORDER BY category ASC");
        $categories = $catStmt->fetchAll(\PDO::FETCH_COLUMN);

        // Fetch Advertisement Banners
        $adStmt = $this->db->query("SELECT * FROM shop_ads_settings WHERE tenant_id = ? AND is_active = 1", [$this->tenantId]);
        $ads = $adStmt->fetchAll();
        $adsByLocation = [];
        foreach ($ads as $ad) {
            $adsByLocation[$ad['banner_location']] = $ad;
        }

        require_once __DIR__ . '/../Views/store/index.php';
    }

    public function product($params)
    {
        $id = is_array($params) ? $params['id'] : $params;
        $stmt = $this->db->query("SELECT * FROM shop_products WHERE id = ?", [$id]);
        $product = $stmt->fetch();

        if (!$product) { echo "Product not found"; return; }

        // Get Vendor info
        $stmt = $this->db->query("SELECT store_name FROM shop_vendors WHERE id = ?", [$product['vendor_id']]);
        $vendor = $stmt->fetch();

        // Get Reviews
        $stmt = $this->db->query("
            SELECT r.*, u.name as user_name 
            FROM shop_product_reviews r 
            JOIN users u ON r.user_id = u.id 
            WHERE r.product_id = ? 
            ORDER BY r.created_at DESC
        ", [$id]);
        $reviews = $stmt->fetchAll();

        // Calculate Average Rating
        $avgRating = 0;
        if (count($reviews) > 0) {
            $sum = 0;
            foreach ($reviews as $r) $sum += $r['rating'];
            $avgRating = round($sum / count($reviews), 1);
        }

        // Check Wishlist Status
        $isWishlisted = false;
        if (isset($_SESSION['user_id'])) {
            $stmt = $this->db->query("SELECT id FROM shop_wishlists WHERE user_id = ? AND product_id = ?", [$_SESSION['user_id'], $id]);
            if ($stmt->fetch()) $isWishlisted = true;
        }

        require_once __DIR__ . '/../Views/store/product.php';
    }

    public function submitReview()
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: /shop/login?msg=Login to review');
            exit;
        }

        $userId = $_SESSION['user_id'];
        $productId = $_POST['product_id'];
        $rating = (int)$_POST['rating'];
        $comment = trim($_POST['comment']);

        // Check if user bought product (Verified Purchase) logic could go here
        // For now, allow all logged in users 

        $this->db->query(
            "INSERT INTO shop_product_reviews (tenant_id, product_id, user_id, rating, comment) VALUES (?, ?, ?, ?, ?)",
            [$this->tenantId, $productId, $userId, $rating, $comment]
        );

        header("Location: /shop/product/$productId?review_submitted=1");
        exit;
    }

    // --- CART Logic (Session Based) ---
    public function addToCart()
    {
        $productId = $_POST['product_id'];
        $quantity = (int)($_POST['quantity'] ?? 1);

        if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

        if (isset($_SESSION['cart'][$productId])) {
            $_SESSION['cart'][$productId] += $quantity;
        } else {
            $_SESSION['cart'][$productId] = $quantity;
        }

        header('Location: /shop/cart');
        exit;
    }

    public function cart()
    {
        $cartItems = [];
        $total = 0;

        if (!empty($_SESSION['cart'])) {
            $ids = implode(',', array_keys($_SESSION['cart']));
            // Safe as keys are ints from session logic ideally, but better to prepare
            $inQuery = implode(',', array_fill(0, count($_SESSION['cart']), '?'));
            $stmt = $this->db->prepare("SELECT * FROM shop_products WHERE id IN ($inQuery)");
            $stmt->execute(array_keys($_SESSION['cart']));
            $products = $stmt->fetchAll();

            foreach ($products as $p) {
                $qty = $_SESSION['cart'][$p['id']];
                $subtotal = $p['price'] * $qty;
                $total += $subtotal;
                $p['qty'] = $qty;
                $p['subtotal'] = $subtotal;
                $cartItems[] = $p;
            }
        }

        require_once __DIR__ . '/../Views/store/cart.php';
    }

    // --- SECURE DOWNLOAD ---
    public function download($params)
    {
        $token = is_array($params) ? $params['token'] : $params;
        
        // Verify Token
        $stmt = $this->db->query("SELECT * FROM shop_digital_access WHERE token = ?", [$token]);
        $access = $stmt->fetch();

        if (!$access) { die("Invalid or expired download link."); }
        if ($access['max_downloads'] > 0 && $access['download_count'] >= $access['max_downloads']) {
            die("Download limit reached.");
        }

        // Get File Path
        $stmt = $this->db->query("
            SELECT p.file_path, p.name 
            FROM shop_order_items oi
            JOIN shop_products p ON oi.product_id = p.id
            WHERE oi.id = ?
        ", [$access['order_item_id']]);
        $product = $stmt->fetch();

        if (!$product || empty($product['file_path'])) { die("File not found on server."); }

        // Construct real path
        $fullPath = __DIR__ . '/../../../../public' . $product['file_path']; // Assumption based on upload logic

        if (!file_exists($fullPath)) { die("File missing on disk."); }

        // Increment count
        $this->db->query("UPDATE shop_digital_access SET download_count = download_count + 1 WHERE id = ?", [$access['id']]);

        // Serve File
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($fullPath).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($fullPath));
        readfile($fullPath);
        exit;
    }
}
