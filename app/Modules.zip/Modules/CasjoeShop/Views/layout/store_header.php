<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'Casjoe Shop' ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        :root { --primary-color: #000066; --secondary-color: #FFA600; }
        .text-primary { color: var(--primary-color) !important; }
        .text-gold { color: var(--secondary-color) !important; }
        .bg-gold { background-color: var(--secondary-color) !important; }
        .btn-primary { background-color: var(--primary-color); border-color: var(--primary-color); }
        .btn-outline-primary { color: var(--primary-color); border-color: var(--primary-color); }
        .btn-outline-primary:hover { background-color: var(--primary-color); color: white; }
        .navbar-brand { font-weight: bold; color: var(--primary-color); display: flex; align-items: center; gap: 10px; }
        .badge-count { position: absolute; top: 0; right: 0; transform: translate(50%, -50%); font-size: 0.75rem; }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
    <div class="container">
        <a class="navbar-brand" href="/shop">
            <img src="/assets/casjoe_shop_logo.png" alt="Logo" style="height: 40px;">
            Casjoe Shop
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#shopNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="shopNav">
            <ul class="navbar-nav me-3 mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="/shop">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Categories</a></li>
                <li class="nav-item"><a class="nav-link text-gold fw-bold" href="/shop/vendor/register">Sell on Casjoe</a></li>
            </ul>

            <!-- Global Search -->
            <form class="d-flex mx-auto mb-2 mb-lg-0" action="/shop" method="GET" style="flex-grow: 1; max-width: 500px;">
                <div class="input-group">
                    <input class="form-control border-end-0 border" type="search" name="q" placeholder="Search for products, brands and more" aria-label="Search" value="<?= htmlspecialchars($_GET['q'] ?? '') ?>">
                    <button class="btn btn-outline-secondary border-start-0 border" type="submit" style="background: white;">
                        <i class="bi bi-search text-muted"></i>
                    </button>
                </div>
            </form>
            <div class="d-flex align-items-center gap-3">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <div class="dropdown">
                        <a href="#" class="text-decoration-none text-dark dropdown-toggle" id="userMenu" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle fs-5"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userMenu">
                            <li><a class="dropdown-item" href="/shop/account"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
                            <li><a class="dropdown-item" href="/shop/account/orders"><i class="bi bi-box-seam"></i> My Orders</a></li>
                            <li><a class="dropdown-item" href="/shop/account/wishlist"><i class="bi bi-heart"></i> My Wishlist</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="/shop/vendor/dashboard">Vendor Portal</a></li>
                            <li><a class="dropdown-item text-danger" href="/shop/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="/shop/login" class="btn btn-sm btn-outline-primary">Login</a>
                <?php endif; ?>

                <a href="/shop/cart" class="position-relative text-dark">
                    <i class="bi bi-cart3 fs-4"></i>
                    <?php if(!empty($_SESSION['cart'])): ?>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            <?= count($_SESSION['cart']) ?>
                        </span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
    </div>
</nav>
