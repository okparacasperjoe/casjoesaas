<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>POS Terminal | Casjoe Shop</title>
    <link rel="stylesheet" href="/css/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        body { margin: 0; padding: 0; overflow: hidden; height: 100vh; display: flex; flex-direction: column; }
        .pos-container { display: flex; flex: 1; height: 100%; }
        
        /* Left: Products */
        .pos-products { flex: 1; padding: 20px; overflow-y: auto; background: #f4f6f9; }
        .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 15px; }
        .product-card { background: #fff; border-radius: 8px; padding: 10px; cursor: pointer; transition: transform 0.2s; box-shadow: 0 2px 5px rgba(0,0,0,0.05); text-align: center; }
        .product-card:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .product-img { width: 100%; height: 100px; object-fit: cover; border-radius: 4px; margin-bottom: 10px; background: #eee; }
        .product-price { font-weight: bold; color: var(--primary); }
        .product-stock { font-size: 0.8rem; color: #999; }

        /* Right: Cart */
        .pos-cart { width: 400px; background: #fff; border-left: 1px solid #ddd; display: flex; flex-direction: column; }
        .cart-header { padding: 20px; background: var(--primary); color: #fff; font-weight: bold; }
        .cart-items { flex: 1; overflow-y: auto; padding: 10px; }
        .cart-item { display: flex; justify-content: space-between; align-items: center; padding: 10px; border-bottom: 1px solid #eee; }
        .cart-item-info { flex: 1; }
        .cart-item-qty { display: flex; align-items: center; gap: 10px; margin: 0 10px; }
        .qty-btn { background: #eee; border: none; width: 25px; height: 25px; border-radius: 50%; cursor: pointer; }
        
        .cart-footer { padding: 20px; background: #f9f9f9; border-top: 1px solid #ddd; }
        .cart-total { font-size: 1.5rem; font-weight: bold; text-align: right; margin-bottom: 20px; }
        .checkout-btn { width: 100%; background: #28a745; color: #fff; padding: 15px; border: none; font-size: 1.2rem; border-radius: 6px; cursor: pointer; transition: background 0.3s; }
        .checkout-btn:hover { background: #218838; }

        .search-bar { margin-bottom: 20px; }
        .search-input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 1rem; }
    </style>
</head>
<body>
    <!-- Top Bar (Optional) -->
    <div style="background: #2c3e50; color: #fff; padding: 10px 20px; display: flex; justify-content: space-between; align-items: center;">
        <span style="font-weight: bold;">Casjoe POS</span>
        <a href="/shop/vendor/dashboard" style="color: #ccc; text-decoration: none;">Exit Terminal</a>
    </div>

    <div class="pos-container">
        <!-- Products Area -->
        <main class="pos-products">
            <div class="search-bar">
                <input type="text" id="search" class="search-input" placeholder="Scan Barcode or Search Product..." autofocus>
            </div>
            
            <div class="product-grid" id="grid">
                <?php foreach ($products as $p): ?>
                    <div class="product-card" onclick="addToCart(<?= htmlspecialchars(json_encode($p)) ?>)">
                        <img src="<?= $p['image_path'] ?? '/assets/placeholder.png' ?>" class="product-img">
                        <div style="font-weight: bold; font-size: 0.9rem; margin-bottom: 5px;"><?= htmlspecialchars($p['name']) ?></div>
                        <div class="product-price">$<?= number_format($p['price'], 2) ?></div>
                        <div class="product-stock">Stock: <?= $p['stock_quantity'] ?></div>
                        <div style="display:none;" class="product-sku"><?= $p['sku'] ?></div> <!-- Hidden for search -->
                    </div>
                <?php endforeach; ?>
            </div>
        </main>

        <!-- Cart Sidebar -->
        <aside class="pos-cart">
            <div class="cart-header">Current Sale</div>
            
            <!-- Customer Select -->
            <div style="padding: 10px; border-bottom: 1px solid #eee;">
                <select id="customer_id" class="form-control" style="width: 100%; padding: 8px;">
                    <option value="">-- Walk-in Customer --</option>
                    <?php foreach ($customers as $c): ?>
                        <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?> (<?= htmlspecialchars($c['email']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="cart-items" id="cartItems">
                <!-- Items injected here -->
                <div style="text-align: center; color: #999; margin-top: 50px;">Cart is empty</div>
            </div>

            <div class="cart-footer">
                <div style="margin-bottom: 15px; display: flex; gap: 10px;">
                    <input type="number" id="discount" class="form-control" placeholder="Discount ($)" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;" onchange="renderCart()">
                    <button onclick="holdCart()" style="background: #ffc107; border:none; padding: 10px; border-radius: 6px; cursor: pointer;">Hold</button>
                    <button onclick="restoreCart()" style="background: #17a2b8; border:none; padding: 10px; border-radius: 6px; color: #fff; cursor: pointer;">Load</button>
                </div>

                <div class="cart-total">Total: $<span id="cartTotal">0.00</span></div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                    <button class="checkout-btn" style="background: #28a745;" onclick="checkout('cash')">CASH</button>
                    <button class="checkout-btn" style="background: #007bff;" onclick="checkout('card')">CARD</button>
                </div>
            </div>
        </aside>
    </div>

    <script>
        // ... (existing js)
        
        async function checkout(method) {
            if (cart.length === 0) return alert('Cart is empty!');
            
            const discount = parseFloat(document.getElementById('discount').value || 0);
            const total = parseFloat(document.getElementById('cartTotal').innerText);
            const customerId = document.getElementById('customer_id').value;

            if (!confirm(`Process $${total} via ${method.toUpperCase()}?`)) return;

            // Simple loading state
            document.querySelectorAll('.checkout-btn').forEach(b => b.disabled = true);

            try {
                const response = await fetch('/shop/pos/checkout', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ cart, total, discount, payment_method: method, customer_id: customerId })
                });

                const result = await response.json();
                
                if (result.success) {
                    printReceipt(result.order_id, method, total, discount);
                    alert('Order Completed! ID: ' + result.order_id);
                    cart = [];
                    document.getElementById('discount').value = '';
                    renderCart();
                } else {
                    alert('Error: ' + result.error);
                }
            } catch (err) {
                alert('Network Error');
            }
            
            document.querySelectorAll('.checkout-btn').forEach(b => b.disabled = false);
        }

        // Hold Cart Logic
        function holdCart() {
            if (cart.length === 0) return;
            localStorage.setItem('pos_hold_cart', JSON.stringify(cart));
            cart = [];
            renderCart();
            alert('Cart Held!');
        }

        function restoreCart() {
            const held = localStorage.getItem('pos_hold_cart');
            if (!held) return alert('No held cart found');
            cart = JSON.parse(held);
            localStorage.removeItem('pos_hold_cart');
            renderCart();
        }

        function printReceipt(orderId, method, total, discount) {
            const win = window.open('', '', 'width=300,height=600');
            let itemsHtml = '';
            cart.forEach(i => itemsHtml += `<div>${i.name} x${i.qty} - $${(i.price * i.qty).toFixed(2)}</div>`);
            
            win.document.write(`
                <html>
                <body style="font-family: monospace; font-size: 12px; width: 280px;">
                    <div style="text-align:center;">
                        <h3>CASJOE SHOP</h3>
                        <p>Order #${orderId}</p>
                    </div>
                    <hr>
                    ${itemsHtml}
                    <hr>
                    <div style="text-align:right;">
                        Discount: -$${discount.toFixed(2)}<br>
                        <strong>TOTAL: $${total.toFixed(2)}</strong><br>
                        Paid via: ${method.toUpperCase()}
                    </div>
                    <p style="text-align:center; margin-top:20px;">Thank You!</p>
                </body>
                </html>
            `);
            win.print();
            // win.close(); // Optional, keep open to confirm
        }

        // Render override to include discount calc
        function renderCart() {
            const container = document.getElementById('cartItems');
            const totalEl = document.getElementById('cartTotal');
            
            container.innerHTML = '';
            let subtotal = 0;

            if (cart.length === 0) {
                container.innerHTML = '<div style="text-align: center; color: #999; margin-top: 50px;">Cart is empty</div>';
                totalEl.innerText = '0.00';
                return;
            }

            cart.forEach((item, index) => {
                const itemTotal = item.price * item.qty;
                subtotal += itemTotal;
                
                const div = document.createElement('div');
                div.className = 'cart-item';
                div.innerHTML = `
                    <div class="cart-item-info">
                        <strong>${item.name}</strong><br>
                        <small>$${item.price} x ${item.qty}</small>
                    </div>
                    <div class="cart-item-qty">
                        <button class="qty-btn" onclick="updateQty(${index}, -1)">-</button>
                        <span>${item.qty}</span>
                        <button class="qty-btn" onclick="updateQty(${index}, 1)">+</button>
                    </div>
                    <div style="font-weight: bold;">$${itemTotal.toFixed(2)}</div>
                `;
                container.appendChild(div);
            });

            const discount = parseFloat(document.getElementById('discount').value || 0);
            const total = Math.max(0, subtotal - discount);
            totalEl.innerText = total.toFixed(2);
        }
    </script>
</body>
</html>
