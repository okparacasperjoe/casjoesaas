<?php 
$title = "Add Product";
require __DIR__ . '/../../../../Core/Views/global_header.php';
?>

<div class="container mt-4 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0">Add New Product</h5>
                    <a href="/shop/vendor/products" class="btn btn-sm btn-outline-secondary">Cancel</a>
                </div>
                <div class="card-body p-4">
                    <form action="/shop/vendor/products/store" method="POST" enctype="multipart/form-data">
                        
                        <!-- Type Selection -->
                        <div class="mb-4 text-center">
                            <label class="form-label d-block text-muted">Product Type</label>
                            <div class="btn-group" role="group" aria-label="Product Type">
                                <input type="radio" class="btn-check" name="type" id="typePhysical" value="physical" checked onchange="toggleType()">
                                <label class="btn btn-outline-primary" for="typePhysical"><i class="bi bi-box-seam"></i> Physical Product</label>

                                <input type="radio" class="btn-check" name="type" id="typeDigital" value="digital" onchange="toggleType()">
                                <label class="btn btn-outline-info" for="typeDigital"><i class="bi bi-cloud-arrow-down"></i> Digital Product</label>
                            </div>
                        </div>

                        <!-- Basic Info -->
                        <div class="row g-3 mb-3">
                            <div class="col-md-12">
                                <label class="form-label">Product Name</label>
                                <input type="text" name="name" class="form-control" placeholder="e.g. Vintage T-Shirt or E-Book" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Category</label>
                                <input type="text" name="category" class="form-control" list="categories" placeholder="e.g. Clothing">
                                <datalist id="categories">
                                    <option value="Clothing">
                                    <option value="Electronics">
                                    <option value="Digital">
                                    <option value="Services">
                                    <option value="Home & Garden">
                                </datalist>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Price ($)</label>
                                <input type="number" name="price" class="form-control" step="0.01" min="0" placeholder="0.00" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Cover Image</label>
                                <input type="file" name="image" class="form-control" accept="image/*">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-control" rows="4"></textarea>
                        </div>

                        <!-- Physical Options -->
                        <div id="physicalOptions" class="p-3 bg-light rounded mb-3 border">
                            <h6 class="fw-bold mb-2"><i class="bi bi-truck"></i> Shipping & Stock</h6>
                            <div class="row g-3">
                                    <label class="form-label">Stock Quantity</label>
                                    <input type="number" name="stock_quantity" class="form-control" value="1">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">SKU (Stock Keeping Unit)</label>
                                    <input type="text" name="sku" class="form-control" placeholder="Automatic if empty">
                                </div>
                            </div>
                        </div>

                        <!-- Digital Options -->
                        <div id="digitalOptions" class="p-3 bg-light rounded mb-3 border" style="display:none;">
                            <h6 class="fw-bold mb-2 text-info"><i class="bi bi-file-earmark-lock"></i> Digital File Delivery</h6>
                            <div class="mb-3">
                                <label class="form-label">Upload File (PDF, ZIP, Audio)</label>
                                <input type="file" name="digital_file" class="form-control">
                                <div class="form-text">Customer will receive a secure download link after purchase.</div>
                            </div>
                        </div>

                        <div class="d-grid mt-4">
                            <button type="submit" class="btn btn-primary btn-lg">Create Product</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleType() {
    const isDigital = document.getElementById('typeDigital').checked;
    document.getElementById('physicalOptions').style.display = isDigital ? 'none' : 'block';
    document.getElementById('digitalOptions').style.display = isDigital ? 'block' : 'none';
}
</script>

<?php require __DIR__ . '/../../../../Core/Views/global_footer.php'; ?>
