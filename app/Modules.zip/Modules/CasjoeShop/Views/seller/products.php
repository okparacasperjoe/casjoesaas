<?php 
$title = "My Products";
require __DIR__ . '/../../../../Core/Views/global_header.php';
?>

<div class="container-fluid mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 fw-bold text-dark">My Products</h1>
        <div>
            <a href="/shop/vendor/dashboard" class="btn btn-outline-secondary">&larr; Dashboard</a>
            <a href="/shop/vendor/products/create" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Add New</a>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Price</th>
                            <th>Status</th>
                            <th>Sales</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($products)): ?>
                            <tr><td colspan="6" class="text-center py-4 text-muted">No products found.</td></tr>
                        <?php else: ?>
                            <?php foreach($products as $p): ?>
                            <tr>
                                <td style="width: 60px;">
                                    <?php if($p['image_path']): ?>
                                        <img src="<?= htmlspecialchars($p['image_path']) ?>" class="rounded" style="width: 40px; height: 40px; object-fit: cover;">
                                    <?php else: ?>
                                        <div class="bg-light rounded d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"><i class="bi bi-box"></i></div>
                                    <?php endif; ?>
                                </td>
                                <td class="fw-bold"><?= htmlspecialchars($p['name']) ?></td>
                                <td>
                                    <?php if($p['type'] == 'digital'): ?>
                                        <span class="badge bg-info text-dark">Digital</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Physical</span>
                                    <?php endif; ?>
                                </td>
                                <td>$<?= number_format($p['price'], 2) ?></td>
                                <td><span class="badge bg-success">Active</span></td>
                                <td>0</td> <!-- Placeholder for sales count -->
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../../../../Core/Views/global_footer.php'; ?>
