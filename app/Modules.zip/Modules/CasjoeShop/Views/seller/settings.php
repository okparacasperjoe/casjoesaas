<?php 
$title = "Store Settings - Vendor Dashboard";
require __DIR__ . '/../../../../Core/Views/global_header.php';
?>

<div class="container-fluid mt-4">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 fw-bold text-dark"><i class="bi bi-gear-fill"></i> Store Settings</h1>
            <div class="text-muted">Manage your store preferences</div>
        </div>
        <div>
            <a href="/shop/vendor/dashboard" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Back to Dashboard</a>
        </div>
    </div>

    <?php if(isset($_GET['msg'])): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?= htmlspecialchars($_GET['msg']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3">
                    <h5 class="fw-bold mb-0">Transaction Fees</h5>
                </div>
                <div class="card-body">
                    <form action="/shop/vendor/settings" method="POST">
                        <div class="mb-4">
                            <label class="form-label fw-bold d-block mb-3">Who pays the transaction fees?</label>
                            
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="radio" name="fee_bearer" id="fee_merchant" value="merchant" <?= ($vendor['fee_bearer'] ?? 'merchant') === 'merchant' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="fee_merchant">
                                    <strong>Merchant (You)</strong>
                                    <div class="text-muted small">
                                        Fees are deducted from your earnings. Customers see free shipping/processing.
                                        <br><em>Example: Product $100 -> Customer pays $100 -> You receive ~$97.</em>
                                    </div>
                                </label>
                            </div>

                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="fee_bearer" id="fee_customer" value="customer" <?= ($vendor['fee_bearer'] ?? 'merchant') === 'customer' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="fee_customer">
                                    <strong>Customer (Buyer)</strong>
                                    <div class="text-muted small">
                                        Fees are added to the transaction total. You receive the full product price.
                                        <br><em>Example: Product $100 -> Customer pays ~$103 -> You receive $100.</em>
                                    </div>
                                </label>
                            </div>
                        </div>

                        <hr>

                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../../../../Core/Views/global_footer.php'; ?>
