<?php 
$title = "Shop Home";
require __DIR__ . '/../layout/store_header.php';
?>

<div class="container mt-4">
    <!-- Top Banner -->
    <?php if(isset($adsByLocation['top']) && $adsByLocation['top']['is_active']): 
        $banner_ad = $adsByLocation['top'];
        include __DIR__ . '/ad_banner.php';
    endif; ?>
    <!-- Hero Banner -->
    <div class="p-5 mb-4 bg-light rounded-3 text-center border">
        <div class="container-fluid py-3">
            <h1 class="display-5 fw-bold text-gold">Marketplace</h1>
            <p class="col-md-8 fs-4 mx-auto">Discover unique physical and digital products from independent vendors.</p>
        </div>
    </div>

    <!-- Content Layout -->
    <div class="row">
        <!-- Sidebar Filters -->
        <div class="col-md-3 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3">
                    <h5 class="fw-bold mb-0">Filters</h5>
                </div>
                <div class="card-body">
                    <form action="/shop" method="GET">
                        <!-- Search -->
                        <div class="mb-3">
                            <label class="form-label fw-bold small text-uppercase">Search</label>
                            <input type="text" name="q" class="form-control" placeholder="Search products..." value="<?= htmlspecialchars($_GET['q'] ?? '') ?>">
                        </div>

                        <!-- Categories -->
                        <div class="mb-3">
                            <label class="form-label fw-bold small text-uppercase">Category</label>
                            <select name="category" class="form-select">
                                <option value="">All Categories</option>
                                <?php foreach($categories as $cat): ?>
                                    <option value="<?= htmlspecialchars($cat) ?>" <?= (isset($_GET['category']) && $_GET['category'] == $cat) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($cat) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Price Range -->
                        <div class="mb-3">
                            <label class="form-label fw-bold small text-uppercase">Price Range</label>
                            <div class="row g-2">
                                <div class="col-6">
                                    <input type="number" name="min_price" class="form-control" placeholder="Min" value="<?= htmlspecialchars($_GET['min_price'] ?? '') ?>">
                                </div>
                                <div class="col-6">
                                    <input type="number" name="max_price" class="form-control" placeholder="Max" value="<?= htmlspecialchars($_GET['max_price'] ?? '') ?>">
                                </div>
                            </div>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Apply Filters</button>
                            <a href="/shop" class="btn btn-outline-secondary btn-sm">Clear All</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Products Grid -->
        <div class="col-md-9">
            <!-- Middle Banner (Advertisement) -->
            <?php if(isset($adsByLocation['middle']) && $adsByLocation['middle']['is_active']): 
                $banner_ad = $adsByLocation['middle'];
                include __DIR__ . '/ad_banner.php';
            endif; ?>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0 text-gold">Latest Products</h3>
                <span class="text-muted"><?= count($products) ?> results found</span>
            </div>

            <?php if(empty($products)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-search fs-1 text-muted mb-3 d-block"></i>
                    <p class="text-muted">No products found matching your criteria.</p>
                </div>
            <?php else: ?>
                <div class="row row-cols-1 row-cols-md-3 g-4 mb-5">
                    <?php foreach ($products as $product): ?>
                    <div class="col">
                        <div class="card h-100 border-0 shadow-sm product-card">
                            <?php if($product['image_path']): ?>
                                <img src="<?= htmlspecialchars($product['image_path']) ?>" class="card-img-top" alt="<?= htmlspecialchars($product['name']) ?>" style="height: 200px; object-fit: cover;">
                            <?php else: ?>
                                <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height: 200px;">
                                    <i class="bi bi-box fs-1 text-muted"></i>
                                </div>
                            <?php endif; ?>
                            
                            <div class="card-body">
                                <div class="d-flex justify-content-between mb-2">
                                    <?php if($product['type'] == 'digital'): ?>
                                        <span class="badge bg-info text-dark">Digital</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Physical</span>
                                    <?php endif; ?>
                                    <?php if(!empty($product['category'])): ?>
                                        <span class="badge bg-light text-dark border"><?= htmlspecialchars($product['category']) ?></span>
                                    <?php endif; ?>
                                </div>
                                <h5 class="card-title fw-bold">
                                    <a href="/shop/product/<?= $product['id'] ?>" class="text-decoration-none text-dark stretched-link">
                                        <?= htmlspecialchars($product['name']) ?>
                                    </a>
                                </h5>
                                <p class="card-text text-muted small text-truncate"><?= htmlspecialchars($product['description'] ?? '') ?></p>
                                <h5 class="text-gold fw-bold">$<?= number_format($product['price'], 2) ?></h5>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../../../../Core/Views/global_footer.php'; ?>
