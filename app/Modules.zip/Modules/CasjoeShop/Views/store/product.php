<?php 
$title = htmlspecialchars($product['name']);
require __DIR__ . '/../layout/store_header.php';
?>

<div class="container mt-5 mb-5">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/shop">Shop</a></li>
            <li class="breadcrumb-item active"><?= htmlspecialchars($product['name']) ?></li>
        </ol>
    </nav>

    <div class="row g-5">
        <!-- Image -->
        <div class="col-md-6">
            <?php if($product['image_path']): ?>
                <img src="<?= htmlspecialchars($product['image_path']) ?>" class="img-fluid rounded shadow-sm w-100">
            <?php else: ?>
                <div class="bg-light rounded p-5 text-center shadow-sm" style="min-height: 400px; display: flex; align-items: center; justify-content: center;">
                    <i class="bi bi-box fs-1 text-muted" style="font-size: 5rem;"></i>
                </div>
            <?php endif; ?>
        </div>

        <!-- Details -->
        <div class="col-md-6">
            <div class="mb-3">
                <?php if($product['type'] == 'digital'): ?>
                    <span class="badge bg-info text-dark p-2"><i class="bi bi-cloud-arrow-down"></i> Digital Download</span>
                <?php else: ?>
                    <span class="badge bg-secondary p-2"><i class="bi bi-box-seam"></i> Physical Product</span>
                <?php endif; ?>
            </div>

            <div class="d-flex align-items-center mb-2">
                <div class="text-warning small me-2">
                    <?php 
                    for($i=1; $i<=5; $i++) {
                        if($i <= floor($avgRating)) echo '<i class="bi bi-star-fill"></i>';
                        elseif($i == ceil($avgRating) && $avgRating - floor($avgRating) > 0) echo '<i class="bi bi-star-half"></i>';
                        else echo '<i class="bi bi-star"></i>';
                    }
                    ?>
                </div>
                <span class="text-muted small">(<?= count($reviews) ?> reviews)</span>
            </div>

            <h1 class="fw-bold mb-2"><?= htmlspecialchars($product['name']) ?></h1>
            <div class="text-muted mb-4 small">Sold by <strong><?= htmlspecialchars($vendor['store_name']) ?></strong></div>

            <h2 class="text-primary fw-bold mb-4">$<?= number_format($product['price'], 2) ?></h2>

            <p class="lead text-muted mb-5"><?= nl2br(htmlspecialchars($product['description'])) ?></p>

            <div class="d-flex gap-2">
                <form action="/shop/cart/add" method="POST" class="flex-grow-1">
                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                    <div class="d-flex gap-3 align-items-center">
                        <input type="number" name="quantity" class="form-control" value="1" min="1" style="width: 80px;">
                        <button type="submit" class="btn btn-primary btn-lg px-5 w-100">Add to Cart</button>
                    </div>
                </form>

                <form action="/shop/wishlist/toggle" method="POST">
                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                    <button type="submit" class="btn btn-lg btn-outline-danger" title="<?= isset($isWishlisted) && $isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist' ?>">
                        <?php if(isset($isWishlisted) && $isWishlisted): ?>
                            <i class="bi bi-heart-fill"></i>
                        <?php else: ?>
                            <i class="bi bi-heart"></i>
                        <?php endif; ?>
                    </button>
                </form>
            </div>

            <?php if($product['type'] == 'digital'): ?>
            <div class="mt-4 p-3 bg-light rounded small">
                <i class="bi bi-info-circle-fill text-info"></i> You will receive a secure download link immediately after payment.
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Reviews Section -->
    <div class="row mt-5 pt-5 border-top">
        <div class="col-md-8">
            <h3 class="fw-bold mb-4">Customer Reviews</h3>
            
            <?php if(isset($_GET['review_submitted'])): ?>
                <div class="alert alert-success">Thank you! Your review has been submitted.</div>
            <?php endif; ?>

            <?php if(empty($reviews)): ?>
                <p class="text-muted">No reviews yet. Be the first to review this product!</p>
            <?php else: ?>
                <?php foreach($reviews as $r): ?>
                <div class="mb-4 pb-4 border-bottom">
                    <div class="d-flex align-items-center mb-2">
                        <div class="text-warning small me-2">
                            <?php for($i=1; $i<=5; $i++) echo ($i <= $r['rating']) ? '<i class="bi bi-star-fill"></i>' : '<i class="bi bi-star"></i>'; ?>
                        </div>
                        <span class="fw-bold me-2"><?= htmlspecialchars($r['user_name']) ?></span>
                        <span class="text-muted small"><?= date('M j, Y', strtotime($r['created_at'])) ?></span>
                    </div>
                    <?php if($r['comment']): ?>
                        <p class="mb-0 text-dark"><?= nl2br(htmlspecialchars($r['comment'])) ?></p>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <div class="col-md-4">
            <div class="card border-0 shadow-sm bg-light">
                <div class="card-body">
                    <h5 class="fw-bold mb-3">Write a Review</h5>
                    <?php if(isset($_SESSION['user_id'])): ?>
                    <form action="/shop/review" method="POST">
                        <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                        <div class="mb-3">
                            <label class="form-label">Rating</label>
                            <select name="rating" class="form-select" required>
                                <option value="5">★★★★★ (5 Stars)</option>
                                <option value="4">★★★★☆ (4 Stars)</option>
                                <option value="3">★★★☆☆ (3 Stars)</option>
                                <option value="2">★★☆☆☆ (2 Stars)</option>
                                <option value="1">★☆☆☆☆ (1 Star)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Review</label>
                            <textarea name="comment" class="form-control" rows="3" placeholder="Share your thoughts..."></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Submit Review</button>
                    </form>
                    <?php else: ?>
                        <p class="text-muted mb-3">Please login to write a review.</p>
                        <a href="/shop/login?redirect=/shop/product/<?= $product['id'] ?>" class="btn btn-outline-primary w-100">Login to Review</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../../../../Core/Views/global_footer.php'; ?>
