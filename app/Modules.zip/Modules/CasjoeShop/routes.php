<?php

use App\Core\Router;
use App\Modules\CasjoeShop\Controllers\AdminController;
use App\Modules\CasjoeShop\Controllers\VendorController;
use App\Modules\CasjoeShop\Controllers\ShopController;
use App\Modules\CasjoeShop\Controllers\CheckoutController;
use App\Modules\CasjoeShop\Controllers\ShopAuthController;
use App\Modules\CasjoeShop\Controllers\ShopCustomerController;
use App\Modules\CasjoeShop\Controllers\PosController;

// POS System
Router::get('/shop/pos', [PosController::class, 'terminal']);
Router::post('/shop/pos/checkout', [PosController::class, 'checkout']);

// Public Storefront
Router::get('/shop', [ShopController::class, 'index']);
Router::get('/shop/login', [ShopAuthController::class, 'login']);
Router::post('/shop/login', [ShopAuthController::class, 'attemptLogin']);
Router::get('/shop/register', [ShopAuthController::class, 'register']);
Router::post('/shop/register', [ShopAuthController::class, 'attemptRegister']);
Router::get('/shop/logout', [ShopAuthController::class, 'logout']);

// Customer Account
Router::get('/shop/account', [ShopCustomerController::class, 'dashboard']);
Router::get('/shop/account/orders/{id}', [ShopCustomerController::class, 'order']);
Router::get('/shop/account/wishlist', [ShopCustomerController::class, 'wishlist']);
Router::post('/shop/wishlist/toggle', [ShopCustomerController::class, 'toggleWishlist']);
Router::get('/shop/wishlist/remove/{id}', [ShopCustomerController::class, 'removeWishlist']);

Router::get('/shop/product/{id}', [ShopController::class, 'product']);
Router::get('/shop/category/{slug}', [ShopController::class, 'category']);
Router::post('/shop/cart/add', [ShopController::class, 'addToCart']);
Router::post('/shop/review', [ShopController::class, 'submitReview']);
Router::get('/shop/cart', [ShopController::class, 'cart']);
Router::get('/shop/checkout', [CheckoutController::class, 'index']);
Router::post('/shop/checkout/process', [CheckoutController::class, 'process']);
Router::get('/shop/download/{token}', [ShopController::class, 'download']); // Secure Download

// Vendor Portal
Router::get('/shop/vendor/register', [VendorController::class, 'register']);
Router::post('/shop/vendor/register', [VendorController::class, 'storeVendor']);
Router::get('/shop/vendor/dashboard', [VendorController::class, 'dashboard']);
Router::get('/shop/vendor/products', [VendorController::class, 'products']);
Router::get('/shop/vendor/products/create', [VendorController::class, 'createProduct']);
Router::post('/shop/vendor/products/store', [VendorController::class, 'storeProduct']);
Router::get('/shop/vendor/orders', [VendorController::class, 'orders']);
Router::get('/shop/vendor/settings', [VendorController::class, 'settings']);
Router::post('/shop/vendor/settings', [VendorController::class, 'updateSettings']);
Router::get('/shop/vendor/shipping', [VendorController::class, 'shipping']);
Router::post('/shop/vendor/shipping', [VendorController::class, 'storeShipping']);
Router::post('/shop/vendor/shipping/delete/{id}', [VendorController::class, 'deleteShipping']);
Router::get('/shop/vendor/coupons', [VendorController::class, 'coupons']);
Router::post('/shop/vendor/coupons', [VendorController::class, 'storeCoupon']);
Router::post('/shop/vendor/coupons/delete/{id}', [VendorController::class, 'deleteCoupon']);

// Admin (Platform Owner)
Router::get('/admin/shop', [AdminController::class, 'dashboard']);
Router::get('/admin/shop/ads', [AdminController::class, 'ads']);
Router::post('/admin/shop/ads/update', [AdminController::class, 'updateAds']);

// Checkout Actions
Router::post('/shop/checkout/coupon/apply', [CheckoutController::class, 'applyCoupon']);
Router::get('/shop/checkout/coupon/remove', [CheckoutController::class, 'removeCoupon']);
Router::get('/admin/shop/vendors', [AdminController::class, 'vendors']);
Router::post('/admin/shop/vendors/{id}/approve', [AdminController::class, 'approveVendor']);
