<?php

namespace App\Modules\CasjoeSmartForms\Controllers;

use App\Core\Database;
use App\Core\TenantContext;

class FormController
{
    public function index()
    {
        // List all forms
        $db = Database::getInstance();
        $tenantId = TenantContext::getTenantId();
        
        $stmt = $db->query("SELECT * FROM smart_forms WHERE tenant_id = ? ORDER BY created_at DESC", [$tenantId]);
        $forms = $stmt->fetchAll();

        // Dashboard Analytics
        $totalForms = count($forms);
        $totalSubmissions = 0;
        $totalViews = 0;

        // Simple aggregation (in a real app, do this via SQL count)
        $formIds = array_column($forms, 'id');
        if (!empty($formIds)) {
            $ids = implode(',', $formIds);
            $stmt = $db->query("SELECT COUNT(*) as cnt FROM smart_form_submissions WHERE form_id IN ($ids)");
            $totalSubmissions = $stmt->fetch()['cnt'] ?? 0;

            $stmt = $db->query("SELECT COUNT(*) as cnt FROM smart_form_analytics WHERE form_id IN ($ids) AND event_type='view'");
            $totalViews = $stmt->fetch()['cnt'] ?? 0;
        }

        require_once __DIR__ . '/../Views/index.php';
    }

    public function create()
    {
        // Show builder
        require_once __DIR__ . '/../Views/create.php';
    }

    public function store()
    {
        // Save new form
        $db = Database::getInstance();
        $tenantId = TenantContext::getTenantId();
        // Placeholder user ID (should get from session)
        $userId = $_SESSION['user_id'] ?? 1; 

        $title = $_POST['title'] ?? 'Untitled Form';
        $structure = $_POST['structure'] ?? '[]'; // JSON string
        $settings = $_POST['settings'] ?? '{}';

        $db->query("INSERT INTO smart_forms (tenant_id, user_id, title, structure, settings) VALUES (?, ?, ?, ?, ?)", 
            [$tenantId, $userId, $title, $structure, $settings]);

        header("Location: /admin/smart-forms");
        exit;
    }

    public function edit($id)
    {
        $id = is_array($id) ? $id['id'] : $id;
        // Show builder with existing data
        $db = Database::getInstance();
        $tenantId = TenantContext::getTenantId();

        $stmt = $db->query("SELECT * FROM smart_forms WHERE id = ? AND tenant_id = ?", [$id, $tenantId]);
        $form = $stmt->fetch();

        require_once __DIR__ . '/../Views/create.php';
    }

    public function update($id)
    {
        $id = is_array($id) ? $id['id'] : $id;
        $db = Database::getInstance();
        $tenantId = TenantContext::getTenantId();
        
        $title = $_POST['title'];
        $structure = $_POST['structure'];
        
        $db->query("UPDATE smart_forms SET title = ?, structure = ? WHERE id = ? AND tenant_id = ?", 
            [$title, $structure, $id, $tenantId]);
            
        header("Location: /admin/smart-forms");
        exit;
    }
    
    public function delete($id)
    {
        $id = is_array($id) ? $id['id'] : $id;
        $db = Database::getInstance();
        $tenantId = TenantContext::getTenantId();
        
        $db->query("DELETE FROM smart_forms WHERE id = ? AND tenant_id = ?", [$id, $tenantId]);
        
        header("Location: /admin/smart-forms");
        exit;
    }

    public function stats($id)
    {
        $id = is_array($id) ? $id['id'] : $id;
        $db = Database::getInstance();
        $tenantId = TenantContext::getTenantId();

        // Get Form Info
        $stmt = $db->query("SELECT * FROM smart_forms WHERE id = ? AND tenant_id = ?", [$id, $tenantId]);
        $form = $stmt->fetch();

        if (!$form) die("Form not found");

        $settings = json_decode($form['settings'] ?? '{}', true);

        // --- 1. Top KPI Strip ---
        // Views
        $stmt = $db->query("SELECT COUNT(*) as count FROM smart_form_analytics WHERE form_id = ? AND event_type = 'view'", [$id]);
        $views = $stmt->fetch()['count'];

        // Starts
        $stmt = $db->query("SELECT COUNT(*) as count FROM smart_form_analytics WHERE form_id = ? AND event_type = 'start'", [$id]);
        $starts = $stmt->fetch()['count'];

        // Submissions
        $stmt = $db->query("SELECT COUNT(*) as count FROM smart_form_submissions WHERE form_id = ?", [$id]);
        $submissions = $stmt->fetch()['count'];

        // Payments
        $stmt = $db->query("SELECT COUNT(*) as count FROM smart_form_submissions WHERE form_id = ? AND payment_status = 'paid'", [$id]);
        $payments = $stmt->fetch()['count'];

        $kpi = [
            'views' => $views,
            'starts' => $starts,
            'submissions' => $submissions,
            'payments' => $payments
        ];

        // --- 2. Conversion Funnel ---
        $funnel = [
            'views' => ['count' => $views, 'drop_off' => 0],
            'starts' => ['count' => $starts, 'drop_off' => $views > 0 ? round((($views - $starts) / $views) * 100) : 0],
            'submitted' => ['count' => $submissions, 'drop_off' => $starts > 0 ? round((($starts - $submissions) / $starts) * 100) : 0],
            'paid' => ['count' => $payments, 'drop_off' => $submissions > 0 ? round((($submissions - $payments) / $submissions) * 100) : 0]
        ];

        // --- 3. Biggest Problem Alert ---
        // Basic Logic: Find where most people are stuck.
        // For now, let's look at the "interaction" events to find the last field.
        $alert = "No major drop-off detected";
        if ($starts > 0 && $submissions == 0) {
            $alert = "Users are starting but not finishing. Check your form length.";
        }
        
        // --- 4. Traffic Quality ---
        // Device
        $stmt = $db->query("SELECT device_type, COUNT(*) as count FROM smart_form_analytics WHERE form_id = ? AND event_type = 'view' GROUP BY device_type", [$id]);
        $deviceStats = $stmt->fetchAll(\PDO::FETCH_KEY_PAIR);
        $totalDevices = array_sum($deviceStats);
        $devices = [
            'mobile' => $totalDevices > 0 && isset($deviceStats['mobile']) ? round(($deviceStats['mobile'] / $totalDevices) * 100) : 0,
            'desktop' => $totalDevices > 0 && isset($deviceStats['desktop']) ? round(($deviceStats['desktop'] / $totalDevices) * 100) : 0
        ];

        // --- 5. Revenue Snapshot ---
        $revenue = 0;
        if (!empty($settings['payment_enabled'])) {
            $stmt = $db->query("SELECT SUM(amount) as total FROM smart_form_submissions WHERE form_id = ? AND payment_status = 'paid'", [$id]);
            $revenue = $stmt->fetch()['total'] ?? 0;
        }

        // --- 6. Recent Activity ---
        $stmt = $db->query("
            SELECT 'submission' as type, created_at, data as details FROM smart_form_submissions WHERE form_id = ? 
            UNION 
            SELECT 'view' as type, created_at, concat('IP: ', ip_address) as details FROM smart_form_analytics WHERE form_id = ? AND event_type='view'
            ORDER BY created_at DESC LIMIT 5
        ", [$id, $id]);
        $activity = $stmt->fetchAll();

        require_once __DIR__ . '/../Views/stats.php';
    }
    public function templates()
    {
        // Pre-defined templates
        $templates = [
            [
                'id' => 'contact',
                'title' => 'Contact Us',
                'description' => 'Standard contact form with name, email, subject, and message fields.',
                'icon' => 'mail-outline',
                'structure' => json_encode([
                    ['type' => 'text', 'label' => 'Full Name', 'name' => 'full_name', 'options' => ''],
                    ['type' => 'email', 'label' => 'Email Address', 'name' => 'email', 'options' => ''],
                    ['type' => 'text', 'label' => 'Subject', 'name' => 'subject', 'options' => ''],
                    ['type' => 'textarea', 'label' => 'Message', 'name' => 'message', 'options' => '']
                ])
            ],
            [
                'id' => 'feedback',
                'title' => 'Customer Feedback',
                'description' => 'Collect feedback with rating and comments.',
                'icon' => 'star-outline',
                'structure' => json_encode([
                    ['type' => 'text', 'label' => 'Customer Name', 'name' => 'customer_name', 'options' => ''],
                    ['type' => 'dropdown', 'label' => 'How would you rate us?', 'name' => 'rating', 'options' => 'Excellent, Good, Average, Poor'],
                    ['type' => 'textarea', 'label' => 'What can we improve?', 'name' => 'feedback_text', 'options' => ''],
                    ['type' => 'checkbox', 'label' => 'May we contact you?', 'name' => 'contact_consent', 'options' => '']
                ])
            ],
            [
                'id' => 'registration',
                'title' => 'Event Registration',
                'description' => 'Register attendees for an upcoming event.',
                'icon' => 'calendar-outline',
                'structure' => json_encode([
                    ['type' => 'text', 'label' => 'Attendee Name', 'name' => 'attendee_name', 'options' => ''],
                    ['type' => 'email', 'label' => 'Email Address', 'name' => 'email', 'options' => ''],
                    ['type' => 'dropdown', 'label' => 'Ticket Type', 'name' => 'ticket_type', 'options' => 'General Admission, VIP, Student'],
                    ['type' => 'textarea', 'label' => 'Dietary Restrictions', 'name' => 'dietary', 'options' => '']
                ])
            ],
            [
                'id' => 'job_app',
                'title' => 'Job Application',
                'description' => 'Simple application form with resume upload.',
                'icon' => 'briefcase-outline',
                'structure' => json_encode([
                    ['type' => 'text', 'label' => 'Full Name', 'name' => 'full_name', 'options' => ''],
                    ['type' => 'email', 'label' => 'Email', 'name' => 'email', 'options' => ''],
                    ['type' => 'url', 'label' => 'Portfolio / LinkedIn', 'name' => 'portfolio_url', 'options' => ''],
                    ['type' => 'file', 'label' => 'Resume / CV', 'name' => 'resume', 'options' => ''],
                    ['type' => 'textarea', 'label' => 'Cover Letter', 'name' => 'cover_letter', 'options' => '']
                ])
            ]
        ];

        require_once __DIR__ . '/../Views/templates.php';
    }

    public function useTemplate()
    {
        $db = Database::getInstance();
        $tenantId = TenantContext::getTenantId();
        $userId = $_SESSION['user_id'] ?? 1;

        $title = $_POST['title'] ?? 'New Form';
        $structure = $_POST['structure'] ?? '[]';
        
        // Settings defaults
        $settings = json_encode(['payment_enabled' => false]);

        $db->query("INSERT INTO smart_forms (tenant_id, user_id, title, structure, settings) VALUES (?, ?, ?, ?, ?)", 
            [$tenantId, $userId, $title, $structure, $settings]); // Insert and get ID
            
        $id = $db->lastInsertId();

        header("Location: /admin/smart-forms/edit/" . $id);
        exit;
    }
}
