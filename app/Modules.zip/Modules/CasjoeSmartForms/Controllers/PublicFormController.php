<?php

namespace App\Modules\CasjoeSmartForms\Controllers;

use App\Core\Database;
use App\Core\TenantContext;

class PublicFormController
{
    public function show($id)
    {
        $id = is_array($id) ? $id['id'] : $id;
        $db = Database::getInstance();
        // Since this is public, we might not have a logged-in tenant context in the same way,
        // but for subdomain multi-tenancy we should still have TenantContext resolved.
        $tenantId = TenantContext::getTenantId();

        $stmt = $db->query("SELECT * FROM smart_forms WHERE id = ? AND tenant_id = ?", [$id, $tenantId]);
        $form = $stmt->fetch();

        if (!$form) {
            http_response_code(404);
            echo "Form not found";
            return;
        }

        // Track view
        $this->trackEvent($form['id'], 'view', $tenantId);

        require_once __DIR__ . '/../Views/public/render.php';
    }

    public function submit($id)
    {
        $id = is_array($id) ? $id['id'] : $id;
        $db = Database::getInstance();
        $tenantId = TenantContext::getTenantId();

        // 1. Handle File Uploads & Data
        $submissionData = $_POST;

        if (!empty($_FILES)) {
            $uploadBase = __DIR__ . '/../../../../public/uploads/forms/' . $tenantId;
            if (!is_dir($uploadBase)) {
                mkdir($uploadBase, 0777, true);
            }

            foreach ($_FILES as $key => $file) {
                if ($file['error'] === UPLOAD_ERR_OK) {
                    // Simple validation: limit size to 5MB
                    if ($file['size'] > 5 * 1024 * 1024) continue;

                    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx'];
                    
                    if (in_array($ext, $allowed)) {
                        $filename = uniqid('form_') . '.' . $ext;
                        $targetPath = $uploadBase . '/' . $filename;
                        
                        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                            $submissionData[$key] = '/uploads/forms/' . $tenantId . '/' . $filename;
                        }
                    }
                }
            }
        }

        $jsonData = json_encode($submissionData);
        
        $db->query("INSERT INTO smart_form_submissions (tenant_id, form_id, data) VALUES (?, ?, ?)", 
            [$tenantId, $id, $jsonData]);

        // 2. Track Completion
        $this->trackEvent($id, 'completion', $tenantId);

        // 3. Payment Integration
        $stmt = $db->query("SELECT settings FROM smart_forms WHERE id = ?", [$id]);
        $settings = json_decode($stmt->fetch()['settings'] ?? '{}', true);

        if (!empty($settings['payment_enabled']) && !empty($settings['payment_amount'])) {
            // Redirect to Casjoe Pay (Mock URL for now)
            $amount = $settings['payment_amount'];
            $currency = $settings['payment_currency'] ?? 'NGN';
            // In a real scenario, we'd generate a payment link or redirect with params
            header("Location: /pay/checkout?amount=$amount&currency=$currency&ref=FORM-$id");
            exit;
        }

        // Default Success
        header("Location: /f/$id?status=success");
        exit;
    }

    public function trackAJAX($id)
    {
        $id = is_array($id) ? $id['id'] : $id;
        // Simple endpoint for JS beacons
        $data = json_decode(file_get_contents('php://input'), true);
        $event = $data['event'] ?? 'view';
        $metadata = $data['metadata'] ?? [];

        // Resolve Tenant (Public context might need domain check, but for now we query from form)
        // We need tenant_id to store stats. 
        $db = Database::getInstance();
        $stmt = $db->query("SELECT tenant_id FROM smart_forms WHERE id = ?", [$id]);
        $form = $stmt->fetch();
        
        if ($form) {
            $this->storeEvent($id, $event, $form['tenant_id'], $metadata);
        }
        
        header('Content-Type: application/json');
        echo json_encode(['status' => 'ok']);
        exit;
    }

    private function trackEvent($formId, $type, $tenantId)
    {
        $this->storeEvent($formId, $type, $tenantId);
    }

    private function storeEvent($formId, $type, $tenantId, $metadata = [])
    {
        $db = Database::getInstance();
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
        
        // Simple device detection logic
        $device = 'desktop';
        if (preg_match('/(mobile|android|iphone|ipad)/i', $ua)) {
            $device = 'mobile';
        }

        $metaJson = !empty($metadata) ? json_encode($metadata) : null;

        $db->query("INSERT INTO smart_form_analytics (tenant_id, form_id, event_type, metadata, ip_address, device_type) VALUES (?, ?, ?, ?, ?, ?)", 
            [$tenantId, $formId, $type, $metaJson, $ip, $device]);
    }
}
