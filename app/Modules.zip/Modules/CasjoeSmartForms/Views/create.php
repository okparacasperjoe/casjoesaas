<?php $title = "Form Builder"; include __DIR__ . '/layout/header.php'; ?>

<style>
    .builder-container { display: flex; gap: 20px; }
    .toolbox { 
        width: 300px; 
        background: rgba(255,255,255,0.05); 
        padding: 20px; 
        border-radius: 8px; 
        border: 1px solid rgba(255,255,255,0.1);
        backdrop-filter: blur(5px);
    }
    .canvas { 
        flex: 1; 
        background: rgba(255,255,255,0.02); 
        padding: 30px; 
        border-radius: 8px; 
        border: 1px solid rgba(255,255,255,0.1);
        min-height: 500px; 
    }
    .field-item { 
        border: 1px solid rgba(255,255,255,0.1); 
        padding: 10px; 
        margin-bottom: 10px; 
        background: rgba(255,255,255,0.05); 
        cursor: move; 
        border-radius: 4px; 
        color: white;
    }
    .field-item:hover {
        background: rgba(255,255,255,0.1);
    }
    .canvas-field { 
        border: 1px dashed rgba(255,255,255,0.3); 
        padding: 15px; 
        margin-bottom: 15px; 
        background: rgba(255,255,255,0.05); 
        position: relative; 
    }
    .canvas-field:hover { 
        border-color: #FFA600; 
        background: rgba(255,255,255,0.08); 
    }
    .remove-btn { position: absolute; top: 10px; right: 10px; color: #ff6b6b; cursor: pointer; }
</style>

<div class="container-fluid">
    <div class="row mb-3">
        <div class="col">
            <h1><?= isset($form) ? 'Edit Form: ' . htmlspecialchars($form['title']) : 'Create New Form' ?></h1>
        </div>
    </div>
    
    <form id="builderForm" action="<?= isset($form) ? '/admin/smart-forms/update/'.$form['id'] : '/admin/smart-forms/store' ?>" method="POST">
        <div class="mb-3">
            <label class="form-label">Form Title</label>
            <input type="text" name="title" class="form-control" value="<?= isset($form) ? htmlspecialchars($form['title']) : '' ?>" required>
        </div>

        <div class="builder-container">
            <div class="toolbox">
                <h5>Toolbox</h5>
                <p class="text-muted small">Click to add fields</p>
                <div class="d-grid gap-2">
                    <button type="button" class="btn btn-outline-primary text-start" onclick="addField('text')">TXT Text Field</button>
                    <button type="button" class="btn btn-outline-primary text-start" onclick="addField('email')">@ Email Address</button>
                    <button type="button" class="btn btn-outline-primary text-start" onclick="addField('url')">🔗 Website Link</button>
                    <button type="button" class="btn btn-outline-primary text-start" onclick="addField('textarea')">¶ Long Text</button>
                    <button type="button" class="btn btn-outline-primary text-start" onclick="addField('dropdown')">▼ Dropdown</button>
                    <button type="button" class="btn btn-outline-primary text-start" onclick="addField('checkbox')">☑ Checkbox</button>
                    <button type="button" class="btn btn-outline-secondary text-start" onclick="addField('file')">📷 Image Upload</button>
                    <button type="button" class="btn btn-outline-info text-start" onclick="addField('content')">ℹ️ Info/Links Block</button>
                </div>
                
                <hr>
                <button type="submit" class="btn btn-success w-100">Save Form</button>
                <a href="/admin/smart-forms" class="btn btn-link text-muted w-100 mt-2">Cancel</a>
            </div>

            <div class="canvas" id="formCanvas">
                <!-- Fields will be dropped here -->
                <div class="text-center text-muted" id="emptyParams">
                    <p>Your form is empty. Add fields from the toolbox.</p>
                </div>
            </div>
        </div>

        <!-- Hidden Input to store JSON structure -->
        <input type="hidden" name="structure" id="structureInput">
    </form>
</div>

<script>
    let fields = <?= isset($form) && $form['structure'] ? $form['structure'] : '[]' ?>;
    
    function render() {
        const canvas = document.getElementById('formCanvas');
        canvas.innerHTML = '';

        if (fields.length === 0) {
            canvas.innerHTML = '<div class="text-center text-muted p-5">Your form is empty. Add fields from the toolbox.</div>';
            return;
        }

        fields.forEach((field, index) => {
            const el = document.createElement('div');
            el.className = 'canvas-field';
            if(field.type === 'content') el.style.borderLeft = "4px solid #17a2b8";
            
            el.innerHTML = `
                <div class="row">
                    <div class="col-8">
                        <label class="form-label">${field.type === 'content' ? 'Heading / Title' : 'Field Label'}</label>
                        <input type="text" class="form-control mb-2" value="${field.label}" onchange="updateLabel(${index}, this.value)" placeholder="Enter label">
                        
                        ${renderFieldPreview(field)}
                    </div>
                    <div class="col-4 border-start">
                        <div class="mb-2">
                            <label class="small text-muted">Field Name (Internal)</label>
                            <input type="text" class="form-control form-control-sm" value="${field.name}" onchange="updateName(${index}, this.value)" ${field.type === 'content' ? 'disabled' : ''}>
                        </div>
                         ${field.type === 'dropdown' ? renderOptionsEditor(field, index) : ''}
                         ${field.type === 'content' ? renderContentEditor(field, index) : ''}
                    </div>
                </div>
                <span class="remove-btn" onclick="removeField(${index})">&times; Remove</span>
            `;
            canvas.appendChild(el);
        });

        document.getElementById('structureInput').value = JSON.stringify(fields);
    }

    function renderFieldPreview(field) {
        if (field.type === 'text') return '<input type="text" class="form-control" disabled placeholder="Text Answer">';
        if (field.type === 'email') return '<input type="email" class="form-control" disabled placeholder="user@example.com">';
        if (field.type === 'url') return '<input type="url" class="form-control" disabled placeholder="https://example.com">';
        if (field.type === 'textarea') return '<textarea class="form-control" disabled rows="3"></textarea>';
        if (field.type === 'file') return '<input type="file" class="form-control" disabled>';
        if (field.type === 'checkbox') return '<div class="form-check"><input class="form-check-input" type="checkbox" disabled> <label class="form-check-label">Option</label></div>';
        if (field.type === 'content') return `<div class="p-2 bg-light small text-muted">${field.options || '<i>No content added. Use the sidebar to add links/text.</i>'}</div>`;
        if (field.type === 'dropdown') {
             let opts = field.options ? field.options.split(',') : ['Option 1', 'Option 2'];
             return `<select class="form-select" disabled>${opts.map(o => `<option>${o.trim()}</option>`).join('')}</select>`;
        }
        return '';
    }

    function renderOptionsEditor(field, index) {
        return `
            <div class="mb-2">
                <label class="small text-muted">Options (comma separated)</label>
                <input type="text" class="form-control form-control-sm" value="${field.options || ''}" onchange="updateOptions(${index}, this.value)">
            </div>
        `;
    }

    function renderContentEditor(field, index) {
        return `
            <div class="mb-2">
                <label class="small text-muted">Description / Links (HTML ok)</label>
                <textarea class="form-control form-control-sm" rows="4" onchange="updateOptions(${index}, this.value)">${field.options || ''}</textarea>
            </div>
        `;
    }

    function addField(type) {
        const id = Date.now().toString().slice(-4);
        fields.push({
            type: type,
            label: type === 'content' ? 'Information' : 'New ' + type + ' field',
            name: type + '_' + id,
            options: type === 'dropdown' ? 'Option 1, Option 2' : (type === 'content' ? 'Add your links or text here.' : '')
        });
        render();
    }

    function removeField(index) {
        fields.splice(index, 1);
        render();
    }

    function updateLabel(index, val) {
        fields[index].label = val;
        document.getElementById('structureInput').value = JSON.stringify(fields);
    }

    function updateName(index, val) {
        fields[index].name = val;
        document.getElementById('structureInput').value = JSON.stringify(fields);
    }

    function updateOptions(index, val) {
        fields[index].options = val;
        render(); // re-render to update preview
    }

    // Initial render
    render();
</script>

<?php include __DIR__ . '/layout/footer.php'; ?>
