<?php $title = "Smart Forms"; include __DIR__ . '/layout/header.php'; ?>

<div class="container-fluid" style="padding-top: 20px;">
    <!-- Welcome / Header Section -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold text-white">Smart Forms</h2>
            <p class="text-muted">Create, manage and track your forms.</p>
        </div>
        <div>
            <a href="/admin/smart-forms/create" class="btn btn-primary d-flex align-items-center gap-2">
                <ion-icon name="add-circle-outline" style="font-size: 1.2rem;"></ion-icon>
                Create New Form
            </a>
        </div>
    </div>

    <!-- Analytics Cards -->
    <div class="row mb-5">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body d-flex align-items-center">
                    <div class="rounded-circle p-3 bg-primary bg-opacity-10 text-primary me-3">
                        <ion-icon name="document-text-outline" style="font-size: 1.5rem;"></ion-icon>
                    </div>
                    <div>
                        <h6 class="text-muted mb-0">Total Forms</h6>
                        <h3 class="fw-bold mb-0"><?= $totalForms ?? 0 ?></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body d-flex align-items-center">
                    <div class="rounded-circle p-3 bg-success bg-opacity-10 text-success me-3">
                        <ion-icon name="paper-plane-outline" style="font-size: 1.5rem;"></ion-icon>
                    </div>
                    <div>
                        <h6 class="text-muted mb-0">Total Submissions</h6>
                        <h3 class="fw-bold mb-0"><?= $totalSubmissions ?? 0 ?></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body d-flex align-items-center">
                    <div class="rounded-circle p-3 bg-info bg-opacity-10 text-info me-3">
                        <ion-icon name="eye-outline" style="font-size: 1.5rem;"></ion-icon>
                    </div>
                    <div>
                        <h6 class="text-muted mb-0">Total Views</h6>
                        <h3 class="fw-bold mb-0"><?= $totalViews ?? 0 ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Forms List -->
    <div class="card border-0 shadow-sm">
        <div class="card-header py-3">
            <h5 class="mb-0 fw-bold">Your Forms</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4">Form Title</th>
                            <th>Status</th>
                            <th>Created On</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($forms)): ?>
                            <tr>
                                <td colspan="4" class="text-center py-5">
                                    <div class="text-muted">
                                        <ion-icon name="file-tray-outline" style="font-size: 3rem; opacity: 0.5;"></ion-icon>
                                        <p class="mt-2 text-muted">No forms created yet.</p>
                                        <a href="/admin/smart-forms/create" class="btn btn-sm btn-outline-primary mt-2">Create your first form</a>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($forms as $form): ?>
                            <tr>
                                <td class="ps-4">
                                    <div class="d-flex align-items-center">
                                        <div class="rounded p-2 me-3 text-white" style="background: rgba(255,255,255,0.1)">
                                            <ion-icon name="clipboard-outline"></ion-icon>
                                        </div>
                                        <div>
                                            <div class="fw-bold text-white"><?= htmlspecialchars($form['title']) ?></div>
                                            <div class="small text-muted">ID: <?= $form['id'] ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($form['status'] === 'active'): ?>
                                        <span class="badge bg-success bg-opacity-10 text-success px-3 py-2 rounded-pill">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary bg-opacity-10 text-secondary px-3 py-2 rounded-pill">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-muted small">
                                    <?= date('M d, Y', strtotime($form['created_at'])) ?>
                                </td>
                                <td class="text-end pe-4">
                                    <div class="btn-group">
                                        <a href="/f/<?= $form['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary" title="View Public Link">
                                            <ion-icon name="open-outline"></ion-icon>
                                        </a>
                                        <a href="/admin/smart-forms/stats/<?= $form['id'] ?>" class="btn btn-sm btn-outline-info" title="Analytics">
                                            <ion-icon name="bar-chart-outline"></ion-icon>
                                        </a>
                                        <a href="/admin/smart-forms/edit/<?= $form['id'] ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                                            <ion-icon name="create-outline"></ion-icon>
                                        </a>
                                        <form action="/admin/smart-forms/delete/<?= $form['id'] ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this form?');">
                                            <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                                <ion-icon name="trash-outline"></ion-icon>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/layout/footer.php'; ?>
