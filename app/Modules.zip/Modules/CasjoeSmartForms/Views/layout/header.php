<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'Casjoe Smart Forms' ?></title>
    <link rel="stylesheet" href="/css/style.css">
    <!-- Bootstrap 5 for Builder UI -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <style>
        .app-container { min-height: 100vh; display: flex; }
        .main-content { flex: 1; padding: 20px; /* background transparent to let body bg show */ }
        
        /* Dark Theme Overrides for Bootstrap */
        .card {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            color: white;
        }
        .card-header {
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            color: white;
        }
        .text-dark { color: white !important; }
        .text-muted { color: rgba(255, 255, 255, 0.6) !important; }
        .bg-white { background: transparent !important; }
        .bg-light { background: rgba(255, 255, 255, 0.05) !important; }
        
        /* Tables */
        .table { color: white; }
        .table-hover tbody tr:hover { color: white; background-color: rgba(255, 255, 255, 0.1); }
        .table thead th { border-bottom: 1px solid rgba(255, 255, 255, 0.1); color: rgba(255, 255, 255, 0.7); }
        .table td, .table th { border-color: rgba(255, 255, 255, 0.1); }
        
        /* Forms */
        .form-control, .form-select {
            background-color: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: white;
        }
        .form-control:focus, .form-select:focus {
            background-color: rgba(255, 255, 255, 0.1);
            border-color: #FFA600;
            color: white;
            box-shadow: 0 0 0 0.25rem rgba(255, 166, 0, 0.25);
        }
        .form-label { color: rgba(255, 255, 255, 0.9); }

        /* Buttons */
        .btn-outline-secondary { color: rgba(255, 255, 255, 0.8); border-color: rgba(255, 255, 255, 0.3); }
        .btn-outline-secondary:hover { background: rgba(255, 255, 255, 0.1); color: white; }
        
        /* List Groups */
        .list-group-item { background: transparent; border-color: rgba(255, 255, 255, 0.1); color: white; }
        
        /* Sidebar Overrides */
        .sidebar .nav-link { color: white !important; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { color: white !important; background: rgba(255, 255, 255, 0.1); }
    </style>
</head>
<body>
<?php require_once dirname(__DIR__, 4) . '/core/Views/partials/mobile_nav.php'; ?>
<div class="app-container">
    <aside class="sidebar">
        <div class="brand">
            <img src="/assets/casjoe_logo.png" alt="Casjoe" style="height: 40px;">
        </div>

        <ul class="nav-menu">
            <li class="nav-item">
                <a href="/admin/smart-forms" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/smart-forms') !== false && strpos($_SERVER['REQUEST_URI'], '/create') === false ? 'active' : '' ?>">
                    <ion-icon name="grid-outline"></ion-icon> Forms
                </a>
            </li>
            <li class="nav-item">
                <a href="/admin/smart-forms/create" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/create') !== false ? 'active' : '' ?>">
                    <ion-icon name="add-circle-outline"></ion-icon> Create New
                </a>
            </li>
            <li class="nav-item">
                <a href="/admin/smart-forms/templates" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/templates') !== false ? 'active' : '' ?>">
                    <ion-icon name="copy-outline"></ion-icon> Templates
                </a>
            </li>
            
            <li class="nav-item" style="margin-top: 20px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 20px;">
                <a href="/dashboard" class="nav-link">
                    <ion-icon name="arrow-back-outline"></ion-icon> Back to Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a href="/logout" class="nav-link">
                    <ion-icon name="log-out-outline"></ion-icon> Logout
                </a>
            </li>
        </ul>
    </aside>
    <main class="main-content">
