<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($form['title']) ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f0f2f5; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .form-container { max-width: 640px; margin: 40px auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .form-header { margin-bottom: 30px; text-align: center; }
        .form-header h2 { font-weight: 700; color: #333; }
        .btn-submit { width: 100%; padding: 12px; font-weight: 600; font-size: 1.1rem; }
    </style>
</head>
<body>

<div class="container">
    <div class="form-container">
        <div class="form-header">
            <h2><?= htmlspecialchars($form['title']) ?></h2>
            <?php if (!empty($form['description'])): ?>
                <p class="text-muted"><?= htmlspecialchars($form['description']) ?></p>
            <?php endif; ?>
        </div>
        
        <?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
            <div class="alert alert-success text-center">
                <h4>Thank you!</h4>
                <p>Your submission has been received.</p>
                <a href="/f/<?= $form['id'] ?>" class="btn btn-outline-success mt-2">Submit another</a>
            </div>
        <?php else: ?>
        
            <form action="/f/<?= $form['id'] ?>/submit" method="POST" enctype="multipart/form-data">
                <?php 
                $structure = json_decode($form['structure'], true);
                if ($structure && is_array($structure)):
                    foreach ($structure as $field): 
                        $required = isset($field['required']) && $field['required'] ? 'required' : '';
                        $fieldName = htmlspecialchars($field['name']);
                        $label = htmlspecialchars($field['label']);
                        
                        // Static Content Block - No Label logic for this one usually
                        if ($field['type'] == 'content') {
                            echo '<div class="mb-4">';
                            if (!empty($label) && $label !== 'Information') echo '<h5 class="fw-bold mb-2">'.$label.'</h5>';
                            echo '<div class="text-muted">'.($field['options'] ?? '').'</div>'; // Allow HTML
                            echo '</div>';
                            continue;
                        }
                ?>
                    <div class="mb-4">
                        <label class="form-label fw-bold"><?= $label ?></label>
                        
                        <?php if ($field['type'] == 'text'): ?>
                            <input type="text" name="<?= $fieldName ?>" class="form-control" <?= $required ?>>
                            
                        <?php elseif ($field['type'] == 'email'): ?>
                            <input type="email" name="<?= $fieldName ?>" class="form-control" <?= $required ?>>

                        <?php elseif ($field['type'] == 'url'): ?>
                            <input type="url" name="<?= $fieldName ?>" class="form-control" placeholder="https://" <?= $required ?>>

                        <?php elseif ($field['type'] == 'file'): ?>
                            <input type="file" name="<?= $fieldName ?>" class="form-control" <?= $required ?>>
                            
                        <?php elseif ($field['type'] == 'textarea'): ?>
                            <textarea name="<?= $fieldName ?>" class="form-control" rows="3" <?= $required ?>></textarea>
 
                        <?php elseif ($field['type'] == 'dropdown'): ?>
                            <select name="<?= $fieldName ?>" class="form-select" <?= $required ?>>
                                <option value="">Select an option...</option>
                                <?php 
                                $options = explode(',', $field['options']);
                                foreach($options as $opt): 
                                ?>
                                    <option value="<?= trim(htmlspecialchars($opt)) ?>"><?= trim(htmlspecialchars($opt)) ?></option>
                                <?php endforeach; ?>
                            </select>
 
                        <?php elseif ($field['type'] == 'checkbox'): ?>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="<?= $fieldName ?>" value="Yes" id="chk_<?= $fieldName ?>" <?= $required ?>>
                                <label class="form-check-label" for="chk_<?= $fieldName ?>">
                                    <?= $label ?>
                                </label>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php 
                    endforeach; 
                else:
                ?>
                    <p class="text-muted text-center">This form has no fields.</p>
                <?php endif; ?>

                <button type="submit" class="btn btn-primary btn-submit">Submit</button>
            </form>
            
        <?php endif; ?>
        
        <div class="mt-4 text-center text-muted small">
            Powered by <a href="#" class="text-decoration-none text-muted fw-bold">Casjoe Smart Forms</a>
        </div>
    </div>
</div>

<script>
    let hasStarted = false;
    const formId = <?= $form['id'] ?>;

    function track(event, data = {}) {
        fetch(`/f/${formId}/track`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ event: event, metadata: data })
        }).catch(err => console.error(err));
    }

    // Track "start" on first input interaction
    document.querySelectorAll('input, select, textarea').forEach(el => {
        el.addEventListener('focus', () => {
            if (!hasStarted) {
                hasStarted = true;
                track('start');
            }
            // Track which field is active (for drop-off logic)
            // simple heat-check: we track "interaction" with field_name
            track('interaction', { field: el.name });
        });
    });
</script>

</body>
</html>
