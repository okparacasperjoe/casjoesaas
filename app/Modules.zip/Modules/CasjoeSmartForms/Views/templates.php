<?php $title = "Form Templates"; include __DIR__ . '/layout/header.php'; ?>

<div class="container-fluid pt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold">Form Templates</h2>
            <p class="text-muted">Start with a pre-built template or create from scratch.</p>
        </div>
        <div>
            <a href="/admin/smart-forms/create" class="btn btn-outline-secondary">
                <ion-icon name="add-outline" style="vertical-align: middle;"></ion-icon> Start from Blank
            </a>
        </div>
    </div>

    <div class="row g-4">
        <?php foreach ($templates as $t): ?>
            <div class="col-md-3">
                <div class="card h-100 border-0 shadow-lg" style="transition: transform 0.2s;">
                    <div class="card-body text-center d-flex flex-column">
                        <div class="mb-3">
                            <div class="d-inline-flex align-items-center justify-content-center rounded-circle" style="width: 80px; height: 80px; background: rgba(255, 166, 0, 0.1);">
                                <ion-icon name="<?= $t['icon'] ?>" style="font-size: 2.5rem; color: #FFA600;"></ion-icon>
                            </div>
                        </div>
                        <h5 class="fw-bold mb-2"><?= $t['title'] ?></h5>
                        <p class="text-muted small mb-4 flex-grow-1"><?= $t['description'] ?></p>
                        
                        <form action="/admin/smart-forms/templates/use" method="POST">
                           <input type="hidden" name="title" value="<?= $t['title'] ?>">
                           <input type="hidden" name="structure" value="<?= htmlspecialchars($t['structure']) ?>">
                           <button type="submit" class="btn btn-primary w-100">
                               Use Template
                           </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<style>
    .card:hover {
        transform: translateY(-5px);
    }
</style>

<?php include __DIR__ . '/layout/footer.php'; ?>
