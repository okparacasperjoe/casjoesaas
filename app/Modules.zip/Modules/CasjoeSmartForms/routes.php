<?php

use App\Core\Router;
use App\Modules\CasjoeSmartForms\Controllers\FormController;
use App\Modules\CasjoeSmartForms\Controllers\PublicFormController;

// Admin Routes (Builder & Stats)
Router::get('/admin/smart-forms', [FormController::class, 'index']);
Router::get('/admin/smart-forms/create', [FormController::class, 'create']);
Router::post('/admin/smart-forms/store', [FormController::class, 'store']);
Router::get('/admin/smart-forms/edit/{id}', [FormController::class, 'edit']);
Router::post('/admin/smart-forms/update/{id}', [FormController::class, 'update']);
Router::post('/admin/smart-forms/delete/{id}', [FormController::class, 'delete']);
Router::get('/admin/smart-forms/stats/{id}', [FormController::class, 'stats']);
Router::get('/admin/smart-forms/templates', [FormController::class, 'templates']);
Router::post('/admin/smart-forms/templates/use', [FormController::class, 'useTemplate']);

// Public Routes (Rendering & Submission)
Router::get('/f/{id}', [PublicFormController::class, 'show']);
Router::post('/f/{id}/submit', [PublicFormController::class, 'submit']);
Router::post('/f/{id}/track', [PublicFormController::class, 'trackAJAX']);
